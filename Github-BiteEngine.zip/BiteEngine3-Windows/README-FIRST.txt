BiteEngine 3 - Windows App
==========================
Free 2D game engine with Vexo scripting. MIT License.

QUICK START
-----------
1. Double-click BiteEngine3.exe.
2. The editor opens in an Edge app window.
3. Pick a ready-made game (Pixel Quest, Cave Escape, Sky Hopper) or
   press + New project.
4. File > Save (Ctrl+S) stores the project. File > Download .biteproj
   makes a backup file.

WHAT THE EXE DOES
-----------------
- Unpacks the engine to %LOCALAPPDATA%\BiteEngine3\app on first run.
- Serves it locally at http://127.0.0.1:17823 (loopback only).
- Opens Microsoft Edge in app mode: no tabs, no address bar.
- Adds a tray icon: Open BiteEngine / Open install folder / Exit.

REQUIREMENTS
------------
- Windows 10 or Windows 11.
- Microsoft Edge (installed by default). Chrome is used if Edge is absent.
- No admin rights, no installer, no runtime to install.

NOTES
-----
- The exe is unsigned. On first launch Windows SmartScreen may show a
  warning: click "More info" > "Run anyway".
- Projects live in %LOCALAPPDATA%\BiteEngine3\profile, so they survive
  restarts. Browser downloads still go to your normal Downloads folder.
- To reset everything: quit from the tray, then delete
  %LOCALAPPDATA%\BiteEngine3.
- Start without opening a window: BiteEngine3.exe --server-only

FOLDER CONTENTS
---------------
- BiteEngine3.exe
- README-FIRST.txt (this file)
- README.md      full engine guide
- LICENSE        MIT license
- logo.svg / logo.png / logo-banner.png
- icon.svg / icon-1024.png / icon-512.png / icon-192.png
- icon-maskable-512.png / favicon.ico

Source code and the web version are in the main project folder
(desktop/Program.cs and desktop/build-exe.ps1 build this exe).

HINGLISH
--------
BiteEngine3.exe ko double-click karein. Pehli baar SmartScreen warning
aa sakti hai: "More info" > "Run anyway". Editor Edge app window mein
khulega. Tray icon se dobara khol sakte hain ya exit kar sakte hain.
Aapke projects %LOCALAPPDATA%\BiteEngine3\profile mein safe rehte hain.
