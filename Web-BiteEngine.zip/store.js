'use strict';
(()=>{
const M=window.STORE_MANIFEST,ROOT='store/PixelAdventure/',A=M.assets;
const url=p=>ROOT+p.split('/').map(encodeURIComponent).join('/');
const nice=a=>a.p.replace(/\.png$/i,'').replace(/ ?\(\d+x\d+\)/,'').split('/').slice(1).join(' ');
let lib=new Set();try{lib=new Set(JSON.parse(localStorage.getItem('bite.lib')||'[]'))}catch{}
const save=()=>{try{localStorage.setItem('bite.lib',JSON.stringify([...lib]))}catch{}};
let view='home',cat='All',q='',picked=new Set(),libQ='',libSel=null;
const DISP={Terrain:'Tiles',Menu:'UI'},ORDER=['Characters','Enemies','Terrain','Backgrounds','Menu','Items','Traps','Other','Root'];
const byCat=c=>A.filter(a=>a.category===c);
const match=(a,s)=>!s||s.toLowerCase().split(/\s+/).every(w=>a.tags.some(t=>t.includes(w))||a.p.toLowerCase().includes(w));
function thumb(a,size=64){
  const fw=a.fw,fh=a.fh,m=Math.max(fw,fh),s=m>size?size/m:Math.max(1,Math.floor(size/m));
  return el('div',{className:'tbw'},el('div',{className:'tb',style:`width:${fw*s}px;height:${fh*s}px;background-image:url("${url(a.p)}");background-size:${a.w*s}px ${a.h*s}px`}));
}
const btn=(t,f,c='')=>el('button',{textContent:t,onclick:f,className:c});
function toast(m){const t=el('div',{className:'toast',textContent:m});document.body.append(t);setTimeout(()=>t.remove(),4500)}

/* ---------- Store ---------- */
function drawStore(){
  const r=$('#storeRoot');r.innerHTML='';
  const search=el('input',{placeholder:'Search sprites, characters, tiles, audio...',value:q,'aria-label':'Search assets',oninput:e=>{q=e.target.value;if(view==='home'&&q)view='pack';drawStore();$('#storeRoot input').focus();const i=$('#storeRoot input');i.setSelectionRange(q.length,q.length)}});
  r.append(el('h1',{textContent:'BiteEngine Asset Store'}),el('p',{className:'dim',textContent:'Discover assets. Build amazing games.'}),el('div',{className:'sbar'},search,btn('My Library ('+lib.size+')',()=>$('[data-ws=lib]').click())));
  view==='home'?home(r):pack(r);
}
function home(r){
  const pick=c=>byCat(c).find(a=>a.w>a.fw)||byCat(c)[0];
  const hero=el('div',{className:'hero'},el('div',{className:'prevs'},...['Characters','Enemies','Items'].map(c=>thumb(pick(c),64))),
    el('div',{},el('h2',{textContent:'Pixel Adventure'}),el('div',{className:'dim',textContent:'Characters, enemies, worlds. '+M.total+' PNG assets, free.'}),btn('View asset pack',()=>{view='pack';cat='All';drawStore()},'pri')));
  const chips=el('div',{className:'chips'},...ORDER.slice(0,5).map(c=>btn((DISP[c]||c)+' ('+byCat(c).length+')',()=>{view='pack';cat=c;drawStore()})),el('button',{textContent:'Audio (0)',disabled:true}));
  const cards=el('div',{className:'cards'},...['Characters','Enemies','Backgrounds'].map(c=>el('div',{className:'card'},thumb(pick(c)),el('b',{textContent:c}),el('span',{className:'free',textContent:'FREE'}),btn('Get asset',()=>{view='pack';cat=c;drawStore()}))));
  r.append(el('h2',{textContent:'Featured asset'}),hero,el('h2',{textContent:'Categories'}),chips,el('h2',{textContent:'Popular assets'}),cards);
}
function pack(r){
  const list=A.filter(a=>(cat==='All'||a.category===cat)&&match(a,q));
  r.append(btn('← Store',()=>{view='home';q='';drawStore()}),el('h1',{textContent:'Pixel Adventure'}),
    el('div',{className:'meta'},...[['Publisher',M.publisher],['Category',M.category],['Price',M.price],['License',M.license],['Assets',M.total+' PNG files'],['Import settings','Nearest filter, no compression, no mipmaps, pixel snap']].flatMap(([k,v])=>[el('span',{textContent:k}),el('b',{textContent:v})])));
  const chips=el('div',{className:'chips'},...['All',...ORDER.filter(c=>counts(c))].map(c=>btn(c==='All'?'All ('+A.length+')':(DISP[c]||c)+' ('+counts(c)+')',()=>{cat=c;drawStore()},c===cat?'on':'')));
  const n=picked.size;
  r.append(chips,el('div',{className:'sbar'},btn('Select shown',()=>{list.forEach(a=>picked.add(a.p));drawStore()}),btn('Clear selection',()=>{picked.clear();drawStore()}),
    btn(n?'Import '+n+' selected':'Import all '+A.length+' to My Library',doImport,'pri')));
  r.append(el('p',{className:'dim',textContent:list.length+' assets shown. Click to select.'}));
  r.append(el('div',{className:'grid'},...list.map(a=>el('div',{className:'asset'+(picked.has(a.p)?' sel':'')+(lib.has(a.p)?' in':''),title:a.p,onclick:()=>{picked.has(a.p)?picked.delete(a.p):picked.add(a.p);drawStore()}},thumb(a),el('span',{textContent:nice(a)||a.p}),el('span',{className:'dim',textContent:a.w+'×'+a.h+(a.frames>1?' · '+a.frames+' fr':'')})))));
}
const counts=c=>byCat(c).length;
function doImport(){
  const list=picked.size?[...picked]:A.map(a=>a.p),before=lib.size;list.forEach(p=>lib.add(p));save();picked.clear();
  const msg='Import complete: '+list.length+' assets ('+(lib.size-before)+' new) in Assets/Store/PixelAdventure/';
  toast(msg);log(msg+' with pixel-perfect settings','ok');drawStore();
}

/* ---------- My Library ---------- */
function drawLib(){
  const r=$('#libRoot');r.innerHTML='';const items=A.filter(a=>lib.has(a.p)&&match(a,libQ));
  r.append(el('h1',{textContent:'My Library'}),el('p',{className:'dim',textContent:lib.size+' installed assets. All use nearest filtering, no compression, no mipmaps, pixel snap on.'}),
    el('div',{className:'sbar'},el('input',{placeholder:'Search library',value:libQ,'aria-label':'Search library',oninput:e=>{libQ=e.target.value;drawLib();const i=$('#libRoot input');i.focus();i.setSelectionRange(libQ.length,libQ.length)}}),
      btn('Download metadata (.basset JSON)',dlMeta),btn('Remove all',()=>{lib.clear();libSel=null;save();drawLib()})));
  if(!lib.size){r.append(el('p',{textContent:'Nothing here yet. Open the Asset Store and import a pack.'}));return}
  const side=el('aside',{});
  if(libSel){
    const a=libSel,fps=el('input',{type:'number',value:10,min:1,max:60}),fw=el('input',{type:'number',value:a.fw,min:1}),fh=el('input',{type:'number',value:a.fh,min:1}),lp=el('input',{type:'checkbox',checked:true});
    const get=()=>({fw:Math.max(1,+fw.value),fh:Math.max(1,+fh.value),fps:Math.max(1,+fps.value||10),loop:lp.checked});
    side.append(thumb(a,96),el('h3',{textContent:nice(a)}),el('p',{className:'dim',textContent:a.w+'×'+a.h+' px, '+a.frames+' frames detected'}),
      ...[['Frame W',fw],['Frame H',fh],['FPS',fps],['Loop',lp]].map(([l,i])=>el('div',{className:'f'},el('label',{textContent:l}),i)),
      btn('Create animation from sprite sheet',()=>mkAnim(a,get()).then(n=>{$('[data-ws=anim]').click();log('Animation "'+n+'" created. Preview it in Animation Studio.','ok')}),'pri'),
      btn('Add to game scene',()=>mkAnim(a,get()).then(n=>{const s=sheets[n];const o=mk('AnimatedSprite2D',{name:n,x:Math.round(cam.x+40),y:100,w:s.fw,h:s.fh,anim:n});sel=o;log('Added "'+n+'" to the scene','ok');$('[data-ws=game]').click()})));
  }else side.append(el('p',{className:'dim',textContent:'Select an asset to create an animation from it.'}));
  r.append(el('div',{className:'libw'},el('div',{},...ORDER.map(c=>{const L=items.filter(a=>a.category===c);return L.length?el('div',{},el('h2',{textContent:(DISP[c]||c)+' ('+L.length+')'}),el('div',{className:'grid'},...L.map(a=>el('div',{className:'asset'+(libSel===a?' sel':''),onclick:()=>{libSel=a;drawLib()}},thumb(a),el('span',{textContent:nice(a)||a.p}))))):''})),side));
}
function mkAnim(a,o){
  return new Promise(res=>{
    const img=new Image();img.onload=()=>{
      const name=nice(a)||a.p,s=addSheet(name,img,o.fw,o.fh);s.src=a.p;
      ANIMS[name]={sheet:name,mode:o.loop?'loop':'once',frames:Array.from({length:s.n},(_,f)=>({f,dur:1/o.fps}))};
      curSheet=name;curAnim=name;selFrame=0;ap.restart(name);res(name);
    };img.src=url(a.p);
  });
}
function dlMeta(){
  const d=A.filter(a=>lib.has(a.p)).map(a=>({path:M.root+a.p,width:a.w,height:a.h,frameWidth:a.fw,frameHeight:a.fh,filter:'nearest',compression:'disabled',mipmaps:false,pixelSnap:true}));
  el('a',{href:URL.createObjectURL(new Blob([JSON.stringify(d,null,1)],{type:'application/json'})),download:'pixeladventure.basset.json'}).click();
}
/* ---------- Game Assets: project files, folders and sound library ---------- */
const SOUNDS=[
  {id:'jump',name:'Jump',file:'jump.wav',path:'assets/sounds/jump.wav',kind:'SFX'},
  {id:'collect_apple',name:'Collect Apple',file:'collect_apple.wav',path:'assets/sounds/collect_apple.wav',kind:'SFX'},
  {id:'death',name:'Death',file:'death.wav',path:'assets/sounds/death.wav',kind:'SFX'},
  {id:'music',name:'Background Music',file:'music.ogg',path:'assets/sounds/music.ogg',kind:'Music'}
];
window.BiteSounds=SOUNDS;
let AF={folders:[],files:[]},aScope='files',aFolder='*',aCat='Characters',aQ='',aKind='All',aSel=null;
const aMark=()=>window.BiteMarkDirty?.();
const aBase=s=>String(s||'').replace(/^.*[\\/]/,'').replace(/\.[^.]+$/,'');
const aSize=n=>n<1024?n+' B':n<1048576?(n/1024).toFixed(1)+' KB':(n/1048576).toFixed(1)+' MB';
const kindOfFile=(mime,name)=>{
  if(String(mime||'').startsWith('image/')||/\.(png|jpe?g|gif|webp|svg|bmp|ico)$/i.test(name))return'image';
  if(String(mime||'').startsWith('audio/')||/\.(wav|ogg|mp3|m4a|aac|flac|webm)$/i.test(name))return'audio';
  if(/\.(json|txt|csv|md|xml|js|css)$/i.test(name))return'data';
  return'other';
};
const folderList=()=>[...new Set([...AF.folders,...AF.files.map(f=>f.folder||'')])].filter(Boolean).sort();
const inFolder=(f,p)=>p==='*'||(f.folder||'')===p;
function addFolder(p){
  p=String(p||'').replace(/\\/g,'/').replace(/^\/+|\/+$/g,'');if(!p)return false;
  if(!AF.folders.includes(p)){AF.folders.push(p);AF.folders.sort()}return true;
}
function addFolderPath(p){const b=String(p||'').split('/').filter(Boolean);for(let i=1;i<=b.length;i++)addFolder(b.slice(0,i).join('/'))}
function readAsset(f,folder){
  return new Promise(res=>{
    const r=new FileReader();
    r.onload=()=>{
      const kind=kindOfFile(f.type,f.name);
      const it={id:'a'+Date.now().toString(36)+Math.random().toString(36).slice(2,8),name:f.name,folder,kind,mime:f.type||'',size:f.size||0,data:r.result};
      while(AF.files.some(x=>x.id===it.id))it.id+='x';
      if(kind!=='image')return res(it);
      const im=new Image();im.onload=()=>{it.w=im.naturalWidth;it.h=im.naturalHeight;res(it)};im.onerror=()=>res(it);im.src=r.result;
    };
    r.onerror=()=>res(null);r.readAsDataURL(f);
  });
}
async function importAssets(list){
  const fs=[...list];if(!fs.length)return;
  const added=[];
  for(const f of fs){
    const rel=(f.webkitRelativePath||'').split('/');rel.pop();
    let folder=rel.join('/');
    if(folder)addFolderPath(folder);else folder=aScope==='files'?(aFolder==='*'?'':aFolder):'';
    const it=await readAsset(f,folder);if(it){AF.files.push(it);added.push(it)}
  }
  if(!added.length)return;
  aSel={kind:'custom',id:added[0].id};aMark();
  toast('Added '+added.length+' file'+(added.length===1?'':'s')+' to Game Assets');
  log('Game Assets: imported '+added.length+' file(s)','ok');drawAssets();
}
function dlAsset(name,href){const a=el('a',{href,download:name});document.body.append(a);a.click();a.remove()}
function addSpriteToGame(a){
  if(typeof playing!=='undefined'&&playing){toast('Stop the game before adding nodes');return}
  const G=window.BiteGame;if(!G||!G.addNode)return;
  const custom=!!a.data,nm=G.uniqueName(aBase(a.name||a.p)||'Sprite');
  const n=G.addNode('Sprite2D',{name:nm,x:Math.round(cam.x+GW/2-16),y:70});if(!n)return;
  if(custom){n.tex='asset:'+a.id;n.w=a.w||32;n.h=a.h||32}
  else{n.tex=a.p;n.w=a.fw||32;n.h=a.fh||32}
  refresh();aMark();$('[data-ws=game]').click();toast('Added Sprite2D "'+nm+'"');
}
function addSoundToGame(a){
  if(typeof playing!=='undefined'&&playing){toast('Stop the game before adding nodes');return}
  const G=window.BiteGame;if(!G||!G.addNode)return;
  const custom=!!a.data,nm=G.uniqueName(aBase(a.name||a.path)||'Sound');
  const n=G.addNode('Sound',{name:nm,x:Math.round(cam.x+40),y:90});if(!n)return;
  n.sound=custom?'asset:'+a.id:a.path;
  if(/music|background/i.test(a.name||a.path)){n.loop=true;n.autoplay=true;n.trigger='start'}
  refresh();aMark();$('[data-ws=game]').click();toast('Added Sound node "'+nm+'"');
}
function aBadge(s,music){return el('div',{className:'afic'+(s==='audio'?' audio':''),textContent:music?'♫':s==='audio'?'♪':'FILE'})}
function drawAssets(){
  const r=$('#assetRoot');if(!r)return;r.innerHTML='';
  const fileIn=el('input',{type:'file',multiple:true,hidden:true,onchange:e=>{importAssets(e.target.files);e.target.value=''}});
  const dirIn=el('input',{type:'file',multiple:true,hidden:true,onchange:e=>{importAssets(e.target.files);e.target.value=''}});
  dirIn.webkitdirectory=true;dirIn.setAttribute('webkitdirectory','');
  r.append(fileIn,dirIn);
  const search=el('input',{className:'aSearch',placeholder:'Search assets',value:aQ,oninput:e=>{aQ=e.target.value;drawAssets();const i=$('#assetRoot .aSearch');if(i){i.focus();i.setSelectionRange(aQ.length,aQ.length)}}});
  const nf=el('input',{placeholder:'New folder',className:'aNew',onkeydown:e=>{if(e.key==='Enter')addBtn.click()}});
  const addBtn=btn('+ Folder',()=>{
    const v=nf.value.trim();if(!v)return;
    if(!addFolder(v)){toast('Folder already exists');return}
    aScope='files';aFolder=v;aSel=null;aMark();drawAssets();
  });
  r.append(el('h1',{textContent:'Game Assets'}),
    el('p',{className:'dim',textContent:'Manage this project’s files and folders. Uploaded images and audio are embedded in the saved .biteproj. Built-in sounds are referenced by path.'}),
    el('div',{className:'sbar'},
      btn('⬆ Upload files',()=>fileIn.click(),'pri'),btn('⬆ Upload folder',()=>dirIn.click()),
      el('span',{className:'grow'}),nf,addBtn,search));
  if(aScope==='files'){
    const chips=el('div',{className:'chips'},...['All','image','audio','data','other'].map(k=>{
      const n=k==='All'?AF.files.length:AF.files.filter(f=>f.kind===k).length;
      return btn((k==='All'?'All':k[0].toUpperCase()+k.slice(1))+' ('+n+')',()=>{aKind=k;drawAssets()},aKind===k?'on':'');
    }));
    r.append(chips);
  }
  const side=el('aside',{className:'afolders'});
  const row=(label,scope,folder,cat,n)=>{
    const on=aScope===scope&&(scope!=='files'||aFolder===folder)&&(scope!=='store'||aCat===cat);
    side.append(el('button',{className:'afrow'+(on?' on':''),onclick:()=>{aScope=scope;aFolder=folder||'';aCat=cat||aCat;aSel=null;drawAssets()}},
      el('span',{className:'afname',textContent:label}),n!==undefined?el('small',{textContent:n}):''));
  };
  side.append(el('h3',{textContent:'Project files'}));
  row('All project files','files','*',undefined,AF.files.length);
  row('Unsorted','files','',undefined,AF.files.filter(f=>!f.folder).length);
  for(const f of folderList())row(f,'files',f,undefined,AF.files.filter(x=>(x.folder||'')===f).length);
  side.append(el('h3',{textContent:'Sound library'}));
  row('All built-in sounds','sounds','',undefined,SOUNDS.length);
  for(const s of SOUNDS)side.append(el('button',{className:'afrow'+(aSel&&aSel.kind==='sound'&&aSel.id===s.id?' on':''),onclick:()=>{aSel={kind:'sound',id:s.id};aScope='sounds';drawAssets()}},el('span',{className:'afname',textContent:'♪ '+s.name})));
  side.append(el('h3',{textContent:'Pixel Adventure'}));
  for(const c of ORDER.filter(c=>counts(c)))row((DISP[c]||c),'store','',c,counts(c));
  const head=el('div',{className:'ahead'});
  head.append(el('h2',{textContent:aScope==='files'?(aFolder==='*'?'All project files':aFolder||'Unsorted'):aScope==='sounds'?'Built-in sounds':'Pixel Adventure · '+(DISP[aCat]||aCat)}));
  if(aScope==='files'&&aFolder&&aFolder!=='*'){
    const rn=el('input',{value:aFolder,className:'aRenameFolder'});
    head.append(rn,btn('Rename folder',()=>{
      const v=rn.value.trim().replace(/[\\/]+/g,'-');if(!v)return;
      const old=aFolder;
      AF.files.forEach(f=>{if((f.folder||'')===old)f.folder=v;else if((f.folder||'').startsWith(old+'/'))f.folder=v+f.folder.slice(old.length)});
      AF.folders=AF.folders.map(x=>x===old?v:x.startsWith(old+'/')?v+x.slice(old.length):x);
      addFolder(v);aFolder=v;aMark();drawAssets();
    }),btn('Delete folder',()=>{
      const old=aFolder,n=AF.files.filter(f=>(f.folder||'')===old||(f.folder||'').startsWith(old+'/')).length;
      if(!confirm('Delete folder "'+old+'"? '+n+' file(s) will move to the project root.'))return;
      AF.files.forEach(f=>{if((f.folder||'')===old||(f.folder||'').startsWith(old+'/'))f.folder=''});
      AF.folders=AF.folders.filter(x=>x!==old&&!x.startsWith(old+'/'));
      aFolder='*';aMark();drawAssets();
    },'danger'));
  }
  const grid=el('div',{className:'grid afgrid'});
  if(aScope==='files'){
    const list=AF.files.filter(f=>inFolder(f,aFolder)&&(aKind==='All'||f.kind===aKind)&&(!aQ||(f.name+' '+(f.folder||'')).toLowerCase().includes(aQ.toLowerCase()))).sort((a,b)=>a.name.localeCompare(b.name));
    for(const f of list){
      const card=el('div',{className:'asset afile'+(aSel&&aSel.kind==='custom'&&aSel.id===f.id?' sel':''),title:f.name,
        onclick:()=>{aSel={kind:'custom',id:f.id};drawAssets()},
        ondblclick:()=>{if(f.kind==='image')addSpriteToGame(f);else if(f.kind==='audio')addSoundToGame(f)}},
        f.kind==='image'?el('div',{className:'aThumb',style:'background-image:url("'+f.data+'")'}):aBadge(f.kind),
        el('span',{textContent:f.name}),
        el('span',{className:'dim',textContent:f.kind+(f.w?' '+f.w+'×'+f.h:'')+' · '+aSize(f.size||0)}));
      grid.append(card);
    }
    if(!list.length)grid.append(el('div',{className:'homeEmpty',textContent:AF.files.length?'No files in this folder. Upload files or pick another folder.':'No project files yet. Use Upload files or Upload folder.'}));
  }else if(aScope==='sounds'){
    for(const s of SOUNDS){
      grid.append(el('div',{className:'asset afile'+(aSel&&aSel.kind==='sound'&&aSel.id===s.id?' sel':''),title:s.path,
        onclick:()=>{aSel={kind:'sound',id:s.id};drawAssets()},ondblclick:()=>addSoundToGame(s)},
        aBadge('audio',s.kind==='Music'),el('span',{textContent:s.name}),el('span',{className:'dim',textContent:s.kind+' · '+s.file})));
    }
  }else{
    const list=A.filter(a=>a.category===aCat&&(!aQ||(a.p+' '+a.tags.join(' ')).toLowerCase().includes(aQ.toLowerCase())));
    for(const a of list){
      grid.append(el('div',{className:'asset afile'+(aSel&&aSel.kind==='sprite'&&aSel.id===a.p?' sel':''),title:a.p,
        onclick:()=>{aSel={kind:'sprite',id:a.p};drawAssets()},ondblclick:()=>addSpriteToGame(a)},
        thumb(a,64),el('span',{textContent:nice(a)||a.p}),el('span',{className:'dim',textContent:a.w+'×'+a.h})));
    }
    if(!list.length)grid.append(el('div',{className:'homeEmpty',textContent:'No sprites match this search.'}));
  }
  const main=el('div',{className:'amain'},head,el('p',{className:'dim',textContent:grid.children.length+' item(s)'}),grid);
  r.append(el('div',{className:'filew'},side,main,assetPreview()));
}
function assetPreview(){
  const p=el('aside',{className:'aprev'});
  if(!aSel){p.append(el('h3',{textContent:'Preview'}),el('p',{className:'dim',textContent:'Select a file to preview, rename, move or add it to the game.'}));return p}
  if(aSel.kind==='custom'){
    const f=AF.files.find(x=>x.id===aSel.id);
    if(!f){aSel=null;return p}
    p.append(el('h3',{textContent:'Project file'}));
    if(f.kind==='image')p.append(el('img',{className:'apimg',src:f.data,alt:f.name}));
    else if(f.kind==='audio')p.append(el('audio',{className:'apaudio',controls:true,preload:'metadata',src:f.data}));
    else p.append(aBadge(f.kind));
    const nm=el('input',{value:f.name,onchange:e=>{const v=e.target.value.trim();if(v){f.name=v;aMark();drawAssets()}}});
    const fs=el('select',{onchange:e=>{f.folder=e.target.value;aMark();drawAssets()}});
    fs.add(new Option('Project root',''));for(const x of folderList())fs.add(new Option(x,x));fs.value=f.folder||'';
    p.append(el('div',{className:'f'},el('label',{textContent:'Name'}),nm),el('div',{className:'f'},el('label',{textContent:'Folder'}),fs),
      el('p',{className:'dim',textContent:f.kind+(f.w?' · '+f.w+'×'+f.h:'')+' · '+aSize(f.size||0)}));
    const acts=el('div',{className:'f2'});
    if(f.kind==='image')acts.append(btn('Add Sprite2D',()=>addSpriteToGame(f),'pri'));
    if(f.kind==='audio')acts.append(btn('Add Sound node',()=>addSoundToGame(f),'pri'));
    acts.append(btn('Download',()=>dlAsset(f.name,f.data)));
    acts.append(btn('Delete',()=>{
      if(!confirm('Delete "'+f.name+'" from this project?'))return;
      AF.files=AF.files.filter(x=>x!==f);aSel=null;aMark();drawAssets();
    },'danger'));
    p.append(acts);
  }else if(aSel.kind==='sound'){
    const s=SOUNDS.find(x=>x.id===aSel.id);if(!s){aSel=null;return p}
    p.append(el('h3',{textContent:'Built-in sound'}),aBadge('audio',s.kind==='Music'),el('b',{textContent:s.name}),
      el('p',{className:'dim',textContent:s.kind+' · '+s.path}),
      el('audio',{className:'apaudio',controls:true,preload:'metadata',src:s.path}),
      el('div',{className:'f2'},btn('Add Sound node',()=>addSoundToGame(s),'pri'),btn('Download',()=>dlAsset(s.file,s.path))));
  }else{
    const a=A.find(x=>x.p===aSel.id);if(!a){aSel=null;return p}
    p.append(el('h3',{textContent:'Built-in sprite'}),thumb(a,128),el('b',{textContent:nice(a)||a.p}),
      el('p',{className:'dim',textContent:a.w+'×'+a.h+' · frame '+a.fw+'×'+a.fh+' · '+a.frames+' frame(s)'}),
      el('div',{className:'f2'},btn('Add Sprite2D',()=>addSpriteToGame(a),'pri'),
        btn('Create animation',()=>mkAnim(a,{fw:a.fw,fh:a.fh,fps:10,loop:true}).then(n=>{$('[data-ws=anim]').click();log('Animation "'+n+'" created','ok')}))));
  }
  return p;
}
window.BiteAssets={
  data:()=>({folders:[...AF.folders],files:AF.files.map(f=>({...f}))}),
  load:d=>{AF={folders:[...(d&&d.folders||[])],files:[...(d&&d.files||[])]};aSel=null;if($('#assetRoot'))drawAssets()},
  list:()=>AF.files.slice(),
  get:id=>AF.files.find(f=>f.id===id)||null,
  url:src=>{const s=String(src||'');if(!s.startsWith('asset:'))return s;const f=AF.files.find(x=>'asset:'+x.id===s);return f?f.data:''},
  info:src=>{const s=String(src||'');if(s.startsWith('asset:')){const f=AF.files.find(x=>'asset:'+x.id===s);return f?{w:f.w||32,h:f.h||32,fw:f.w||32,fh:f.h||32,frames:1}:null}const a=A.find(x=>x.p===s);return a||null},
  audioOptions:()=>[...SOUNDS.map(s=>[s.path,s.name+' ('+s.kind+')']),...AF.files.filter(f=>f.kind==='audio').map(f=>['asset:'+f.id,'[Project] '+f.name])],
  imageOptions:()=>AF.files.filter(f=>f.kind==='image').map(f=>['asset:'+f.id,'[Project] '+f.name]),
  draw:drawAssets
};
$$('#tabs button').forEach(b=>b.addEventListener('click',()=>{if(b.dataset.ws==='store')drawStore();if(b.dataset.ws==='lib')drawLib();if(b.dataset.ws==='assets')drawAssets()}));
log('Asset Store ready: '+M.name+' ('+M.total+' assets)','ok');
window.BiteLib={url,get:()=>[...lib],set:a=>{lib=new Set(a);save()}};
})();
