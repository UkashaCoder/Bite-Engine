BiteEngine 3 — 2D game editor in the browser
============================================

RUN
---
1. Extract the whole ZIP (keep index.html, the "store" folder and the "assets"
   folder together).
2. Open index.html in Chrome, Edge, Firefox or Safari.
   No install, server or C# needed. Vexo Script is built in.
3. On a phone, open mobile.html instead: it is the same editor with all code in
   one file (see SINGLE-FILE MOBILE BUILD below).

MOBILE (touch)
--------------
- Tap a project card to open it, or "+ New project".
- Bottom tab bar switches Game Editor, Animation, Pixel Art, Profiler, Store,
  Library and Game Assets.
- Game Editor: tap + (bottom right) to add a node. Long-press a node in the scene
  tree or the viewport for Rename / Duplicate / Delete / Add Child.
- Tap Scene / Inspect / Console / View to open the bottom panels.
- Tap Pan, then drag the viewport with one finger. Tap Pan again to move nodes.
- Play controls are in the top toolbar (scroll it sideways for extras).
- The Scene bar under the toolbar switches scenes; + Scene, Duplicate, Rename
  and Delete manage them. Each scene keeps its own nodes.
- Use File > Download .biteproj to back up a project. Projects are saved in the
  browser on the device.
- On Android/Desktop Chrome (served over http/https) the app can be installed
  from the browser menu using manifest.webmanifest + sw.js.

GLASS UI AND 5 COLOUR THEMES
----------------------------
The interface uses a glassmorphism style: frosted translucent panels, soft
light borders and accent glows over a layered background. It covers the project
manager, toolbars, side panels, menus, dialogs and mobile sheets.

Five colour themes are available:
  Cyan, Violet, Emerald, Amber, Rose.

Pick one from the colour swatches in the project manager header, the editor
header, or Edit > Theme: … The choice is remembered in this browser. The
Light theme button works with every colour and switches the glass to a frosted
white look.

SINGLE-FILE MOBILE BUILD
------------------------
mobile.html is a complete phone build with the HTML, both stylesheets and every
JavaScript file inlined. There are no external .css or .js files to load. Open
it on a phone and use the same project manager, editor, templates, glass UI and
five colour themes; projects use the same browser storage as index.html.

Keep mobile.html next to the assets/ and store/ folders so the built-in sounds
and bundled artwork load. Without those folders the editor and games still run,
but bundled art and sounds are missing.

MAIN FILES (28)
---------------
 1. index.html           App shell and editor markup
 2. style.css            Desktop / base theme
 3. mobile.css           Touch-first mobile layout
 4. mobile.js            Mobile panels, Pan mode, first-run tip, PWA hook
 5. engine.js            Rendering, animation runtime, main loop
 6. godot.js             Node types, scene tree, context menus, AnimationPlayer,
                         Vexo runtime glue, game menus, auto scripts, touch
 7. project.js           Project manager, save/load, templates, logos, home
 8. store.js             Asset store, project file manager and sound library
 9. vexo.js              Vexo 2D scripting language (lexer/parser/runtime)
10. store/manifest.js    Asset catalogue
11. manifest.webmanifest Installable app metadata
12. sw.js                Offline cache and update strategy
13. logo.svg             Website logo (vector)
14. logo.png             Website logo, 1200 x 320
15. logo-banner.png      Logo banner with dark background for store pages
16. icon.svg             App icon (vector)
17. icon-1024.png        App icon, 1024 x 1024
18. icon-192.png         App icon, 192 x 192
19. icon-512.png         App icon, 512 x 512
20. icon-maskable-512.png App icon for Android maskable use
21. favicon.ico          Windows browser / shortcut icon
22. BiteEngine3-Windows/ Windows release folder: BiteEngine3.exe,
                         README-FIRST.txt, LICENSE, logo and icon files
23. desktop/Program.cs   Launcher source (C#)
24. desktop/build-exe.ps1 Launcher build script
25. README.md            Markdown guide (features, publishing, license)
26. LICENSE              MIT license text
27. mobile.html          Single-file mobile build (all CSS + JS inline)
28. README.txt           This file

Folders:
  store/                 Bundled Pixel Adventure artwork for the Asset Store
  assets/sounds/         Built-in sounds: jump.wav, collect_apple.wav,
                         death.wav, music.ogg

WINDOWS APP
-----------
Double-click BiteEngine3.exe to run the full engine as a desktop app.

  - First run unpacks the engine to %LOCALAPPDATA%\BiteEngine3\app.
  - It serves the editor at http://127.0.0.1:17823 and opens an Edge app
    window (no tabs, no address bar). Projects persist in the bundled profile.
  - The tray icon opens the editor, opens the install folder or exits.
  - Microsoft Edge is required (preinstalled on Windows 10/11). Without it the
    editor opens in the default browser.
  - The exe is unsigned, so SmartScreen may ask for confirmation once.
  - Command line: BiteEngine3.exe --server-only starts the local server only.

GAME ASSETS
-----------
Open the Game Assets tab to manage everything the project uses:

  - Upload files or a whole folder. Images and sounds are embedded in the
    saved .biteproj, so the project stays self-contained.
  - Create, rename and delete folders, filter by Image / Audio / Data / Other.
  - Preview an image or play an audio file, then click Add Sprite2D or
    Add Sound node to put it in the scene.
  - Built-in sounds (Jump, Collect Apple, Death, Background Music) are listed
    under Sound library and are referenced by path, so saves stay small.
  - Projects load their assets again automatically when reopened.

GAMEPLAY NODES (NO CODE NEEDED)
-------------------------------
Add these from the + button or by right-clicking the scene tree:

  Enemy           20 skins, Patrol / Chase / Fly / Static, health, damage,
                  stomp to defeat, score points.
  StartCheckpoint Player spawn when Play starts. Heal and label options.
  Checkpoint      Saves respawn point when touched. Heal, bonus, reusable.
  EndCheckpoint   Finishes the level. Win text, bonus, require all coins,
                  optional next scene (Space/Enter or automatic), label.
  SceneChanger    Level door. Touch it to load another scene. Options: target
                  scene, delay, keep player health, label.
  Spike           Floor or wall hazard. Damage and respawn options.
  Spring          Bounces the player upward. Set bounce power.
  FireTrap        Timed fire hazard. Set cycle, on/off times, damage.
  MovingPlatform  Moves on X or Y, carries the player, ping-pong distance.
  BreakableBox    3 box styles, hit count, score, optional coin drop.
  Sound           Plays a built-in or uploaded clip. Trigger it when the
                  level starts, when the player touches it, when a key is
                  pressed, or manually from Vexo. Options: volume, loop,
                  play at start, only once.

Jump, collect and death effects play automatically. Use the SFX checkbox in
the game toolbar to mute sound effects. The background music node loops until
you press Stop.

The player node already has Max health. Touching a StartCheckpoint or
Checkpoint heals by default. The goal screen shows score and the next level.

MULTIPLE SCENES AND LEVEL CHANGES
--------------------------------
A project can hold many scenes, like Godot scenes or levels.

  - Use the Scene bar above the viewport: pick a scene from the list, then
    + Scene (new empty scene with a Node2D root), Duplicate, Rename or Delete.
    File > Scene and the Help menu offer the same actions, plus Next/Previous.
  - Each scene stores its own node tree. Switching scenes never mixes nodes.
  - Renaming a scene updates SceneChanger and EndCheckpoint targets that used
    the old name.

Changing level while the game is playing:

  1. SceneChanger node: set Target scene in the Inspector. When the player
     touches the door, the engine loads that scene after the Delay, keeps the
     score, and with Keep player health keeps the current HP.
  2. EndCheckpoint node: set Next scene. On touching the goal the win banner
     appears; press Space/Enter, or tick Continue automatically to load the
     next scene after Auto delay.
  3. Vexo script: change_scene("Level 2") and get_scene().
     Legacy JavaScript hooks also get change_scene() and get_scene().

The target scene needs its own Player (CharacterBody2D) and ground, because
each scene is a complete level. The engine logs a warning if a scene has no
player. Score, assets, animations and the Sound library carry across levels.

READY-MADE GAMES (3 TEMPLATES × 10 LEVELS)
------------------------------------------
The home screen has a "Ready-made games" row, and the New project dialog lists
the same three templates:

  Pixel Quest    Classic platformer. 10 green levels with fruit, enemies,
                 spikes, springs, checkpoints and a goal.
  Cave Escape    Action levels. 10 caverns with fire traps, flying enemies,
                 moving platforms and spikes.
  Sky Hopper     Coin collector. 10 sky levels; the goal requires every coin.
                 Springs, breakable boxes and floating platforms.

Each template creates a complete project with:
  - 10 scenes named Level 1 … Level 10, linked by the goal (auto-advance after
    touching the EndCheckpoint).
  - A Player, StartCheckpoint, ground, floating platforms, coins, enemies,
    hazards, background, music and a mid-level checkpoint from Level 3.
  - A configured game menu: Main, Pause and Game Over pages with level select.
  - A difficulty ramp: more enemies and hazards in later levels.

Click Create game on a card, or pick a game template in New project. The game
opens in the editor immediately and is saved in this browser. Edit any level,
add nodes or scripts, then press Play. Press Esc for the pause menu; Level
select lists all 10 scenes.

PROJECT LOGOS AND DOWNLOAD
--------------------------
Every project gets a logo: a 16:9 title card with the project initials, name,
accent bar and the BITEENGINE 3 mark. The three game templates use their own
colours (green Sky Hopper, amber Cave Escape, blue Pixel Quest); other projects
get a colour picked from the project name.

  - The logo is shown on the project card in the project manager and next to
    the project name in the editor toolbar.
  - The logo is stored inside the project file (the logo key in .biteproj), so
    an imported or downloaded project keeps the same logo.
  - Click Download on a project card, or File > Download .biteproj, to open the
    Download project panel. It previews the logo and offers:
      Download .biteproj           full project with the logo embedded
      Download logo (PNG 640×360)  logo image for a store page or README
      Download Windows icon (.ico) 256×256 icon for a shortcut or file type
  - Browsers cannot attach a custom icon to a .biteproj file automatically.
    Keep the PNG next to the project, or use the .ico for a shortcut or a
    Windows file-type icon.

GAME MENUS
----------
Click Menus in the toolbar (or File / Game Menu > Menu builder) to design the
menus that appear while the game is playing. Three pages are included:

  Main menu    Start game, Level select, Settings, Back to editor.
  Pause menu   Resume, Restart level, Level select, Main menu, Settings,
               Back to editor.
  Game over    Retry level, Level select, Main menu, Back to editor.

For each page you can set Enabled, Title, Subtitle, Accent colour and which
buttons are shown. Main menu also has "Show automatically when Play starts".
Preview starts the game with that menu open. Save menu stores the setup inside
the project (the menus key in .biteproj).

While playing:
  - Esc or P opens / closes the pause menu.
  - Up / Down and Enter (or W / S) navigate and activate. Click or tap also
    works. Game simulation pauses while a menu is open.
  - Settings can toggle sound effects and fullscreen.
  - Level select lists every scene in the project and loads it immediately.
  - The game over menu opens automatically when the player's health reaches 0
    (if Game over is enabled in the builder).

AUTOMATIC SCRIPTS
-----------------
You do not have to write code to make a node do something useful.

  - Select a node and click Auto in the Scene panel header (or right-click >
    Automatic script). The engine attaches a ready-made Vexo behaviour that
    matches the node type: CharacterBody2D gets player movement, Area2D gets
    coin collection, Label shows the score, Sound plays on touch, SceneChanger
    changes scene, AnimatedSprite2D plays its animation. Other types get a
    starter template suited to the node.
  - Behaviours… opens a picker with all 15 Vexo behaviours (movement, follow,
    collect, damage, door, animation, enemy damage, heal, checkpoint, sound,
    win level, change scene, score label, fall respawn). Choose one and press
    Add script.
  - When creating a new node, tick "Add starter script automatically" before
    pressing Create. The automatic script is attached immediately.
  - Auto / Add script appends to the node script and skips code that is
    already attached, so clicking twice is safe. Use Edit script to change it.

SCRIPTING
---------
Select a node, then Scene panel > Script (or right-click > Attach Vexo script).
Vexo uses indentation:

  on start:
      print("hello")

  on update(dt):
      self.x += 60 * dt

Signals: signal, emit, connect; timers: after, every; collisions: on collision(other).
Vexo audio: play_sound("jump"), play_sound("asset:<id>"), play_music("music"),
stop_sound("jump"), stop_music(). Scenes: change_scene("Level 2"), get_scene().
C# is not part of this engine.

PUBLISHING
----------
BiteEngine is a static website. To publish it, upload the whole folder
(including store/ and assets/) to any static host and serve it over HTTPS.
HTTPS enables the service worker, offline mode and PWA installation.

Before sharing a game:
  1. Save the project (Ctrl+S), then use File > Publish checklist.
     It checks the project name, scene count, player, game menu and logo.
  2. Use File > Download .biteproj to export the project with its logo.
  3. Use File > Download .biteproj > Download logo to create store artwork
     (PNG 640 x 360) and a Windows icon (.ico).
  4. Send the .biteproj file to players; they open it with File > Open file.

The service worker (sw.js) loads pages, scripts and styles from the network
first, so a new deployment is picked up on the next visit. Bump the cache name
in sw.js (biteengine3-v9 to biteengine3-v10) when you deploy an update.

LICENSE AND FREE USE
--------------------
BiteEngine is released under the MIT License. See LICENSE for the full text.

You can use, copy, modify, merge, publish, distribute, sublicense and sell
copies of the software, including commercially, provided the copyright notice
and permission notice are included. The software is provided "as is", without
warranty of any kind.

The bundled Pixel Adventure artwork by Pixel Frog is CC0 public domain and is
not covered by the MIT license. Its attribution remains visible in the Asset
Store.

TIPS
----
- Every new project starts with a Node2D root.
- Select AnimationPlayer > Open animation timeline. Add keyframes, press Play in
  the timeline header to preview.
- Encounter an error? Open the Console panel to read it.
- Help > License shows the MIT text inside the app. Help > Quick start lists
  the basic workflow.
