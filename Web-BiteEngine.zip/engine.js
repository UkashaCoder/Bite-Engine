'use strict';
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const el=(t,p={},...k)=>{const e=Object.assign(document.createElement(t),p);e.append(...k);return e};
function log(m,c=''){const d=el('div',{className:c,textContent:m});$('#log').append(d);$('#log').scrollTop=1e9}
const STEP=1/60,GW=320,GH=180;

/* ================= Sprite sheets & animation ================= */
const sheets={},ANIMS={};
function slice(s){
  s.cols=Math.max(1,Math.floor((s.img.width-2*s.m+s.sp)/(s.fw+s.sp)));
  s.rows=Math.max(1,Math.floor((s.img.height-2*s.m+s.sp)/(s.fh+s.sp)));s.n=s.cols*s.rows;
}
function addSheet(name,img,fw,fh,m=0,sp=0){const s={name,img,fw,fh,m,sp};slice(s);sheets[name]=s;return s}
function blit(g,s,f,x,y,flip){
  const c=f%s.cols,r=Math.floor(f/s.cols),sx=s.m+c*(s.fw+s.sp),sy=s.m+r*(s.fh+s.sp);
  if(flip){g.save();g.translate(x+s.fw,y);g.scale(-1,1);g.drawImage(s.img,sx,sy,s.fw,s.fh,0,0,s.fw,s.fh);g.restore()}
  else g.drawImage(s.img,sx,sy,s.fw,s.fh,x,y,s.fw,s.fh);
}
/* Time-based player: accumulates elapsed time, supports per-frame durations,
   loop / pingpong / once, resets on switch, independent of render FPS. */
class AnimPlayer{
  constructor(){this.name=null;this.reset()}
  reset(){this.t=0;this.i=0;this.dir=1;this.done=false}
  play(n){if(this.name!==n){this.name=n;this.reset()}}
  restart(n){this.name=null;this.play(n)}
  update(dt,speed=1){
    const a=ANIMS[this.name];if(!a||!a.frames.length||this.done)return;
    this.t+=dt*speed;let g=0;
    while(!this.done&&g++<64){
      const d=Math.max(.01,a.frames[Math.min(this.i,a.frames.length-1)].dur);
      if(this.t<d)break;this.t-=d;this.advance(a);
    }
  }
  advance(a){
    const n=a.frames.length;
    if(n<2){if(a.mode==='once')this.done=true;return}
    if(a.mode==='pingpong'){if(this.i+this.dir>=n||this.i+this.dir<0)this.dir*=-1;this.i+=this.dir}
    else if(this.i+1>=n){if(a.mode==='loop')this.i=0;else{this.done=true;this.t=0}}
    else this.i++;
  }
  frame(){const a=ANIMS[this.name];return a&&a.frames[Math.min(this.i,a.frames.length-1)]}
}
/* ================= Game editor ================= */
const cv=$('#cv'),ctx=cv.getContext('2d');
const buf=el('canvas',{width:GW,height:GH}),bg=buf.getContext('2d');
const NODE_TYPES=['CharacterBody2D','AnimatedSprite2D','StaticBody2D','Area2D'];
let nodes=[],sel=null,nid=1,playing=false,run=null,pp=true,score=0,cam={x:0,y:0},view={s:1,ox:0,oy:0},drag=null,calls=0;
const aps=new Map(),keys={};
const apOf=n=>{let a=aps.get(n);if(!a)aps.set(n,a=new AnimPlayer());return a};
function mk(type,o={}){const n={id:nid++,type,name:type,x:0,y:0,w:16,h:16,anim:'Idle',flip:false,speed:1,...o};nodes.push(n);return n}
function demo(){nodes=[];nid=1;sel=null;refresh()}
function refresh(){
  const ul=$('#list');ul.innerHTML='';
  nodes.forEach(n=>ul.append(el('li',{className:n===sel?'sel':'',onclick:()=>{if(!playing){sel=n;refresh()}}},n.name,el('small',{textContent:n.type}))));
  const f=$('#fields');f.innerHTML='';
  if(!sel){f.append(el('p',{className:'dim',textContent:'Select a node to edit it.'}));return}
  const row=(label,key,type='text',opts)=>{
    const d=el('div',{className:'f'},el('label',{textContent:label}));let i;
    if(type==='select'){i=el('select');opts.forEach(o=>i.add(new Option(o)));i.value=sel[key];i.onchange=()=>sel[key]=i.value}
    else if(type==='checkbox'){i=el('input',{type,checked:sel[key],onchange:()=>sel[key]=i.checked})}
    else{i=el('input',{type,value:sel[key],step:'any',oninput:()=>{sel[key]=type==='number'?+i.value:i.value;if(key==='name')ul.children[nodes.indexOf(sel)].firstChild.textContent=sel.name}})}
    d.append(i);f.append(d);
  };
  row('Name','name');row('X','x','number');row('Y','y','number');row('Width','w','number');row('Height','h','number');
  if(sel.type==='CharacterBody2D'||sel.type==='AnimatedSprite2D'){row('Animation','anim','select',Object.keys(ANIMS));row('Speed','speed','number');row('Flip H','flip','checkbox')}
}
function listNodes(){
  const q=$('#nsearch').value.toLowerCase(),ul=$('#nlist');ul.innerHTML='';
  NODE_TYPES.filter(t=>t.toLowerCase().includes(q)).forEach(t=>ul.append(el('li',{textContent:t,onclick:()=>{
    if(playing)return;sel=mk(t,t==='StaticBody2D'?{w:64,h:12}:t==='AnimatedSprite2D'?{w:32,h:32}:t==='Area2D'?{w:8,h:8}:{w:12,h:26});
    sel.x=Math.round(cam.x+GW/2-sel.w/2);sel.y=60;log('Created '+t,'ok');refresh()}})));
}
$('#nsearch').oninput=listNodes;listNodes();
$('#bDel').onclick=()=>{if(playing||!sel)return;nodes=nodes.filter(n=>n!==sel);log('Deleted '+sel.name,'w');sel=null;refresh()};
$('#pp').onchange=e=>{pp=e.target.checked;log('Pixel perfect '+(pp?'ON':'OFF'),pp?'ok':'w')};
$('#bPlay').onclick=()=>{
  run=JSON.parse(JSON.stringify(nodes));run.forEach(n=>{n.vx=0;n.vy=0;n.sx=n.x;n.sy=n.y});
  score=0;$('#score').textContent='Coins 0';playing=true;document.body.classList.add('live');$('#bPlay').disabled=true;$('#bStop').disabled=false;cv.focus();log('▶ Play','ok');
};
$('#bStop').onclick=()=>{playing=false;run=null;cam.x=0;document.body.classList.remove('live');$('#bPlay').disabled=false;$('#bStop').disabled=true;log('■ Stop')};
addEventListener('keydown',e=>{const k=e.key.toLowerCase();keys[k]=true;if(playing&&[' ','arrowup','arrowdown','arrowleft','arrowright'].includes(k))e.preventDefault()});
addEventListener('keyup',e=>keys[e.key.toLowerCase()]=false);
const hit=(a,b)=>a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y;

function gameStep(){
  const L=playing?run:nodes,solids=L.filter(n=>n.type==='StaticBody2D');
  if(playing){
    for(const b of L.filter(n=>n.type==='CharacterBody2D')){
      const ax=(keys.d||keys.arrowright?1:0)-(keys.a||keys.arrowleft?1:0);
      b.vx=ax*95;b.vy=Math.min(b.vy+720*STEP,420);
      if(ax)b.flip=ax<0;
      if((keys[' ']||keys.w||keys.arrowup)&&b.floor)b.vy=-285;
      b.x+=b.vx*STEP;for(const s of solids)if(hit(b,s))b.x=b.vx>0?s.x-b.w:s.x+s.w;
      b.y+=b.vy*STEP;b.floor=false;
      for(const s of solids)if(hit(b,s)){if(b.vy>0){b.y=s.y-b.h;b.floor=true}else b.y=s.y+s.h;b.vy=0}
      if(b.y>400){b.x=b.sx;b.y=b.sy;b.vy=0;log('Player fell and respawned','w')}
      b.anim=ax?'Run':'Idle';
      for(const a of L.filter(n=>n.type==='Area2D'))if(hit(b,a)){run=run.filter(n=>n!==a);score++;$('#score').textContent='Coins '+score;log('Area2D: coin collected','ok')}
      const t=b.x+b.w/2-GW/2;cam.x+=(t-cam.x)*.12;cam.x=Math.max(0,Math.min(640-GW,cam.x));
    }
  }
  for(const n of L)if(n.type==='CharacterBody2D'||n.type==='AnimatedSprite2D'){const a=apOf(n);a.play(n.anim);a.update(STEP,n.speed||1)}
}
let cvW=0,cvH=0;
function measureCv(){const r=cv.getBoundingClientRect();cvW=Math.round(r.width);cvH=Math.round(r.height)}
const hasRO=typeof ResizeObserver!=='undefined';
if(hasRO)new ResizeObserver(es=>{const r=es[es.length-1].contentRect;cvW=Math.round(r.width);cvH=Math.round(r.height)}).observe(cv);
measureCv();
function fit(c){
  if(!hasRO||!cvW||!cvH)measureCv();
  const d=Math.min(devicePixelRatio||1,2),w=Math.round(cvW*d),h=Math.round(cvH*d);
  if(w&&(c.width!==w||c.height!==h)){c.width=w;c.height=h}
}
function setValid(cls,txt){const v=$('#valid');if(v.className===cls&&v.textContent===txt)return;v.className=cls;v.textContent=txt}
function renderGame(){
  fit(cv);calls=0;
  bg.imageSmoothingEnabled=!pp;bg.fillStyle='#0b1222';bg.fillRect(0,0,GW,GH);calls++;
  const cx=pp?Math.round(cam.x):cam.x,cy=pp?Math.round(cam.y):cam.y,R=v=>pp?Math.round(v):v;
  for(const n of (playing?run:nodes)){
    const x=R(n.x-cx),y=R(n.y-cy);calls++;
    if(n.type==='StaticBody2D'){bg.fillStyle='#24324d';bg.fillRect(x,y,n.w,n.h);bg.fillStyle='#39D5FF';bg.fillRect(x,y,n.w,2)}
    else if(n.type==='Area2D'){bg.fillStyle='#F59E0B';bg.fillRect(x,y,n.w,n.h);bg.fillStyle='#fde68a';bg.fillRect(x+1,y+1,2,2)}
    else{const a=apOf(n),fr=a.frame(),sh=fr&&sheets[ANIMS[a.name].sheet];
      if(sh)blit(bg,sh,fr.f,R(x+n.w/2-sh.fw/2),R(y+n.h-sh.fh),n.flip);else{bg.fillStyle='#EF4444';bg.fillRect(x,y,n.w,n.h)}}
    if(!playing&&n===sel){bg.strokeStyle='#8B5CF6';bg.lineWidth=1;bg.strokeRect(Math.round(x)-.5,Math.round(y)-.5,n.w+1,n.h+1)}
  }
  const W=cv.width,H=cv.height,k=Math.min(W/GW,H/GH),s=pp?Math.max(1,Math.floor(k)):k;
  view={s,ox:pp?Math.floor((W-GW*s)/2):(W-GW*s)/2,oy:pp?Math.floor((H-GH*s)/2):(H-GH*s)/2};
  ctx.imageSmoothingEnabled=!pp;ctx.fillStyle='#05080f';ctx.fillRect(0,0,W,H);
  ctx.drawImage(buf,view.ox,view.oy,GW*s,GH*s);calls++;
  if(pp)setValid('ok','✓ Nearest neighbor, '+s+'× integer scale');
  else if(Math.abs(s-Math.round(s))>.01)setValid('warn','⚠ '+s.toFixed(2)+'× scale with smoothing: sprites will blur');
  else setValid('warn','⚠ Smoothing is on: pixel edges may soften');
}
const wpos=e=>{const r=cv.getBoundingClientRect(),k=cv.width/r.width;return{x:((e.clientX-r.left)*k-view.ox)/view.s+cam.x,y:((e.clientY-r.top)*k-view.oy)/view.s+cam.y}};
cv.oncontextmenu=e=>e.preventDefault();
cv.onpointerdown=e=>{
  cv.focus();if(playing)return;
  if(e.button===2){drag={pan:1,sx:e.clientX,cx:cam.x};cv.setPointerCapture(e.pointerId);return}
  const p=wpos(e),h=[...nodes].reverse().find(n=>p.x>=n.x&&p.x<=n.x+n.w&&p.y>=n.y&&p.y<=n.y+n.h);
  sel=h||null;refresh();if(h)drag={n:h,ox:p.x-h.x,oy:p.y-h.y};cv.setPointerCapture(e.pointerId);
};
cv.onpointermove=e=>{
  if(!drag)return;
  if(drag.pan){cam.x=Math.max(0,Math.min(640-GW,drag.cx-(e.clientX-drag.sx)/view.s*(cv.width/cv.getBoundingClientRect().width)));return}
  const p=wpos(e);drag.n.x=Math.round(p.x-drag.ox);drag.n.y=Math.round(p.y-drag.oy);
};
cv.onpointerup=()=>{if(drag&&drag.n)refresh();drag=null};

/* ================= Animation Studio ================= */
let curAnim='',curSheet='',aPlaying=true,selFrame=0;const ap=new AnimPlayer(),pv=$('#prev').getContext('2d');
const A=()=>ANIMS[curAnim];
const markData=()=>window.BiteMarkDirty?.();
function animRefresh(){
  const L=$('#animList');L.innerHTML='';Object.keys(ANIMS).forEach(n=>L.add(new Option(n)));L.value=curAnim;
  const S=$('#sheetSel');S.innerHTML='';Object.keys(sheets).forEach(n=>S.add(new Option(n)));S.value=curSheet;
  const s=sheets[curSheet],a=A();
  if(s){
    $('#sFw').value=s.fw;$('#sFh').value=s.fh;$('#sSp').value=s.sp;$('#sM').value=s.m;
    $('#sInfo').textContent=s.img.width+'×'+s.img.height+' px, '+s.cols+'×'+s.rows+' frames';
    drawSheet();
  }else{
    $('#sInfo').textContent='No sprite sheet yet. Import a PNG above, draw one in Pixel Art Studio, or use the Asset Store.';
    $('#sheetView').width=1;$('#sheetView').height=1;
  }
  if(a&&sheets[a.sheet]){
    $('#aMode').value=a.mode;$('#aFps').value=Math.round(1/a.frames[0]?.dur)||12;
    timeline();
  }else{
    $('#tl').innerHTML='';$('#aDur').value=100;
    $('#aInfo').textContent=a?'This animation needs a sprite sheet.':'Create an animation to add frames.';
  }
}
function timeline(){
  const a=A(),t=$('#tl');t.innerHTML='';if(!a)return;
  selFrame=Math.max(0,Math.min(selFrame,a.frames.length-1));
  const sh=sheets[a.sheet];
  if(!sh)return;
  a.frames.forEach((fr,i)=>{
    const c=el('canvas',{width:sh.fw,height:sh.fh});blit(c.getContext('2d'),sh,fr.f,0,0);
    t.append(el('div',{className:'th'+(i===selFrame?' sel':''),onclick:()=>{selFrame=i;aPlaying=false;$('#aPlay').textContent='Play';ap.i=i;ap.t=0;ap.done=false;timeline()}},c,el('div',{textContent:(i+1)+' · '+Math.round(fr.dur*1000)+'ms'})));
  });
  $('#aDur').value=a.frames[selFrame]?Math.round(a.frames[selFrame].dur*1000):100;
  $('#aInfo').textContent=a.frames.length+' frames, '+(a.frames.reduce((s,f)=>s+f.dur,0)).toFixed(2)+' s';
}
function drawSheet(){
  const s=sheets[curSheet],c=$('#sheetView');if(!s){c.width=1;c.height=1;return}
  const z=Math.max(1,Math.floor(380/s.img.width));c.width=s.img.width*z;c.height=s.img.height*z;
  const g=c.getContext('2d');g.imageSmoothingEnabled=false;g.drawImage(s.img,0,0,c.width,c.height);
  g.strokeStyle='#39D5FF99';g.fillStyle='#F8FAFC';g.font='10px sans-serif';
  for(let i=0;i<s.n;i++){const x=(s.m+(i%s.cols)*(s.fw+s.sp))*z,y=(s.m+Math.floor(i/s.cols)*(s.fh+s.sp))*z;g.strokeRect(x+.5,y+.5,s.fw*z-1,s.fh*z-1);g.fillText(i+1,x+3,y+11)}
  c.dataset.z=z;
}
$('#sheetView').onclick=e=>{
  const s=sheets[curSheet];if(!s){log('Import a sprite sheet first','w');return}
  const c=e.target,z=+c.dataset.z,r=c.getBoundingClientRect(),k=c.width/r.width;
  const px=(e.clientX-r.left)*k/z-s.m,py=(e.clientY-r.top)*k/z-s.m,col=Math.floor(px/(s.fw+s.sp)),row=Math.floor(py/(s.fh+s.sp));
  if(col<0||row<0||col>=s.cols||row>=s.rows)return;
  const a=A();if(!a){log('Create an animation first','w');return}
  if(a.sheet!==curSheet){log('This animation uses '+a.sheet+'. Create a new animation for '+curSheet,'w');return}
  a.frames.push({f:row*s.cols+col,dur:a.frames.at(-1)?.dur||.1});selFrame=a.frames.length-1;markData();timeline();
};
$('#animList').onchange=e=>{curAnim=e.target.value;curSheet=A().sheet;selFrame=0;ap.restart(curAnim);animRefresh()};
$('#sheetSel').onchange=e=>{curSheet=e.target.value;animRefresh()};
$('#bSlice').onclick=()=>{const s=sheets[curSheet];if(!s){log('Import a sprite sheet first','w');return}s.fw=Math.max(1,+$('#sFw').value);s.fh=Math.max(1,+$('#sFh').value);s.sp=Math.max(0,+$('#sSp').value);s.m=Math.max(0,+$('#sM').value);slice(s);markData();log('Sliced '+s.name+': '+s.n+' frames','ok');animRefresh()};
$('#bAuto').onclick=()=>{const s=sheets[curSheet];if(!s){log('Import a sprite sheet first','w');return}s.fh=s.img.height;s.fw=s.img.width%s.img.height===0?s.img.height:s.img.width;s.sp=s.m=0;slice(s);markData();animRefresh()};
$('#bNewAnim').onclick=()=>{
  const s=sheets[curSheet];
  if(!s){log('Import a sprite sheet first: Sprite sheet above, Pixel Art Studio > Send to game assets, or the Asset Store.','w');return}
  const n=$('#newName').value.trim()||'Anim'+(Object.keys(ANIMS).length+1);
  if(ANIMS[n]&&!confirm('Replace animation "'+n+'"?'))return;
  ANIMS[n]={sheet:curSheet,mode:'loop',frames:Array.from({length:s.n},(_,f)=>({f,dur:.1}))};curAnim=n;selFrame=0;ap.restart(n);$('#newName').value='';markData();log('Animation "'+n+'" created from '+s.n+' frames','ok');animRefresh();
};
$('#sheetFile').onchange=e=>{
  const f=e.target.files[0];if(!f)return;const img=new Image();
  img.onload=()=>{const name=f.name.replace(/\.\w+$/,'');const s=addSheet(name,img,img.width%img.height===0?img.height:img.width,img.height);curSheet=name;markData();log('Imported '+name+' ('+img.width+'×'+img.height+', nearest filtering)','ok');animRefresh()};
  img.src=URL.createObjectURL(f);
};
$('#aMode').onchange=e=>{const a=A();if(!a)return;a.mode=e.target.value;ap.restart(curAnim);markData()};
$('#aFps').oninput=e=>{const a=A();if(!a)return;const f=Math.max(1,+e.target.value||12);a.frames.forEach(x=>x.dur=1/f);markData();timeline()};
$('#aDur').oninput=e=>{const a=A(),fr=a&&a.frames[selFrame];if(fr){fr.dur=Math.max(.01,+e.target.value/1000);markData();timeline()}};
$('#fDup').onclick=()=>{const a=A();if(!a||!a.frames.length)return;a.frames.splice(selFrame+1,0,{...a.frames[selFrame]});selFrame++;markData();timeline()};
$('#fDel').onclick=()=>{const a=A();if(!a||a.frames.length<2)return;a.frames.splice(selFrame,1);selFrame=Math.max(0,selFrame-1);markData();timeline()};
const mv=d=>{const a=A();if(!a)return;const f=a.frames,j=selFrame+d;if(j<0||j>=f.length)return;[f[selFrame],f[j]]=[f[j],f[selFrame]];selFrame=j;markData();timeline()};
$('#fL').onclick=()=>mv(-1);$('#fR').onclick=()=>mv(1);
$('#aPlay').onclick=()=>{aPlaying=!aPlaying;$('#aPlay').textContent=aPlaying?'Pause':'Play';if(aPlaying){ap.done=false}};
const stepF=d=>{const a=A();if(!a||!a.frames.length)return;aPlaying=false;$('#aPlay').textContent='Play';const n=a.frames.length;ap.i=(ap.i+d+n)%n;ap.t=0;ap.done=false;selFrame=ap.i;timeline()};
$('#aPrev').onclick=()=>stepF(-1);$('#aNext').onclick=()=>stepF(1);
function renderAnim(){
  const a=A(),sh=a&&sheets[a.sheet],fr=sh&&ap.frame();pv.clearRect(0,0,192,192);pv.imageSmoothingEnabled=false;
  if(!fr)return;const z=Math.max(1,Math.floor(192/Math.max(sh.fw,sh.fh)));
  pv.save();pv.translate(Math.floor((192-sh.fw*z)/2),Math.floor((192-sh.fh*z)/2));pv.scale(z,z);
  if($('#onion').checked&&a.frames.length>1){pv.globalAlpha=.35;blit(pv,sh,a.frames[(ap.i+a.frames.length-1)%a.frames.length].f,0,0)}
  pv.globalAlpha=1;blit(pv,sh,fr.f,0,0);pv.restore();
  $$('#tl .th').forEach((e,i)=>e.classList.toggle('cur',i===ap.i));
}

/* ================= Pixel Art Studio ================= */
const PS=32,PZ=14,px=$('#px'),pctx=px.getContext('2d'),art=el('canvas',{width:PS,height:PS}),ag=art.getContext('2d',{willReadFrequently:true});
let tool='pencil',col='#39d5ff',pdown=null,snap=null,sentN=0;
['#090D18','#151F32','#24324d','#94A3B8','#F8FAFC','#39D5FF','#8B5CF6','#22C55E','#F59E0B','#EF4444','#f1c9a5','#7c4a2d','#ec4899','#14b8a6','#1d4ed8','#fde68a'].forEach(c=>
  $('#pal').append(el('i',{style:'background:'+c,title:c,onclick:()=>{col=c;$('#pcol').value=c}})));
$('#pcol').oninput=e=>col=e.target.value;
$$('#tools [data-t]').forEach(b=>b.onclick=()=>{tool=b.dataset.t;$$('#tools [data-t]').forEach(x=>x.classList.toggle('on',x===b))});
function pdraw(){
  pctx.imageSmoothingEnabled=false;pctx.clearRect(0,0,px.width,px.height);pctx.drawImage(art,0,0,PS*PZ,PS*PZ);
  if($('#grid').checked){pctx.strokeStyle='#ffffff18';pctx.beginPath();for(let i=0;i<=PS;i++){pctx.moveTo(i*PZ+.5,0);pctx.lineTo(i*PZ+.5,PS*PZ);pctx.moveTo(0,i*PZ+.5);pctx.lineTo(PS*PZ,i*PZ+.5)}pctx.stroke()}
  const p=$('#pv').getContext('2d');p.clearRect(0,0,160,128);p.imageSmoothingEnabled=false;p.drawImage(art,4,4);p.drawImage(art,32,0,128,128);
}
const dot=(x,y,erase)=>{if(x<0||y<0||x>=PS||y>=PS)return;if(erase)ag.clearRect(x,y,1,1);else{ag.fillStyle=col;ag.fillRect(x,y,1,1)}};
function line(x0,y0,x1,y1,er){const dx=Math.abs(x1-x0),dy=-Math.abs(y1-y0),sx=x0<x1?1:-1,sy=y0<y1?1:-1;let e=dx+dy;for(;;){dot(x0,y0,er);if(x0===x1&&y0===y1)break;const e2=2*e;if(e2>=dy){e+=dy;x0+=sx}if(e2<=dx){e+=dx;y0+=sy}}}
function flood(x,y){
  const im=ag.getImageData(0,0,PS,PS),d=im.data,i0=(y*PS+x)*4,t=[d[i0],d[i0+1],d[i0+2],d[i0+3]];
  ag.fillStyle=col;ag.fillRect(0,0,0,0);const c=el('canvas',{width:1,height:1}).getContext('2d');c.fillStyle=col;c.fillRect(0,0,1,1);const n=c.getImageData(0,0,1,1).data;
  if(t.every((v,k)=>v===n[k]))return;const st=[[x,y]];
  while(st.length){const [a,b]=st.pop();if(a<0||b<0||a>=PS||b>=PS)continue;const i=(b*PS+a)*4;
    if(d[i]!==t[0]||d[i+1]!==t[1]||d[i+2]!==t[2]||d[i+3]!==t[3])continue;d[i]=n[0];d[i+1]=n[1];d[i+2]=n[2];d[i+3]=255;st.push([a+1,b],[a-1,b],[a,b+1],[a,b-1])}
  ag.putImageData(im,0,0);
}
const ppos=e=>{const r=px.getBoundingClientRect();return[Math.floor((e.clientX-r.left)*px.width/r.width/PZ),Math.floor((e.clientY-r.top)*px.height/r.height/PZ)]};
px.onpointerdown=e=>{
  const [x,y]=ppos(e);px.setPointerCapture(e.pointerId);pdown=[x,y];snap=ag.getImageData(0,0,PS,PS);
  if(tool==='pencil'||tool==='eraser')dot(x,y,tool==='eraser');
  else if(tool==='fill')flood(x,y);
  else if(tool==='pick'){const d=ag.getImageData(x,y,1,1).data;if(d[3]){col='#'+[...d.slice(0,3)].map(v=>v.toString(16).padStart(2,'0')).join('');$('#pcol').value=col}}
  pdraw();
};
px.onpointermove=e=>{
  if(!pdown)return;const [x,y]=ppos(e);
  if(tool==='pencil'||tool==='eraser'){line(pdown[0],pdown[1],x,y,tool==='eraser');pdown=[x,y]}
  else if(['line','rect','circle'].includes(tool)){
    ag.putImageData(snap,0,0);const [a,b]=pdown;
    if(tool==='line')line(a,b,x,y);
    else if(tool==='rect'){line(a,b,x,b);line(x,b,x,y);line(x,y,a,y);line(a,y,a,b)}
    else{const r=Math.hypot(x-a,y-b);for(let i=0;i<PS;i++)for(let j=0;j<PS;j++)if(Math.abs(Math.hypot(i-a,j-b)-r)<.5)dot(i,j)}
  }
  pdraw();
};
px.onpointerup=()=>{if(pdown&&tool!=='pick')markData();pdown=null};
$('#grid').onchange=pdraw;
$('#pClear').onclick=()=>{ag.clearRect(0,0,PS,PS);markData();pdraw()};
$('#pSend').onclick=()=>{
  const c=el('canvas',{width:PS,height:PS});c.getContext('2d').drawImage(art,0,0);const n='Sprite_'+(++sentN);
  addSheet(n,c,PS,PS);ANIMS[n]={sheet:n,mode:'loop',frames:[{f:0,dur:.1}]};curSheet=n;curAnim=n;markData();log('Sent "'+n+'" to assets. Pick it as an animation on a node.','ok');
};
$('#pPng').onclick=()=>{const a=el('a',{href:art.toDataURL(),download:'sprite.png'});a.click()};
ag.fillStyle='#8B5CF6';[[15,6],[16,6],[14,7],[17,7],[14,8],[17,8],[15,9],[16,9]].forEach(([x,y])=>ag.fillRect(x,y,1,1));pdraw();

/* ================= Profiler ================= */
const P={ft:[],upd:0,ren:0};let statT=0;
function renderProf(now){
  const g=$('#graph').getContext('2d'),W=520,H=160;g.clearRect(0,0,W,H);
  g.strokeStyle='#24324d';g.beginPath();g.moveTo(0,H-H*(16.7/50));g.lineTo(W,H-H*(16.7/50));g.stroke();
  g.strokeStyle='#39D5FF';g.beginPath();P.ft.forEach((v,i)=>{const x=i*W/119,y=H-Math.min(H,v/50*H);i?g.lineTo(x,y):g.moveTo(x,y)});g.stroke();
  if(now-statT<250)return;statT=now;
  const avg=P.ft.reduce((a,b)=>a+b,0)/Math.max(1,P.ft.length),L=playing?run:nodes,mem=performance.memory;
  const rows=[['FPS',Math.round(1000/avg)],['Frame time',avg.toFixed(1)+' ms'],['Update time',P.upd.toFixed(2)+' ms'],['Render time',P.ren.toFixed(2)+' ms'],['Objects',L.length],['Sprites',L.filter(n=>apOf(n).frame()).length],['Draw calls',calls],['Animations',Object.keys(ANIMS).length],['Memory',mem?Math.round(mem.usedJSHeapSize/1048576)+' MB':'not available']];
  $('#stats').innerHTML='';rows.forEach(([k,v])=>$('#stats').append(el('div',{},el('span',{textContent:k}),el('b',{textContent:v}))));
}

/* ================= Shell & main loop ================= */
let ws='game';
$$('#tabs button').forEach(b=>b.onclick=()=>{ws=b.dataset.ws;$$('#tabs button').forEach(x=>x.classList.toggle('on',x===b));$$('.ws').forEach(s=>s.classList.toggle('on',s.id==='ws-'+ws));if(ws==='game')refresh();if(ws==='anim')animRefresh();if(ws==='pixel')pdraw()});
/* five colour themes, shared by the home screen and the editor header */
const ACCENTS=[['cyan','Cyan','#39D5FF'],['violet','Violet','#A78BFA'],['emerald','Emerald','#34D399'],['amber','Amber','#FBBF24'],['rose','Rose','#FB7185']];
function setAccent(id){
  if(!ACCENTS.some(a=>a[0]===id))id='cyan';
  document.documentElement.dataset.accent=id;
  $$('.sw').forEach(b=>{const on=b.dataset.accent===id;b.classList.toggle('on',on);b.setAttribute('aria-pressed',String(on))});
  try{localStorage.setItem('bite.accent',id)}catch{}
}
$$('[data-accpick]').forEach(box=>{
  if(box.children.length)return;
  for(const [id,label,hex] of ACCENTS){
    const b=el('button',{className:'sw',title:label+' theme',type:'button'});
    b.dataset.accent=id;b.style.background=hex;b.setAttribute('aria-label',label+' theme');
    b.onclick=()=>setAccent(id);box.append(b);
  }
});
try{setAccent(localStorage.getItem('bite.accent')||'cyan')}catch{setAccent('cyan')}
function applyTheme(light,save){
  document.documentElement.dataset.theme=light?'light':'';
  $('#theme').textContent=light?'Dark theme':'Light theme';
  if(save){try{localStorage.setItem('bite.theme',light?'light':'dark')}catch{}}
}
$('#theme').onclick=()=>applyTheme(document.documentElement.dataset.theme!=='light',true);
try{applyTheme(localStorage.getItem('bite.theme')==='light',false)}catch{applyTheme(false,false)}
let last=performance.now(),acc=0;
function frame(t){
  const dt=t-last;last=t;acc+=Math.min(dt,100)/1000;const u0=performance.now();let n=0;
  while(acc>=STEP&&n++<6){gameStep();if(aPlaying)ap.update(STEP,+$('#aSpd').value||1);acc-=STEP}
  if(acc>=STEP)acc=0;
  const u1=performance.now();
  if(!document.hidden){if(ws==='game')renderGame();else if(ws==='anim')renderAnim()}
  P.upd=u1-u0;P.ren=performance.now()-u1;P.ft.push(dt);if(P.ft.length>120)P.ft.shift();
  if(ws==='prof')renderProf(t);
  requestAnimationFrame(frame);
}
demo();log('BiteEngine 3.0 ready. Fixed 60 Hz simulation.','ok');
requestAnimationFrame(frame);
