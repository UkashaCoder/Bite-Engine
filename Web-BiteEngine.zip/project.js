'use strict';
(()=>{
const KEY='bite.proj.',IDX='bite.projects',DEF=JSON.stringify(ANIMS),L=window.BiteLib;
const HOME=$('#home');
let proj={name:'Untitled project',named:false,logo:null},dirty=false,homeQ='',logoKey='';
const ls=(k,v)=>{try{if(v===undefined)return localStorage.getItem(k);v===null?localStorage.removeItem(k):localStorage.setItem(k,v);return true}catch{return false}};
const names=()=>{try{return JSON.parse(ls(IDX)||'[]')}catch{return[]}};
const note=(m,c='ok')=>{log(m,c);const t=el('div',{className:'toast',textContent:m});document.body.append(t);setTimeout(()=>t.remove(),3500)};
function title(){
  $('#proj').textContent=proj.name+(dirty?' *':'');document.title=(HOME.classList.contains('off')?proj.name+' - BiteEngine':'BiteEngine 3.0');
  const im=$('#projLogo'),k=proj.name+'|'+JSON.stringify(proj.logo||null);
  if(im&&k!==logoKey){logoKey=k;im.src=logoUrl(proj.logo,proj.name)}
}
window.BiteMarkDirty=()=>{if(!dirty){dirty=true;title()}};
window.BiteProjectName=()=>proj.name;

function serialize(){
  const sh={};
  for(const [n,s] of Object.entries(sheets)){
    const o={fw:s.fw,fh:s.fh,m:s.m,sp:s.sp};
    if(n==='Player_Run')o.builtin=1;else if(s.src)o.store=s.src;
    else try{const c=el('canvas',{width:s.img.width,height:s.img.height});c.getContext('2d').drawImage(s.img,0,0);o.data=c.toDataURL()}catch{o.skip=1}
    sh[n]=o;
  }
  const out={format:'biteproj',version:1,name:proj.name,logo:proj.logo||null,saved:new Date().toISOString(),nodes,nid,sheets:sh,anims:ANIMS,lib:L.get(),assets:window.BiteAssets?BiteAssets.data():{folders:[],files:[]}};
  if(window.BiteScenes)Object.assign(out,BiteScenes.data());
  if(window.BiteMenus)Object.assign(out,BiteMenus.data());
  return out;
}
function save(){
  const s=JSON.stringify(serialize());
  if(!ls(KEY+proj.name,s)){note('Could not save: browser storage is full. Use Download .biteproj instead.','e');return false}
  const n=names();if(!n.includes(proj.name)){n.push(proj.name);ls(IDX,JSON.stringify(n))}
  ls('bite.last',proj.name);proj.named=true;dirty=false;title();note('Saved project "'+proj.name+'"');
  if(!HOME.classList.contains('off'))homeRefresh();
  return true;
}
const saveCmd=()=>proj.named?save():saveAs();
async function load(d){
  if(playing)$('#bStop').click();
  for(const n of Object.keys(sheets))if(n!=='Player_Run')delete sheets[n];
  for(const k of Object.keys(ANIMS))delete ANIMS[k];
  Object.assign(ANIMS,JSON.parse(DEF),d.anims||{});
  for(const [n,o] of Object.entries(d.sheets||{})){
    if(o.builtin)continue;
    const src=o.data||(o.store&&L.url(o.store));if(!src)continue;
    await new Promise(r=>{const img=new Image();img.onload=()=>{const s=addSheet(n,img,o.fw,o.fh,o.m,o.sp);if(o.store)s.src=o.store;r()};img.onerror=r;img.src=src});
  }
  for(const [k,a] of Object.entries(ANIMS))if(!sheets[a.sheet])delete ANIMS[k];
  if(window.BiteScenes)BiteScenes.load(d);
  else{nodes=d.nodes||[];nid=d.nid||Math.max(0,...nodes.map(n=>n.id))+1}
  if(window.BiteMenus)BiteMenus.load(d.menus);
  sel=null;aps.clear();cam.x=0;L.set(d.lib||[]);
  if(window.BiteAssets)BiteAssets.load(d.assets);
  const dock=document.getElementById('animDock');if(dock)dock.classList.remove('on');
  curAnim=Object.keys(ANIMS)[0]||'';curSheet=ANIMS[curAnim]?ANIMS[curAnim].sheet:'';selFrame=0;ap.restart(curAnim);
  proj={name:d.name||'Untitled project',named:true,logo:d.logo||templateLogo(d.name)};refresh();animRefresh();dirty=false;title();
}

/* New projects always start from a scene tree, never an empty file.
   Both templates include a Node2D root, like Godot's 2D scene root. */
function node2D(id,name,x=0,y=0,extra={}){
  return {id,type:'Node2D',name,x,y,w:8,h:8,anim:'Idle',flip:false,speed:1,fps:12,...extra};
}
function templateNodes(tpl){
  const root=node2D(1,'Root');
  if(tpl!=='starter')return{nodes:[root],nid:2};
  const player={id:2,type:'CharacterBody2D',name:'Player',x:120,y:96,w:14,h:24,anim:'Idle',flip:false,speed:1,fps:12,skin:'Mask Dude',run:100,jump:270,dj:true,grav:1,parent:1};
  const ground={id:3,type:'StaticBody2D',name:'Ground',x:0,y:152,w:320,h:20,anim:'Idle',flip:false,speed:1,fps:12,col:'#24324d',parent:1};
  const camera={id:4,type:'Camera2D',name:'Camera2D',x:0,y:0,w:16,h:16,anim:'Idle',flip:false,speed:1,fps:12,follow:true,smooth:.12,limit:true,parent:1};
  return{nodes:[root,player,ground,camera],nid:5};
}
async function fresh(name,tpl){
  if(String(tpl).startsWith('game:')){
    const data=buildGameTemplate(tpl.slice(5),uniqueProjectName(name));
    await load(data);sel=nodes[0]||null;refresh();
    save();hideHome();$('[data-ws=game]').click();
    log('Created "'+data.name+'": 10 levels, game menus and music. Press Play to start.','ok');
    return;
  }
  const t=templateNodes(tpl);
  await load({name,nodes:t.nodes,nid:t.nid,sheets:{},anims:JSON.parse(DEF),lib:[]});
  sel=nodes[0]||null;refresh();
  save();hideHome();$('[data-ws=game]').click();
  log('New project "'+name+'" ready with a Node2D root. Right-click the Scene tree to add child nodes.','ok');
}
function uniqueProjectName(base){
  base=String(base||'My Game').trim()||'My Game';
  const used=names();let name=base,i=2;
  while(used.includes(name)||ls(KEY+name))name=base+' '+(i++);
  return name;
}

/* ---------- ready-made games: 3 templates × 10 levels ---------- */
const TDEF={
  Node2D:{w:8,h:8},Camera2D:{w:16,h:16,follow:true,smooth:.12,limit:true},Label:{text:'Label',size:8,col:'#ffffff',w:40,h:10},
  CharacterBody2D:{w:14,h:24,skin:'Mask Dude',run:100,jump:270,dj:true,grav:1,maxHp:3},StaticBody2D:{w:64,h:12},Area2D:{w:16,h:16,tex:''},
  Enemy:{w:36,h:30,skin:'AngryPig',behavior:'patrol',dir:-1,speed:36,range:96,sight:150,dmg:1,hp:2,points:10,stomp:true,ledge:true,fps:10},
  MovingPlatform:{w:64,h:12,axis:'x',dist:96,speed:40,phase:0},Spike:{w:32,h:16,dmg:1,respawn:false},Spring:{w:28,h:28,power:420},
  FireTrap:{w:16,h:32,dmg:1,cycle:true,startOn:true,onTime:1.4,offTime:1.1},
  BreakableBox:{w:28,h:24,box:1,hits:1,points:5,drop:false},
  StartCheckpoint:{w:64,h:64,active:true,heal:true,label:''},Checkpoint:{w:64,h:64,heal:true,bonus:0,reusable:false,label:''},
  EndCheckpoint:{w:64,h:64,requireCoins:false,bonus:0,winText:'LEVEL COMPLETE!',next:'',label:''},
  Sound:{w:24,h:24,sound:'assets/sounds/jump.wav',volume:.8,loop:false,autoplay:false,trigger:'collision',key:' ',once:false},
  ParallaxBackground:{tex:'Backgrounds/Green.png',sx:0,sy:24,w:0,h:0}
};
const FRUIT_NAMES=['Apple','Bananas','Cherries','Kiwi','Melon','Orange','Pineapple','Strawberry'];
const GAME_TEMPLATES=[
  {id:'platformer',name:'Pixel Quest',tag:'Platformer',badge:'PQ',desc:'Run, jump and collect fruit across 10 green levels with enemies, spikes, springs and checkpoints.',accent:'#39D5FF',c1:'#0e3a52',c2:'#1d4ed8',bg:'Backgrounds/Green.png',sx:7,sy:10,ground:'#24324d',platform:'#334155',player:'Mask Dude',enemies:['AngryPig','Bunny','Chicken','Duck'],music:.45,fly:false},
  {id:'cave',name:'Cave Escape',tag:'Action',badge:'CE',desc:'Escape 10 dark caverns full of fire traps, flying bats, spikes and moving platforms.',accent:'#F59E0B',c1:'#2b1c5e',c2:'#7c3aed',bg:'Backgrounds/Purple.png',sx:9,sy:12,ground:'#1f2937',platform:'#374151',player:'Ninja Frog',enemies:['Bat','Ghost','Skull','BlueBird'],music:.4,fly:true},
  {id:'sky',name:'Sky Hopper',tag:'Coin collector',badge:'SH',desc:'Bounce between floating islands and collect every coin across 10 sky levels. Springs and boxes included.',accent:'#22C55E',c1:'#0e3a52',c2:'#0e7490',bg:'Backgrounds/Blue.png',sx:5,sy:8,ground:'#334155',platform:'#475569',player:'Pink Man',enemies:['BlueBird','Bee','Duck'],music:.45,fly:true,requireCoins:true}
];
const tNode=(id,type,props)=>Object.assign({id,type,name:type,x:0,y:0,w:16,h:16,anim:'Idle',flip:false,speed:1,fps:12,rotation:0,alpha:1},TDEF[type]||{},props||{});
function templateLevel(tpl,n){
  const W=900+n*40,goalX=W-96,nodes=[];
  let id=1,coinNo=0;
  const root=tNode(id++,'Node2D',{name:'Root',w:8,h:8});nodes.push(root);
  const put=(type,props={})=>{const nd=tNode(id++,type,Object.assign({parent:1},props));nodes.push(nd);return nd};
  const coin=(x,y)=>put('Area2D',{name:'Coin '+(++coinNo),x:Math.round(x),y:Math.round(y),w:16,h:16,tex:'Items/Fruits/'+FRUIT_NAMES[(coinNo-1)%FRUIT_NAMES.length]+'.png'});
  put('ParallaxBackground',{name:'Sky',tex:tpl.bg,sx:tpl.sx,sy:tpl.sy});
  put('StaticBody2D',{name:'Ground',x:0,y:160,w:W,h:20,col:tpl.ground});
  put('CharacterBody2D',{name:'Player',x:120,y:136,skin:tpl.player,run:105,jump:280,dj:true,grav:1,maxHp:3});
  put('StartCheckpoint',{name:'Start',x:24,y:96,active:true,heal:true,label:'START'});
  put('Camera2D',{name:'Camera2D'});
  put('Sound',{name:'Music',x:8,y:8,sound:'assets/sounds/music.ogg',volume:tpl.music,loop:true,trigger:'start',autoplay:true});
  put('Label',{name:'LevelTitle',x:24,y:16,w:90,h:12,text:'LEVEL '+n,size:10,col:tpl.accent});
  put('Label',{name:'Hint',x:24,y:32,w:200,h:10,text:'A/D move · Space jump · Esc menu',size:7,col:'#94A3B8'});
  put('EndCheckpoint',{name:'Goal',x:goalX,y:96,next:n<10?'Level '+(n+1):'',autoNext:n<10,delay:1.4,winText:n<10?'LEVEL '+n+' COMPLETE!':'YOU WIN THE GAME!',bonus:50*n,requireCoins:!!tpl.requireCoins,label:n<10?'GOAL':'FINISH'});
  if(n>=3)put('Checkpoint',{name:'Checkpoint',x:Math.round(W*.5),y:96,bonus:20,label:'CHECKPOINT'});
  /* floating platforms, always within jump reach */
  const plats=2+Math.min(6,n),pSpan=(W-460)/Math.max(1,plats-1);
  for(let k=0;k<plats;k++){
    const x=Math.round(230+k*pSpan),y=112+(k%3)*8;
    if(tpl.id==='cave'&&k%3===2)put('MovingPlatform',{name:'Moving platform '+(k+1),x,y,w:72,h:12,axis:k%2?'y':'x',dist:64,speed:34,phase:k*.4});
    else put('StaticBody2D',{name:'Platform '+(k+1),x,y,w:72,h:12,col:tpl.platform});
    if((tpl.requireCoins||k%2===0)&&x<W*.6)coin(x+28,y-24);
  }
  /* springs with coins above, in the first half */
  const springs=tpl.id==='sky'?[.3,.42]:[.32];
  springs.forEach((f,k)=>{
    const x=Math.round(W*f);
    put('Spring',{name:'Spring '+(k+1),x,y:132,power:430});
    coin(x+6,110);coin(x+6,80);if(tpl.requireCoins)coin(x+6,50);
  });
  /* ground coins, kept clear of the hazard band */
  for(let k=0;k<4;k++)coin(200+k*((W*.4-200)/3),130);
  /* enemies */
  const en=Math.min(6,1+Math.floor(n/2)),eSpan=(W-560)/Math.max(1,en-1);
  for(let k=0;k<en;k++){
    const x=Math.round(320+k*eSpan),skin=tpl.enemies[k%tpl.enemies.length];
    if(tpl.fly&&k%2===1)put('Enemy',{name:'Flyer '+(k+1),x,y:70+(k%3)*16,skin,behavior:'fly',speed:34,range:0,hp:1,points:15});
    else put('Enemy',{name:'Enemy '+(k+1),x,y:130,skin,behavior:'patrol',speed:30+n*2,range:80,sight:150,hp:2,points:10});
  }
  /* breakable boxes near the start */
  const boxes=tpl.id==='sky'?Math.min(3,Math.floor(n/3)):(n>=5?1:0);
  for(let k=0;k<boxes;k++)put('BreakableBox',{name:'Box '+(k+1),x:290+k*88,y:136,box:1+(k%3),hits:1,points:5});
  /* timed fire traps */
  const fire=tpl.id==='cave'?Math.min(2,Math.floor(n/3)):(n>=8?1:0);
  for(let k=0;k<fire;k++)put('FireTrap',{name:'Fire '+(k+1),x:Math.round(W*.36+k*78),y:128});
  /* spikes in the second half, spaced for single jumps */
  const sp=tpl.id==='cave'?Math.min(4,Math.floor(n/2)):tpl.id==='sky'?Math.min(2,Math.floor(n/4)):Math.min(3,Math.floor(n/3));
  const s0=tpl.id==='cave'?.62:.66,band=tpl.id==='cave'?.22:.18,sSpan=W*band/Math.max(1,sp-1);
  for(let k=0;k<sp;k++)put('Spike',{name:'Spike '+(k+1),x:Math.round(W*s0+k*sSpan),y:144});
  return{id:'s'+n,name:'Level '+n,nodes};
}
function templateMenus(t){
  return{
    main:{enabled:true,showOnStart:true,title:t.name.toUpperCase(),subtitle:t.tag.toUpperCase()+' · 10 LEVELS',accent:t.accent,items:{play:true,levels:true,settings:true,editor:true}},
    pause:{enabled:true,title:'PAUSED',subtitle:'Level select and settings',accent:t.accent,items:{resume:true,restart:true,levels:true,main:true,settings:true,editor:true}},
    over:{enabled:true,title:'GAME OVER',subtitle:'Try again or pick another level',accent:'#EF4444',items:{retry:true,levels:true,main:true,editor:true}}
  };
}
function buildGameTemplate(id,name){
  const tpl=GAME_TEMPLATES.find(t=>t.id===id);
  if(!tpl)throw new Error('Unknown game template');
  const scenes=Array.from({length:10},(_,i)=>templateLevel(tpl,i+1));
  return{format:'biteproj',version:1,name,logo:{a:tpl.accent,c1:tpl.c1,c2:tpl.c2,b:tpl.badge},saved:new Date().toISOString(),nodes:scenes[0].nodes,
    nid:scenes.reduce((m,s)=>Math.max(m,...s.nodes.map(nd=>nd.id)),0)+1,
    sheets:{},anims:JSON.parse(DEF),lib:[],assets:{folders:[],files:[]},
    scenes,current:scenes[0].id,menus:templateMenus(tpl)};
}
function createGameTemplate(id){
  const tpl=GAME_TEMPLATES.find(t=>t.id===id);if(!tpl)return;
  if(dirty&&!confirm('You have unsaved changes. Create the "'+tpl.name+'" template anyway?'))return;
  fresh(tpl.name,'game:'+id);
}
function renderTemplateCards(){
  const box=$('#homeTemplates');if(!box)return;box.innerHTML='';
  for(const t of GAME_TEMPLATES){
    box.append(el('div',{className:'pcard tplcard',onclick:()=>createGameTemplate(t.id)},
      el('div',{className:'pthumb'},el('img',{className:'plogo',src:logoUrl({a:t.accent,c1:t.c1,c2:t.c2,b:t.badge},t.name),alt:''})),
      el('h3',{textContent:t.name}),
      el('p',{className:'pmeta',textContent:t.tag+' · 10 levels · game menu'}),
      el('p',{className:'tdesc',textContent:t.desc}),
      el('div',{className:'pactions'},el('button',{textContent:'Create game',className:'pri',onclick:e=>{e.stopPropagation();createGameTemplate(t.id)}}))));
  }
}

/* ---------- project manager / home ---------- */
function hideHome(){HOME.classList.add('off');title()}
function showHome(){
  if(dirty&&!confirm('You have unsaved changes. Continue to the project manager anyway?'))return false;
  HOME.classList.remove('off');homeQ='';$('#homeSearch').value='';homeRefresh();title();return true;
}
function savedProjects(){
  return names().map(n=>{
    try{
      const d=JSON.parse(ls(KEY+n));if(!d)return null;
      const scenes=Array.isArray(d.scenes)&&d.scenes.length?d.scenes:null;
      return{name:n,saved:d.saved||'',logo:d.logo||templateLogo(n),scenes:scenes?scenes.length:1,nodes:scenes?scenes.reduce((a,s)=>a+((s.nodes||[]).length),0):(d.nodes||[]).length};
    }catch{return null}
  }).filter(Boolean).sort((a,b)=>String(b.saved).localeCompare(String(a.saved)));
}
function homeRefresh(){
  const grid=$('#homeProjects');if(!grid)return;grid.innerHTML='';
  const all=savedProjects(),q=homeQ.trim().toLowerCase(),list=q?all.filter(p=>p.name.toLowerCase().includes(q)):all;
  $('#homeCount').textContent=all.length;
  const add=el('div',{className:'pcard new',onclick:()=>newDlg()},el('div',{className:'plus',textContent:'+'}),el('b',{textContent:'New project'}),el('span',{className:'dim',textContent:'Start with a Node2D scene root'}));
  grid.append(add);
  if(!list.length&&all.length){
    grid.append(el('div',{className:'homeEmpty',textContent:'No projects match "'+homeQ+'".'}));
    return;
  }
  if(!all.length){
    grid.append(el('div',{className:'homeEmpty',textContent:'No saved projects yet. Create your first 2D game with the button above.'}));
    return;
  }
  for(const p of list){
    const date=p.saved?new Date(p.saved).toLocaleDateString(undefined,{month:'short',day:'numeric',year:'numeric'}):'Not saved';
    const card=el('div',{className:'pcard',onclick:()=>openHomeProject(p.name)},
      el('div',{className:'pthumb'},el('img',{className:'plogo',src:logoUrl(p.logo,p.name),alt:''})),
      el('h3',{textContent:p.name}),
      el('p',{className:'pmeta',textContent:p.nodes+' node'+(p.nodes===1?'':'s')+' · '+p.scenes+' scene'+(p.scenes===1?'':'s')+' · '+date}),
      el('div',{className:'pactions'},
        el('button',{textContent:'Open',className:'pri',onclick:e=>{e.stopPropagation();openHomeProject(p.name)}}),
        el('button',{textContent:'Download',onclick:e=>{e.stopPropagation();downloadByName(p.name)}}),
        el('button',{textContent:'Delete',className:'danger',onclick:e=>{e.stopPropagation();deleteProject(p.name)}})));
    grid.append(card);
  }
}
async function openHomeProject(name){
  if(dirty&&!confirm('You have unsaved changes. Open "'+name+'" anyway?'))return;
  const raw=ls(KEY+name);if(!raw){note('That project is no longer in this browser','e');homeRefresh();return}
  try{
    await load(JSON.parse(raw));hideHome();$('[data-ws=game]').click();
    log('Opened "'+name+'"','ok');
  }catch{note('That project could not be read','e')}
}
function deleteProject(name){
  if(!confirm('Delete "'+name+'" from this browser?'))return;
  ls(KEY+name,null);ls(IDX,JSON.stringify(names().filter(x=>x!==name)));if(ls('bite.last')===name)ls('bite.last',null);
  note('Deleted "'+name+'"','w');homeRefresh();
}
function downloadByName(name){
  try{
    const d=JSON.parse(ls(KEY+name));if(!d)throw 0;
    if(!d.logo){d.logo=logoFor(null,name);ls(KEY+name,JSON.stringify(d));homeRefresh()}
    downloadDlg(d,name);
  }catch{note('That project could not be read','e')}
}

/* ---------- project logos ---------- */
const LOGO_PALETTES=[
  ['#39D5FF','#0e3a52','#1d4ed8'],['#F59E0B','#2b1c5e','#7c3aed'],['#22C55E','#0e3a52','#0e7490'],
  ['#EC4899','#3b0764','#be185d'],['#A3E635','#14532d','#4d7c0f'],['#F97316','#431407','#b45309'],
  ['#8B5CF6','#1e1b4b','#6d28d9'],['#06B6D4','#083344','#155e75']
];
const logoHash=s=>{let h=0;for(const c of String(s))h=(h*31+c.charCodeAt(0))>>>0;return h};
const logoEsc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]));
function logoBadge(name){
  const w=String(name||'Game').trim().split(/\s+/).filter(Boolean);
  let b=w.map(x=>x[0]).join('');
  if(b.length<2)b=(w[0]||'2D').slice(0,2);
  return b.slice(0,2).toUpperCase();
}
function templateLogo(name){
  const t=GAME_TEMPLATES.find(t=>t.name.toLowerCase()===String(name||'').toLowerCase());
  return t?{a:t.accent,c1:t.c1,c2:t.c2,b:t.badge}:null;
}
function logoFor(logo,name){
  const p=LOGO_PALETTES[logoHash(name||'Game')%LOGO_PALETTES.length],o=logo||templateLogo(name)||{};
  return{a:o.a||p[0],c1:o.c1||p[1],c2:o.c2||p[2],b:String(o.b||logoBadge(name)).slice(0,3).toUpperCase()};
}
const LOGO_URLS=new Map();
function logoUrl(logo,name){
  const g=logoFor(logo,name),nm=String(name||'Untitled project'),key=g.a+g.c1+g.c2+g.b+'|'+nm;
  let u=LOGO_URLS.get(key);if(u)return u;
  const short=logoEsc(nm.length>26?nm.slice(0,25)+'…':nm),bs=g.b.length>2?32:42;
  const svg='<svg xmlns="http://www.w3.org/2000/svg" width="320" height="180" viewBox="0 0 320 180">'
    +'<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="'+g.c1+'"/><stop offset="1" stop-color="'+g.c2+'"/></linearGradient>'
    +'<pattern id="p" width="12" height="12" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><rect width="3" height="12" fill="#fff" opacity=".055"/></pattern></defs>'
    +'<rect width="320" height="180" fill="url(#g)"/><rect width="320" height="180" fill="url(#p)"/>'
    +'<circle cx="160" cy="80" r="50" fill="#000" opacity=".22"/><circle cx="160" cy="80" r="45" fill="#fff" opacity=".08" stroke="#fff" stroke-opacity=".25"/>'
    +'<text x="160" y="'+(80+bs*.36)+'" font-family="Segoe UI,Arial,sans-serif" font-size="'+bs+'" font-weight="800" letter-spacing="2" text-anchor="middle" fill="#fff">'+logoEsc(g.b)+'</text>'
    +'<text x="160" y="148" font-family="Segoe UI,Arial,sans-serif" font-size="13" font-weight="700" text-anchor="middle" fill="#fff">'+short+'</text>'
    +'<text x="14" y="20" font-family="Segoe UI,Arial,sans-serif" font-size="8" letter-spacing="2.4" fill="#fff" opacity=".75">BITEENGINE 3</text>'
    +'<text x="306" y="20" font-family="Segoe UI,Arial,sans-serif" font-size="8" letter-spacing="1.2" text-anchor="end" fill="#fff" opacity=".65">2D GAME</text>'
    +'<rect y="172" width="320" height="8" fill="'+g.a+'"/></svg>';
  u='data:image/svg+xml,'+encodeURIComponent(svg);LOGO_URLS.set(key,u);return u;
}
function logoPng(logo,name,cb){
  const img=new Image();
  img.onload=()=>{const c=el('canvas',{width:640,height:360});c.getContext('2d').drawImage(img,0,0,640,360);cb(c.toDataURL('image/png'))};
  img.onerror=()=>cb(null);img.src=logoUrl(logo,name);
}
function logoIco(logo,name,cb){
  const g=logoFor(logo,name),img=new Image();
  img.onload=()=>{
    const c=el('canvas',{width:256,height:256}),x=c.getContext('2d'),gr=x.createLinearGradient(0,0,256,256);
    gr.addColorStop(0,g.c1);gr.addColorStop(1,g.c2);x.fillStyle=gr;x.fillRect(0,0,256,256);
    x.drawImage(img,0,56,256,144);
    const bin=atob(c.toDataURL('image/png').split(',')[1]),raw=new Uint8Array(bin.length);
    for(let i=0;i<bin.length;i++)raw[i]=bin.charCodeAt(i);
    const h=new Uint8Array(22),v=new DataView(h.buffer);
    v.setUint16(2,1,true);v.setUint16(4,1,true);v.setUint16(10,1,true);v.setUint16(12,32,true);v.setUint32(14,raw.length,true);v.setUint32(18,22,true);
    cb(new Blob([h,raw],{type:'image/x-icon'}));
  };
  img.onerror=()=>cb(null);img.src=logoUrl(g,name);
}
function saveBlob(blob,file){
  const a=el('a',{href:URL.createObjectURL(blob),download:file});document.body.append(a);a.click();a.remove();
  setTimeout(()=>URL.revokeObjectURL(a.href),5000);
}
const saveUrl=(url,file)=>{const a=el('a',{href:url,download:file});document.body.append(a);a.click();a.remove()};
const logoFile=n=>String(n||'project').replace(/[^\w-]+/g,'_')||'project';
function downloadDlg(data,name){
  if(!data||typeof data!=='object'){note('That project could not be read','e');return}
  name=name||data.name||'Untitled project';
  const logo=logoFor(data.logo,name);data.logo=logo;
  const scenes=Array.isArray(data.scenes)&&data.scenes.length?data.scenes:null,sc=scenes?scenes.length:1;
  const nodes=scenes?scenes.reduce((a,s)=>a+((s.nodes||[]).length),0):(data.nodes||[]).length;
  const file=logoFile(name)+'.biteproj';
  const body=el('div',{className:'dlg'},
    el('img',{className:'dlglogo',src:logoUrl(logo,name),alt:'Logo for '+name}),
    el('p',{className:'dlgname',textContent:name}),
    el('p',{className:'pmeta',textContent:sc+' scene'+(sc===1?'':'s')+' · '+nodes+' node'+(nodes===1?'':'s')+' · '+file}),
    el('p',{className:'dim dlgdesc',textContent:'The logo is stored inside the .biteproj and shown in the project manager. Browsers cannot attach a custom icon to a .biteproj file, so download the PNG or Windows icon too.'}),
    el('div',{className:'dlgbtns'},
      el('button',{className:'pri',textContent:'Download .biteproj',onclick:()=>{saveBlob(new Blob([JSON.stringify(data)],{type:'application/json'}),file);note('Downloaded '+file)}}),
      el('button',{textContent:'Download logo (PNG 640×360)',onclick:()=>logoPng(logo,name,u=>u?(saveUrl(u,logoFile(name)+'-logo.png'),note('Downloaded project logo')):note('Could not create the logo image','e'))}),
      el('button',{textContent:'Download Windows icon (.ico)',onclick:()=>logoIco(logo,name,b=>b?(saveBlob(b,logoFile(name)+'-logo.ico'),note('Downloaded project icon')):note('Could not create the icon','e'))})));
  modal('Download project',body,[['Close',()=>{}]]);
}

/* ---------- dialogs ---------- */
function modal(t,body,actions){
  const o=el('div',{className:'modal'}),p=el('div',{className:'mp',role:'dialog','aria-label':t}),close=()=>o.remove();
  p.append(el('h2',{textContent:t}),body,el('div',{className:'f2'},...actions.map(([x,f,c])=>el('button',{textContent:x,className:c||'',onclick:()=>{if(f(close)!==false)close()}}))));
  o.append(p);o.onclick=e=>{if(e.target===o)close()};document.body.append(o);const i=p.querySelector('input');if(i){i.focus();i.select()}
}
const guard=f=>()=>{if(dirty&&!confirm('You have unsaved changes. Continue anyway?'))return;f()};
const newDlg=guard(()=>{
  const n=el('input',{value:'Pixel Quest','aria-label':'Project name'}),t=el('select');
  [['game:platformer','Game: Pixel Quest — 10 platformer levels'],
   ['game:cave','Game: Cave Escape — 10 action levels'],
   ['game:sky','Game: Sky Hopper — 10 coin levels'],
   ['starter','2D starter — Player, Ground, Camera (1 scene)'],
   ['empty','Empty 2D — Node2D root']].forEach(([v,x])=>t.add(new Option(x,v)));
  const tplName={'game:platformer':'Pixel Quest','game:cave':'Cave Escape','game:sky':'Sky Hopper'};
  t.onchange=()=>{const tn=tplName[t.value]||'';if(tn&&(n.value==='My Game'||Object.values(tplName).includes(n.value)))n.value=tn};
  modal('New project',el('div',{},el('div',{className:'f'},el('label',{textContent:'Name'}),n),el('div',{className:'f'},el('label',{textContent:'Template'}),t),el('p',{className:'dim',textContent:'The three game templates create a full game: 10 scenes, player, hazards, music and main / pause / game-over menus. Scripts use the built-in Vexo 2D language.'})),
    [['Cancel',()=>{}],['Create project',()=>{const v=n.value.trim();if(!v)return false;fresh(v,t.value)},'pri']]);
});
function saveAs(){
  const n=el('input',{value:proj.name,'aria-label':'Project name'});
  modal('Save project as',el('div',{className:'f'},el('label',{textContent:'Name'}),n),[['Cancel',()=>{}],['Save',()=>{const v=n.value.trim();if(!v)return false;proj.name=v;save()},'pri']]);
}
const openDlg=guard(()=>{
  const ns=names().filter(n=>ls(KEY+n)),box=el('div',{});
  if(!ns.length)box.append(el('p',{className:'dim',textContent:'No saved projects yet. Use File > Save to create one.'}));
  ns.forEach(n=>box.append(el('div',{className:'prow'},el('span',{textContent:n}),
    el('button',{textContent:'Open',onclick:()=>{try{load(JSON.parse(ls(KEY+n)));document.querySelector('.modal')?.remove()}catch{note('That project could not be read','e')}}}),
    el('button',{textContent:'Delete',onclick:e=>{if(!confirm('Delete "'+n+'"?'))return;ls(KEY+n,null);ls(IDX,JSON.stringify(names().filter(x=>x!==n)));e.target.closest('.prow').remove()}}))));
  modal('Open project',box,[['Open file…',()=>$('#projFile').click()],['Close',()=>{}]]);
});
function download(){proj.logo=logoFor(proj.logo,proj.name);downloadDlg(serialize(),proj.name)}
$('#projFile').onchange=e=>{
  const f=e.target.files[0];if(!f)return;const r=new FileReader();
  r.onload=()=>{try{const d=JSON.parse(r.result);if(d.format!=='biteproj')throw 0;load(d).then(()=>{save();hideHome();$('[data-ws=game]').click();log('Imported "'+proj.name+'"','ok')})}catch{note('That file is not a BiteEngine project','e')}};
  r.readAsText(f);e.target.value='';
};

/* ---------- help, license and publish ---------- */
const MIT_TEXT=`MIT License

Copyright (c) 2026 BiteEngine contributors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.`;
function showLicense(){
  modal('License — MIT',el('div',{},el('p',{className:'dim',textContent:'BiteEngine is free and open source. You may use it personally, in education and commercially.'}),el('pre',{className:'license',textContent:MIT_TEXT}),el('p',{className:'dim',textContent:'Bundled Pixel Adventure artwork by Pixel Frog is CC0 public domain and keeps its own attribution.'})),[['Close',()=>{}]]);
}
function showQuickStart(){
  const steps=['Pick a ready-made game, or choose + New project.','Select a node in the Scene panel to edit it in the Inspector. Right-click the scene tree or viewport to add child nodes.','Press Play to test. A/D or arrows move, Space jumps, Esc opens the menu.','Use the Animation Studio for sprite sheets, and the Pixel Art Studio for 32×32 sprites.','Save with Ctrl+S. File > Download .biteproj exports a backup.','Open File > Publish checklist before sharing your game.'];
  modal('Quick start',el('div',{},el('ol',{className:'qs'},...steps.map(s=>el('li',{textContent:s}))),el('p',{className:'dim',textContent:'Help > Controls lists keyboard and touch controls. Help > License shows the MIT text.'})),[['Close',()=>{}]]);
}
function publishChecklist(){
  const sd=window.BiteScenes?BiteScenes.data():{scenes:[],current:''};
  const scenes=sd.scenes||[],all=scenes.flatMap(s=>s.nodes||[]);
  const menu=(window.BiteMenus?BiteMenus.data().menus:null)||{};
  const rows=[
    [!dirty,'Project saved in this browser'],
    [!!proj.named,'Project has a name'],
    [scenes.length>0,scenes.length+' scene'+(scenes.length===1?'':'s')+' in the project'],
    [all.some(n=>n.type==='CharacterBody2D'),'A CharacterBody2D player exists'],
    [all.some(n=>['StartCheckpoint','Checkpoint','EndCheckpoint','SceneChanger'].includes(n.type)),'A start, checkpoint, goal or level door exists'],
    [!!(menu.main&&menu.main.enabled),'Main menu is enabled'],
    [true,'Project logo is generated automatically']
  ];
  const body=el('div',{},el('p',{className:'dim',textContent:'A quick check before you publish or share. Items marked ! can be fixed in the editor.'}),el('div',{className:'checklist'},...rows.map(([ok,t])=>el('div',{className:'checkrow '+(ok?'ok':'warn')},el('b',{textContent:ok?'✓':'!'}),el('span',{textContent:t})))),el('p',{className:'dim',textContent:'To publish the engine: upload the whole folder including store/ and assets/, serve it over HTTPS, then open File > Download .biteproj to share your game. Send the .biteproj file and players import it with File > Open file.'}));
  modal('Publish checklist',body,[['Download .biteproj',()=>{download()}],['Close',()=>{}]]);
}

/* ---------- home wiring ---------- */
$('#homeNew').onclick=()=>newDlg();
$('#homeImport').onclick=()=>$('#projFile').click();
$('#homeSearch').oninput=e=>{homeQ=e.target.value;homeRefresh()};
$('#homeLicense').onclick=()=>showLicense();
$('#homeTheme').onclick=()=>{$('#theme').click();syncHomeTheme()};
$('#bHome').onclick=()=>showHome();
$('#logo').onclick=()=>showHome();
function syncHomeTheme(){const light=document.documentElement.dataset.theme==='light';$('#homeTheme').textContent=light?'Dark theme':'Light theme'}
$('#theme').addEventListener('click',syncHomeTheme);

/* ---------- menu bar ---------- */
const tab=w=>()=>$('[data-ws='+w+']').click();
const MENUS={
  File:[['Project manager',showHome],['New project…',newDlg],['Open project…',openDlg],['Save',saveCmd,'Ctrl+S'],['Save as…',saveAs],['Download .biteproj',download],['Open file…',()=>$('#projFile').click()],['Publish checklist…',publishChecklist]],
  Edit:[['Delete selected node',()=>$('#bDel').click(),'Del'],['Toggle pixel perfect',()=>$('#pp').click()],['Switch light / dark',()=>$('#theme').click()],['Theme: Cyan',()=>setAccent('cyan')],['Theme: Violet',()=>setAccent('violet')],['Theme: Emerald',()=>setAccent('emerald')],['Theme: Amber',()=>setAccent('amber')],['Theme: Rose',()=>setAccent('rose')]],
  Scene:[['Play',()=>$('#bPlay').click()],['Stop',()=>$('#bStop').click()],['Create node…',()=>{tab('game')();$('#nsearch').focus()}],['New scene…',()=>{tab('game')();$('#sceneNew').click()}],['Duplicate scene',()=>{tab('game')();$('#sceneDup').click()}],['Rename scene…',()=>{tab('game')();$('#sceneRen').click()}],['Delete scene',()=>{tab('game')();$('#sceneDel').click()}],['Next scene',()=>{tab('game')();window.BiteScenes&&BiteScenes.next()}],['Previous scene',()=>{tab('game')();if(window.BiteScenes){const L=BiteScenes.list(),c=BiteScenes.current(),i=L.findIndex(s=>c&&s.id===c.id);BiteScenes.switch(L[(i-1+L.length)%L.length].id)}}]],
  Window:[['Project manager',showHome],['Game Editor',tab('game')],['Animation Studio',tab('anim')],['Pixel Art Studio',tab('pixel')],['Profiler',tab('prof')],['Asset Store',tab('store')],['My Library',tab('lib')],['Game Assets',tab('assets')]],
  'Game Menu':[['Menu builder…',()=>{tab('game')();window.BiteMenus?.open()}],['Preview main menu',()=>{tab('game')();window.BiteMenus?.preview('main')}],['Preview pause menu',()=>{tab('game')();window.BiteMenus?.preview('pause')}],['Preview game over',()=>{tab('game')();window.BiteMenus?.preview('over')}]],
  Help:[['Quick start',showQuickStart],['Controls',()=>modal('Controls',el('p',{innerHTML:'Edit: drag nodes, right-drag to pan.<br>Scene tree / viewport right-click: add a child node.<br>Play: A/D or arrows to move, Space to jump. Esc opens the pause menu.<br>Menus: the Menus button or Game Menu > Menu builder creates main, pause and game-over menus without code.<br>Scenes: use the Scene bar above the viewport to create, duplicate, rename or delete scenes. SceneChanger and EndCheckpoint can load another scene.<br>Scripts: select a node and press Auto (or Inspector > Auto script) to add a ready-made Vexo behaviour.<br>Gameplay: Enemy, StartCheckpoint, Checkpoint, EndCheckpoint, SceneChanger, Spike, Spring, FireTrap, MovingPlatform, BreakableBox and Sound work without a script.<br>Game Assets: upload files, create folders and add sounds or images.<br>Ctrl+S saves the project.'}),[['Close',()=>{}]])],['License (MIT)',showLicense],['About BiteEngine',()=>modal('BiteEngine 3.0',el('div',{},el('p',{className:'dim',textContent:'A Godot-style 2D game engine in the browser. Projects are saved locally and can be downloaded as .biteproj files.'}),el('p',{className:'dim',textContent:'Free and open source under the MIT License. See Help > License for the full text.'}),el('p',{className:'dim',textContent:'Scripting is built in with Vexo, the 2D game language from vexo_script. C# is not part of the engine.'})),[['Close',()=>{}]])]]
};
const bar=$('#menubar'),closeAll=()=>$$('.mi.open').forEach(m=>m.classList.remove('open'));
for(const [name,items] of Object.entries(MENUS)){
  const mi=el('div',{className:'mi'}),dd=el('div',{className:'dd'});
  items.forEach(([t,f,k])=>dd.append(el('button',{onclick:()=>{closeAll();f()}},el('span',{textContent:t}),k?el('kbd',{textContent:k}):'')));
  mi.append(el('button',{textContent:name,onclick:e=>{e.stopPropagation();const o=mi.classList.contains('open');closeAll();if(!o)mi.classList.add('open')}}),dd);bar.append(mi);
}
document.addEventListener('click',closeAll);
addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='s'){e.preventDefault();saveCmd()}});
addEventListener('beforeunload',e=>{if(dirty){e.preventDefault();e.returnValue=''}});
title();syncHomeTheme();
HOME.classList.remove('off');renderTemplateCards();homeRefresh();
})();
