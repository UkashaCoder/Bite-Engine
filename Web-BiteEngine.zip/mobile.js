'use strict';
/* BiteEngine 3 — mobile shell: bottom panels, pan mode, add-node button,
   first-run tip and optional PWA install/offline support. */
(()=>{
const $=s=>document.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const GAME=$('#ws-game'),TABS=$('#mTabs'),PAN=$('#mPan'),TIP=$('#mTip'),FAB=$('#mAdd');

function setPanel(p){
  if(!GAME||!TABS)return;
  const scene=p==='scene',props=p==='props',con=p==='console';
  GAME.classList.toggle('mPanel-scene',scene);
  GAME.classList.toggle('mPanel-props',props);
  document.body.classList.toggle('mConsoleOpen',con);
  $$('button[data-panel]',TABS).forEach(b=>b.classList.toggle('on',b.dataset.panel===p));
}
TABS?.addEventListener('click',e=>{
  const b=e.target.closest('button[data-panel]');if(!b)return;
  const p=b.dataset.panel;
  const open=p==='scene'?GAME.classList.contains('mPanel-scene')
    :p==='props'?GAME.classList.contains('mPanel-props')
    :p==='console'?document.body.classList.contains('mConsoleOpen')
    :false;
  setPanel(open?'none':p);
});

PAN?.addEventListener('click',()=>{
  const on=document.body.classList.toggle('mPan');
  PAN.classList.toggle('on',on);
  PAN.textContent=on?'Pan ON':'Pan';
  if(on)setPanel('none');
});
addEventListener('keydown',e=>{if(e.key==='Escape'){setPanel('none');if(document.body.classList.contains('mPan'))PAN?.click()}});

$('#bPlay')?.addEventListener('click',()=>setPanel('none'));
$$('#tabs button').forEach(b=>b.addEventListener('click',()=>{setPanel('none');if(document.body.classList.contains('mPan'))PAN.click()}));

FAB?.addEventListener('click',()=>{
  if(window.BiteMobile?.addNode)window.BiteMobile.addNode();
  else $('#nsearch')?.focus();
});

if(TIP){
  try{if(localStorage.getItem('bite.mobileTip'))TIP.hidden=true}catch{}
  $('#mTipX')?.addEventListener('click',()=>{
    TIP.hidden=true;try{localStorage.setItem('bite.mobileTip','1')}catch{}
  });
}

matchMedia('(min-width:761px)').addEventListener?.('change',e=>{
  if(e.matches){setPanel('none');if(document.body.classList.contains('mPan'))PAN?.click()}
});

if('serviceWorker' in navigator&&/^https?:$/.test(location.protocol)){
  addEventListener('load',()=>navigator.serviceWorker.register('sw.js').catch(()=>{}));
}
})();
