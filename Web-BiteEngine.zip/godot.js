'use strict';
/* BiteEngine 3 - Godot-style layer: node types, TileMap, ParallaxBackground,
   Sprite2D, skinned CharacterBody2D (idle/run/jump/fall/double jump), fruits, pixel-perfect render. */
(()=>{
const M=STORE_MANIFEST,AS={};M.assets.forEach(a=>AS[a.p]=a);
const IMC={},IM=p=>IMC[p]||(IMC[p]=Object.assign(new Image(),{src:assetUrl(p)})),rdy=i=>i.complete&&i.naturalWidth>0;
const assetUrl=p=>String(p||'').startsWith('asset:')?(window.BiteAssets?.url(p)||''):BiteLib.url(p);
const SKINS=['Mask Dude','Ninja Frog','Pink Man','Virtual Guy'],FRUITS=['Apple','Bananas','Cherries','Kiwi','Melon','Orange','Pineapple','Strawberry'];
const SA={Idle:['Idle (32x32).png',11,.06],Run:['Run (32x32).png',12,.05],Jump:['Jump (32x32).png',1,1],Fall:['Fall (32x32).png',1,1],'Double Jump':['Double Jump (32x32).png',6,.06],Hit:['Hit (32x32).png',7,.06]};
const T=16,COLS=22,TS='Terrain/Terrain (16x16).png',KC=new WeakMap();
let gt=0,tile=7,fx=[],pre=null,tileErase=false;
let SCENES=[],CUR_SCENE='',RUN_SCENE='';
const sceneAt=id=>SCENES.find(s=>s.id===id)||SCENES[0]||null;
const sceneByName=nm=>{const q=String(nm||'').trim().toLowerCase();return SCENES.find(s=>s.name.toLowerCase()===q)||SCENES.find(s=>s.id.toLowerCase()===q)||null};
const sceneOptions=()=>SCENES.map(s=>[s.name,s.name]);
const currentSceneName=()=>{const s=sceneAt(playing?(RUN_SCENE||CUR_SCENE):CUR_SCENE);return s?s.name:''};
const SET=Object.assign({bg:'#0b1222',g:720,snap:false,sz:8,col:false,sfx:true},(()=>{try{return JSON.parse(localStorage.getItem('bite.set'))}catch{return{}}})());
[['snapOn','snap','checked'],['snapSz','sz','value',Number],['showCol','col','checked'],['sfxOn','sfx','checked'],['grav','g','value',Number],['bgc','bg','value']].forEach(([id,k,p,c])=>{
  const i=$('#'+id);i[p]=SET[k];i.onchange=i.oninput=()=>{SET[k]=c?c(i[p]):i[p];try{localStorage.setItem('bite.set',JSON.stringify(SET))}catch{}}});
NODE_TYPES.splice(0,NODE_TYPES.length,'Node2D','Sprite2D','AnimatedSprite2D','CharacterBody2D','Enemy','StaticBody2D','MovingPlatform','Area2D','Spike','Spring','FireTrap','BreakableBox','StartCheckpoint','Checkpoint','EndCheckpoint','SceneChanger','Sound','TileMap','ParallaxBackground','Camera2D','Label','AnimationPlayer');
/* enemy sheets: idle/move/hit are [file, frame count]; fly + fixed drive sensible defaults */
const ENEMY_SKINS={
  AngryPig:{fw:36,fh:30,idle:['Idle (36x30).png',9],move:['Run (36x30).png',12],hit:['Hit 1 (36x30).png',5]},
  Bat:{fw:46,fh:30,idle:['Idle (46x30).png',12],move:['Flying (46x30).png',7],hit:['Hit (46x30).png',5],fly:true},
  Bee:{fw:36,fh:34,idle:['Idle (36x34).png',6],move:['Idle (36x34).png',6],hit:['Hit (36x34).png',5],fly:true},
  BlueBird:{fw:32,fh:32,idle:['Flying (32x32).png',9],move:['Flying (32x32).png',9],hit:['Hit (32x32).png',5],fly:true},
  Bunny:{fw:34,fh:44,idle:['Idle (34x44).png',8],move:['Run (34x44).png',12],hit:['Hit (34x44).png',5]},
  Chameleon:{fw:84,fh:38,idle:['Idle (84x38).png',13],move:['Run (84x38).png',8],hit:['Hit (84x38).png',5]},
  Chicken:{fw:32,fh:34,idle:['Idle (32x34).png',13],move:['Run (32x34).png',14],hit:['Hit (32x34).png',5]},
  Duck:{fw:36,fh:36,idle:['Idle (36x36).png',10],move:['Idle (36x36).png',10],hit:['Hit (36x36).png',5]},
  FatBird:{fw:40,fh:48,idle:['Idle (40x48).png',8],move:['Ground (40x48).png',4],hit:['Hit (40x48).png',5],fly:true},
  Ghost:{fw:44,fh:30,idle:['Idle (44x30).png',10],move:['Idle (44x30).png',10],hit:['Hit (44x30).png',5],fly:true},
  Mushroom:{fw:32,fh:32,idle:['Idle (32x32).png',14],move:['Run (32x32).png',16],hit:['Hit.png',5]},
  Plant:{fw:44,fh:42,idle:['Idle (44x42).png',11],move:['Idle (44x42).png',11],hit:['Hit (44x42).png',5],fixed:true},
  Radish:{fw:30,fh:38,idle:['Idle 1 (30x38).png',6],move:['Run (30x38).png',12],hit:['Hit (30x38).png',5]},
  Rino:{fw:52,fh:34,idle:['Idle (52x34).png',11],move:['Run (52x34).png',6],hit:['Hit (52x34).png',5]},
  Rocks:{fw:38,fh:34,idle:['Rock1_Idle (38x34).png',14],move:['Rock1_Run (38x34).png',14],hit:['Rock1_Hit.png',1]},
  Skull:{fw:52,fh:54,idle:['Idle 1 (52x54).png',8],move:['Idle 1 (52x54).png',8],hit:['Hit (52x54).png',5],fly:true},
  Slime:{fw:44,fh:30,idle:['Idle-Run (44x30).png',10],move:['Idle-Run (44x30).png',10],hit:['Hit (44x30).png',5]},
  Snail:{fw:38,fh:24,idle:['Idle (38x24).png',15],move:['Walk (38x24).png',10],hit:['Hit (38x24).png',5]},
  Trunk:{fw:64,fh:32,idle:['Idle (64x32).png',18],move:['Run (64x32).png',14],hit:['Hit (64x32).png',5],fixed:true},
  Turtle:{fw:44,fh:26,idle:['Idle 1 (44x26).png',14],move:['Idle 1 (44x26).png',14],hit:['Hit (44x26).png',5],fixed:true}
};
const ENEMY_BEHAVIOURS=[['patrol','Patrol (walk back and forth)'],['chase','Chase the player'],['fly','Fly / float'],['static','Static (no movement)']];
const CP_TEX={startIdle:'Items/Checkpoints/Start/Start (Idle).png',startMove:'Items/Checkpoints/Start/Start (Moving) (64x64).png',
  cpIdle:'Items/Checkpoints/Checkpoint/Checkpoint (Flag Idle)(64x64).png',cpOut:'Items/Checkpoints/Checkpoint/Checkpoint (Flag Out) (64x64).png',
  cpNone:'Items/Checkpoints/Checkpoint/Checkpoint (No Flag).png',endIdle:'Items/Checkpoints/End/End (Idle).png',endPressed:'Items/Checkpoints/End/End (Pressed) (64x64).png'};
const boxTex=(i,k)=>{i=Math.max(1,Math.min(3,+i||1));return k==='idle'?'Items/Boxes/Box'+i+'/Idle.png':k==='hit'?'Items/Boxes/Box'+i+'/Hit (28x24).png':'Items/Boxes/Box'+i+'/Break (28x24).png'};
const BOX_HIT=[0,3,4,2];
const DEF={Node2D:{w:8,h:8},Camera2D:{w:16,h:16,follow:true,smooth:.12,limit:true},Label:{text:'Label',size:8,col:'#ffffff',w:40,h:10},Sprite2D:{tex:'Items/Fruits/Apple.png',w:32,h:32,fps:12},AnimatedSprite2D:{w:32,h:32},
  CharacterBody2D:{w:14,h:24,skin:'Mask Dude',run:100,jump:270,dj:true,grav:1,maxHp:3},StaticBody2D:{w:64,h:12},Area2D:{w:16,h:16,tex:''},
  Enemy:{w:36,h:30,skin:'AngryPig',behavior:'patrol',dir:-1,speed:36,range:96,sight:150,dmg:1,hp:2,points:10,stomp:true,ledge:true,fps:10},
  MovingPlatform:{w:64,h:12,axis:'x',dist:96,speed:40,phase:0},
  Spike:{w:32,h:16,dmg:1,respawn:false},
  Spring:{w:28,h:28,power:420},
  FireTrap:{w:16,h:32,dmg:1,cycle:true,startOn:true,onTime:1.4,offTime:1.1},
  BreakableBox:{w:28,h:24,box:1,hits:1,points:5,drop:false},
  StartCheckpoint:{w:64,h:64,active:true,heal:true,label:''},
  Checkpoint:{w:64,h:64,heal:true,bonus:0,reusable:false,label:''},
  EndCheckpoint:{w:64,h:64,requireCoins:false,bonus:0,winText:'LEVEL COMPLETE!',next:'',label:''},
  Sound:{w:24,h:24,sound:'assets/sounds/jump.wav',volume:.8,loop:false,autoplay:false,trigger:'collision',key:' ',once:false},
  SceneChanger:{w:32,h:48,scene:'',delay:.25,keep:false,label:'Level door'},
  TileMap:{cells:{},w:0,h:0},ParallaxBackground:{tex:'Backgrounds/Green.png',sx:0,sy:24,w:0,h:0},
  AnimationPlayer:{w:0,h:0,anims:{},autoplay:'',speed:1,playing:true}};
mk=function(type,o={}){const n={id:nid++,type,name:type,x:0,y:0,w:16,h:16,anim:'Idle',flip:false,speed:1,fps:12,rotation:0,alpha:1,...JSON.parse(JSON.stringify(DEF[type]||{})),...o};nodes.push(n);return n};
const fi=(t,fps,n,loop=true)=>{const i=Math.floor(t*fps);return loop?i%n:Math.min(n-1,i)};
function cell(g,img,fw,fh,f,x,y,flip){
  if(!rdy(img))return;const c=Math.max(1,Math.floor(img.naturalWidth/fw)),sx=(f%c)*fw,sy=Math.floor(f/c)*fh;
  if(flip){g.save();g.translate(x+fw,y);g.scale(-1,1);g.drawImage(img,sx,sy,fw,fh,0,0,fw,fh);g.restore()}else g.drawImage(img,sx,sy,fw,fh,x,y,fw,fh);
}
function spr(g,s,f,x,y,fh,fv,al){
  const c=f%s.cols,r=Math.floor(f/s.cols),sx=s.m+c*(s.fw+s.sp),sy=s.m+r*(s.fh+s.sp);
  g.save();g.globalAlpha=al;g.translate(x+(fh?s.fw:0),y+(fv?s.fh:0));g.scale(fh?-1:1,fv?-1:1);g.drawImage(s.img,sx,sy,s.fw,s.fh,0,0,s.fw,s.fh);g.restore();
}
const tl=n=>{let a=KC.get(n);if(!a){a=Object.keys(n.cells||{}).map(k=>{const[x,y]=k.split(',');return[+x,+y,n.cells[k]]});KC.set(n,a)}return a};

/* full tileset palette: every cell in Terrain (16x16).png */
function palette(){
  const SC=2,ROWS=11,W=COLS*T*SC,H=ROWS*T*SC;
  const wrap=el('div',{className:'tilepalWrap'}),bar=el('div',{className:'tilepalBar'}),info=el('span',{className:'dim'});
  const erase=el('button',{textContent:'Erase',onclick:()=>{tileErase=!tileErase;sync()}});
  const clear=el('button',{textContent:'Clear tiles',onclick:()=>{
    if(!confirm('Clear all painted tiles on this TileMap?'))return;
    snap();sel.cells={};KC.delete(sel);window.BiteMarkDirty?.();refresh();log('Cleared all tiles on '+sel.name,'w');
  }});
  const box=el('div',{className:'tilepal',title:'All 242 terrain tiles'});
  const c=el('canvas',{width:W,height:H,className:'tilepalCv'});
  const g=c.getContext('2d'),im=IM(TS);
  g.imageSmoothingEnabled=false;
  const draw=()=>{
    g.clearRect(0,0,W,H);
    if(rdy(im))g.drawImage(im,0,0,W,H);
    g.strokeStyle='#ffffff18';g.lineWidth=1;g.beginPath();
    for(let x=0;x<=COLS;x++){g.moveTo(x*T*SC+.5,0);g.lineTo(x*T*SC+.5,H)}
    for(let y=0;y<=ROWS;y++){g.moveTo(0,y*T*SC+.5);g.lineTo(W,y*T*SC+.5)}
    g.stroke();
    const tx=(tile%COLS)*T*SC,ty=Math.floor(tile/COLS)*T*SC;
    g.strokeStyle='#8B5CF6';g.lineWidth=3;g.strokeRect(tx+1.5,ty+1.5,T*SC-3,T*SC-3);
    g.strokeStyle='#39D5FF';g.lineWidth=1;g.strokeRect(tx+3.5,ty+3.5,T*SC-7,T*SC-7);
  };
  const sync=()=>{
    erase.classList.toggle('on',tileErase);
    erase.textContent=tileErase?'Erase ON':'Erase';
    info.textContent=tileErase?'Tap the map to remove tiles':'Tile '+(tile+1)+' of '+(COLS*ROWS);
    draw();
  };
  c.onclick=e=>{
    const r=c.getBoundingClientRect();
    const col=Math.floor((e.clientX-r.left)*W/r.width/(T*SC));
    const row=Math.floor((e.clientY-r.top)*H/r.height/(T*SC));
    if(col<0||row<0||col>=COLS||row>=ROWS)return;
    tile=row*COLS+col;tileErase=false;sync();
    if(matchMedia('(max-width:760px)').matches)document.querySelector('#mTabs [data-panel=none]')?.click();
  };
  if(!rdy(im))im.addEventListener('load',draw,{once:true});
  bar.append(erase,clear,info);box.append(c);wrap.append(bar,box);sync();
  return wrap;
}

demo=function(){nodes=[];nid=1;sel=null;refresh()};
/* ---------- scene tree, inspector, create node, console ---------- */
const INFO={Node2D:['N2','#94A3B8','Base 2D node. Holds a position and groups children.'],
 Sprite2D:['SP','#39D5FF','Draws one texture. Sprite sheets play automatically.'],
 AnimatedSprite2D:['AS','#8B5CF6','Plays animations from sprite frames (loop, ping-pong, once).'],
 CharacterBody2D:['CB','#22C55E','Player body with gravity, run, jump, double jump and health.'],
 Enemy:['EN','#EF4444','Animated enemy with patrol, chase and fly behaviour. Works with no script.'],
 StaticBody2D:['SB','#60A5FA','Solid rectangle that bodies collide with.'],
 MovingPlatform:['MP','#38BDF8','Solid platform that moves back and forth and carries the player.'],
 Area2D:['AR','#F59E0B','Pickup zone that detects the player (fruits, coins).'],
 Spike:['SP','#F87171','Spike hazard. Damages or respawns the player.'],
 Spring:['SG','#A3E635','Trampoline that launches the player into the air.'],
 FireTrap:['FR','#FB923C','Fire hazard that switches on and off.'],
 BreakableBox:['BX','#D97706','Solid box that breaks when the player hits it from below.'],
 StartCheckpoint:['ST','#FBBF24','Player spawn point when Play starts.'],
 Checkpoint:['CP','#FBBF24','Saves the respawn point when the player touches it.'],
 EndCheckpoint:['GO','#22C55E','Level goal. Touching it completes the level.'],
 Sound:['SD','#F472B6','Plays a sound effect or music. Choose a trigger in the Inspector.'],
 SceneChanger:['LD','#2DD4BF','Moves the player to another scene when touched. Pick the target scene in the Inspector.'],
 TileMap:['TM','#EC4899','Paint terrain tiles from the Terrain tileset. Solid in Play.'],
 ParallaxBackground:['PB','#14B8A6','Scrolling tiled background.'],
 Camera2D:['CM','#F59E0B','Controls the game view. Follows the player or stays fixed.'],
 Label:['LB','#E2E8F0','Draws text in the scene (score, hints).'],
 AnimationPlayer:['AP','#F43F5E','Godot-style keyframe player. Animates X, Y, rotation, opacity and visibility.']};
const badge=t=>el('span',{className:'ic',textContent:INFO[t]?INFO[t][0]:'??',style:'background:'+(INFO[t]?INFO[t][1]:'#94A3B8')});
const kidsOf=(L,n)=>L.filter(k=>k.parent===n.id),subtree=(L,n)=>[n,...kidsOf(L,n).flatMap(k=>subtree(L,k))];
const moveKids=(L,n,dx,dy)=>{if(dx||dy)for(const k of subtree(L,n).slice(1)){k.x+=dx;k.y+=dy}};
const uniq=b=>{let k=b,i=2;while(nodes.some(x=>x.name===k))k=b+i++;return k};
let pickT='Sprite2D';
function order(){const out=[],walk=(p,d)=>{for(const n of nodes)if((n.parent||null)===p){out.push([n,d]);if(n.open!==false)walk(n.id,d+1)}};walk(null,0);return out}
function rename(n,li){
  if(playing)return;const s=li.querySelector('.nm');
  const i=el('input',{value:n.name,onclick:e=>e.stopPropagation(),onkeydown:e=>{if(e.key==='Enter')i.blur();if(e.key==='Escape'){i.value=n.name;i.blur()}},onblur:()=>{const v=i.value.trim()||n.name;if(v!==n.name){n.name=v;window.BiteMarkDirty?.()}refresh()}});
  s.replaceWith(i);i.focus();i.select();
}
refresh=function(){
  const ul=$('#list');ul.innerHTML='';
  for(const[n,d]of order()){
    const has=kidsOf(nodes,n).length>0,li=el('li',{_node:n,className:(n===sel?'sel ':'')+(n.hide?'off':''),style:'padding-left:'+(6+d*14)+'px',onclick:()=>{if(!playing){sel=n;refresh()}},ondblclick:()=>rename(n,li),
      oncontextmenu:e=>{e.preventDefault();e.stopPropagation();if(playing)return;sel=n;refresh();const node=sel;const cur=$('#list li.sel');nodeMenu(e.clientX,e.clientY,node,undefined,cur)}},
      el('span',{className:'arr',textContent:has?(n.open===false?'▸':'▾'):'',onclick:e=>{e.stopPropagation();n.open=n.open===false;refresh()}}),
      badge(n.type),el('span',{className:'nm',textContent:n.name}),el('small',{textContent:n.type}),n.script?el('span',{className:'eye',title:'Open script',textContent:'◈',onclick:e=>{e.stopPropagation();sel=n;openScript(n)}}):'',
      el('span',{className:'eye',title:'Show / hide',textContent:n.hide?'○':'●',onclick:e=>{e.stopPropagation();n.hide=!n.hide;window.BiteMarkDirty?.();refresh()}}));
    ul.append(li);
  }
  inspector();
};
function inspector(){
  const f=$('#fields');f.innerHTML='';
  if(!sel){f.append(el('p',{className:'dim',textContent:'Select a node to edit it.'}));return}
  const add=(l,w)=>f.append(el('div',{className:'f'},el('label',{textContent:l}),w)),sec=t=>f.append(el('h3',{textContent:t}));
  const pick=(items,value,onchange)=>{
    const s=el('select'),arr=items||[],pairs=arr.length&&Array.isArray(arr[0])?arr:arr.map(x=>[x,x]);
    pairs.forEach(([v,label])=>s.add(new Option(String(label),String(v))));
    s.value=value??'';s.onchange=()=>onchange(s.value);return s;
  };
  const row=(l,k,type='text')=>{const i=el('input',{type,value:sel[k]??(type==='number'?0:''),step:'any',oninput:()=>{const o=sel[k];sel[k]=type==='number'?+i.value:i.value;
    if(k==='x'||k==='y')moveKids(nodes,sel,k==='x'?sel.x-o:0,k==='y'?sel.y-o:0);if(k==='name'){const nm=$('#list li.sel .nm');if(nm)nm.textContent=sel.name}}});add(l,i)};
  const chk=(l,k,d,cb)=>add(l,el('input',{type:'checkbox',checked:sel[k]??d,onchange:e=>{sel[k]=e.target.checked;cb&&cb()}}));
  const btns=(...b)=>f.append(el('div',{className:'f2'},...b.map(([t,fn])=>el('button',{textContent:t,onclick:fn}))));
  const ty=sel.type,bodies=['CharacterBody2D','StaticBody2D','Area2D','AnimatedSprite2D','Enemy','MovingPlatform','Spike','Spring','FireTrap','BreakableBox','StartCheckpoint','Checkpoint','EndCheckpoint','SceneChanger','Sound'].includes(ty);
  sec(ty);row('Name','name');add('Visible',el('input',{type:'checkbox',checked:!sel.hide,onchange:e=>{sel.hide=!e.target.checked;refresh()}}));
  sec('Transform');row('X','x','number');row('Y','y','number');row('Rotation','rotation','number');if(bodies){row('Width','w','number');row('Height','h','number')}
  add('Opacity',el('input',{type:'range',min:0,max:1,step:.05,value:sel.alpha??1,oninput:e=>{sel.alpha=+e.target.value}}));
  if(ty==='CharacterBody2D'){sec('Body');add('Skin',pick(SKINS,sel.skin||SKINS[0],v=>sel.skin=v));row('Speed','run','number');row('Jump','jump','number');chk('Double jump','dj',true);row('Gravity scale','grav','number');row('Max health','maxHp','number');chk('Built-in controls','ctrl',true)}
  if(ty==='Enemy'){
    sec('Enemy');
    add('Skin',pick(Object.keys(ENEMY_SKINS),sel.skin||'AngryPig',v=>{
      sel.skin=v;const E=ENEMY_SKINS[v];
      if(E){sel.w=E.fw;sel.h=E.fh;if(E.fly)sel.behavior='fly';else if(E.fixed&&sel.behavior!=='chase')sel.behavior='static';else if(sel.behavior==='fly')sel.behavior='patrol'}
      refresh();
    }));
    add('Behaviour',pick(ENEMY_BEHAVIOURS,sel.behavior||'patrol',v=>{sel.behavior=v;inspector()}));
    row('Speed','speed','number');row('Patrol range','range','number');row('Chase sight','sight','number');
    row('Damage','dmg','number');row('Health','hp','number');row('Score points','points','number');
    add('Start direction',pick([['-1','Left'],['1','Right']],String((sel.dir??-1)<0?-1:1),v=>sel.dir=+v));
    chk('Stompable','stomp',true);chk('Turn at ledges','ledge',true);
    f.append(el('p',{className:'dim',textContent:'No script needed. Pick Patrol, Chase, Fly or Static and press Play. Damage comes from touching the player.'}));
  }
  if(ty==='StartCheckpoint'){
    sec('Start checkpoint');
    chk('Use as player spawn','active',true);chk('Heal on respawn','heal',true);row('Label','label');
    f.append(el('p',{className:'dim',textContent:'When Play starts the first active StartCheckpoint becomes the player spawn.'}));
  }
  if(ty==='Checkpoint'){
    sec('Checkpoint');
    chk('Heal the player','heal',true);row('Bonus score','bonus','number');chk('Reusable','reusable',false);row('Label','label');
    f.append(el('p',{className:'dim',textContent:'Touching the flag saves a new respawn point. Falls and damage return the player here.'}));
  }
  if(ty==='EndCheckpoint'){
    sec('Level goal');
    row('Win text','winText');
    const sc=sceneOptions(),opts=[['','(stay on win screen)'],...sc];
    if(sel.next&&!sc.some(([n])=>n===sel.next))opts.push([sel.next,sel.next+' (missing scene)']);
    add('Next scene',pick(opts,sel.next||'',v=>{sel.next=v;inspector()}));
    chk('Continue automatically','autoNext',false);row('Auto delay (seconds)','delay','number');
    row('Bonus score','bonus','number');chk('Require all coins','requireCoins',false);row('Label','label');
    f.append(el('p',{className:'dim',textContent:'Touching the goal shows a level complete banner. With a next scene you can press Space/Enter, or let it continue automatically.'}));
  }
  if(ty==='SceneChanger'){
    sec('Level door');
    const sc=sceneOptions(),opts=sc.length?sc:[['','(no scenes yet)']];
    if(sel.scene&&!sc.some(([n])=>n===sel.scene))opts.push([sel.scene,sel.scene+' (missing scene)']);
    add('Target scene',pick(opts,sel.scene||'',v=>{sel.scene=v;inspector()}));
    row('Delay (seconds)','delay','number');chk('Keep player health','keep',false);row('Label','label');
    f.append(el('p',{className:'dim',textContent:'When the player touches this door the engine loads the target scene, keeps the score and starts its scripts and sounds. Create more scenes with the Scene bar above the viewport.'}));
  }
  if(ty==='MovingPlatform'){
    sec('Platform');
    add('Axis',pick([['x','Horizontal'],['y','Vertical']],sel.axis||'x',v=>{sel.axis=v;inspector()}));
    row('Distance','dist','number');row('Speed','speed','number');row('Phase (seconds)','phase','number');
    f.append(el('p',{className:'dim',textContent:'Moves back and forth from its start position and carries the player standing on top.'}));
  }
  if(ty==='Spike'){sec('Spike hazard');row('Damage','dmg','number');chk('Respawn player on touch','respawn',false)}
  if(ty==='Spring'){sec('Spring');row('Bounce power','power','number');f.append(el('p',{className:'dim',textContent:'Touching it while falling launches the player upward.'}))}
  if(ty==='FireTrap'){
    sec('Fire hazard');row('Damage','dmg','number');
    chk('Cycle on and off','cycle',true);chk('Start switched on','startOn',true);
    row('On time (seconds)','onTime','number');row('Off time (seconds)','offTime','number');
  }
  if(ty==='BreakableBox'){
    sec('Breakable box');
    add('Box style',pick([['1','Box 1'],['2','Box 2'],['3','Box 3']],String(sel.box||1),v=>{sel.box=+v;refresh()}));
    row('Hits to break','hits','number');row('Score points','points','number');chk('Drop a coin','drop',false);
    f.append(el('p',{className:'dim',textContent:'Jump into the box from below to break it. It is solid until it breaks.'}));
  }
  if(ty==='Sound'){
    const opts=(window.BiteAssets&&BiteAssets.audioOptions)?BiteAssets.audioOptions():SND.map(s=>[s.path,s.name+' ('+s.kind+')']);
    sec('Sound');
    add('Clip',pick(opts,sel.sound||'assets/sounds/jump.wav',v=>{sel.sound=v;if(/music|background/i.test(v)){sel.loop=true;inspector()}}));
    add('Play when',pick([['collision','Player touches it'],['key','Key is pressed'],['start','Level starts'],['manual','Only from a script']],sel.trigger||'collision',v=>{sel.trigger=v;inspector()}));
    if(sel.trigger==='key')row('Key','key');
    row('Volume','volume','number');chk('Loop','loop',false);chk('Play at start','autoplay',false);chk('Only once','once',false);
    btns(['▶ Preview',()=>playSound(sel.sound,{volume:sel.volume??.8}),'■ Stop',()=>stopSound(sel.sound)]);
    f.append(el('p',{className:'dim',textContent:'Built-in sounds: Jump, Collect Apple, Death and Background Music. Project sounds appear here after you upload them in Game Assets. Use play_sound() in Vexo for manual playback.'}));
  }
  if(ty==='Camera2D'){sec('Camera');chk('Follow player','follow',true);row('Smoothing','smooth','number');chk('Limit to level','limit',true)}
  if(ty==='Label'){sec('Text');row('Text','text');row('Size','size','number');add('Color',el('input',{type:'color',value:sel.col||'#ffffff',oninput:e=>sel.col=e.target.value}))}
  if(ty==='StaticBody2D')add('Color',el('input',{type:'color',value:sel.col||'#24324d',oninput:e=>sel.col=e.target.value}))
  if(ty==='AnimationPlayer'){
    const names=Object.keys(sel.anims||{});
    sec('AnimationPlayer');
    add('Autoplay',pick(['',...names],sel.autoplay||'',v=>{sel.autoplay=v;if(v)sel.playingAnim=v;refresh()}));
    row('Speed','speed','number');chk('Play at start','playing',true);
    btns(['Open animation timeline',()=>openAnimDock(sel)]);
    f.append(el('p',{className:'dim',textContent:names.length+' animation'+(names.length===1?'':'s')+'. The timeline below adds X, Y, rotation, opacity and visibility keys.'}));
  }
  if(ty==='AnimatedSprite2D'){
    const A=ANIMS[sel.anim],nf=A?A.frames.length:1,a=apOf(sel);
    sec('Sprite Frames');
    btns(['Open SpriteFrames editor',()=>{if(ANIMS[sel.anim]){curAnim=sel.anim;curSheet=ANIMS[sel.anim].sheet;selFrame=0;ap.restart(curAnim)}$('[data-ws=anim]').click()}]);
    sec('Animation');
    add('Animation',pick(Object.keys(ANIMS),sel.anim,v=>{sel.anim=v;sel.frame=0;inspector()}));
    add('Frame',el('input',{type:'number',min:0,max:nf-1,step:1,value:sel.frame|0,oninput:e=>{sel.frame=Math.max(0,Math.min(nf-1,+e.target.value|0))}}));
    row('Speed Scale','speed','number');chk('Playing','playing',true,()=>{if(sel.playing!==false)a.done=false});chk('Autoplay','auto',true);
    btns(['▶ Play',()=>{sel.playing=true;a.done=false;inspector()}],['❚❚ Pause',()=>{sel.playing=false;sel.frame=a.i;inspector()}],['■ Stop',()=>{sel.playing=false;sel.frame=0;inspector()}]);
    f.append(el('p',{className:'dim',textContent:nf+' frames, '+(A?A.mode:'')+', sheet '+(A?A.sheet:'-')}));
    sec('Offset');chk('Centered','ctr',true);row('Offset X','ox','number');row('Offset Y','oy','number');
    sec('Flip & Color');chk('Flip H','flip',false);chk('Flip V','flipV',false);
    add('Opacity',el('input',{type:'range',min:0,max:1,step:.05,value:sel.alpha??1,oninput:e=>sel.alpha=+e.target.value}));
  }
  if(ty==='Sprite2D'){
    const custom=(window.BiteAssets&&BiteAssets.imageOptions)?BiteAssets.imageOptions():[];
    const texs=[...Object.keys(AS).filter(p=>!/^(Menu|Root)/.test(p)).map(p=>[p,p]),...custom];
    sec('Texture');
    add('Texture',pick(texs,sel.tex,v=>{sel.tex=v;const inf=AS[v]||(window.BiteAssets&&BiteAssets.info?BiteAssets.info(v):null);if(inf){sel.w=inf.fw;sel.h=inf.fh}refresh();inspector()}));
    row('FPS','fps','number');chk('Flip H','flip',false);
    if(custom.length)f.append(el('p',{className:'dim',textContent:'Project images from Game Assets appear at the end of the texture list.'}));
  }
  if(ty==='Area2D'){sec('Item');add('Item',pick([['','Coin'],...FRUITS.map(x=>['Items/Fruits/'+x+'.png',x])],sel.tex||'',v=>sel.tex=v))}
  if(ty==='ParallaxBackground'){sec('Background');add('Texture',pick(Object.keys(AS).filter(p=>p.startsWith('Backgrounds/')),sel.tex,v=>sel.tex=v));row('Scroll X','sx','number');row('Scroll Y','sy','number')}
  if(ty==='TileMap'){sec('Tile palette');f.append(el('p',{className:'dim',textContent:'Pick a tile, then click in the viewport to paint. Shift+click erases. Tiles are solid in Play.'}),palette())}
  const lang=sel.scriptLang||(sel.script?'js':'vexo');
  sec('Script');
  f.append(el('p',{className:'dim',textContent:sel.script?'Script attached ('+(lang==='vexo'?'Vexo 2D':'JavaScript')+', '+sel.script.split('\n').length+' lines).':'No script. Auto adds a ready-made script for this node type.'}));
  f.append(el('div',{className:'f2'},el('button',{textContent:'Auto script',onclick:()=>autoScript(sel)}),el('button',{textContent:'Behaviours…',onclick:()=>openBehaviourPicker(sel)})));
  btns([sel.script?'Edit script':'New Vexo script',()=>openScript(sel)]);if(sel.script)btns(['Remove script',()=>{snap();delete sel.script;delete sel.scriptLang;window.BiteMarkDirty?.();refresh();log('Removed script from '+sel.name,'w')}]);
}
function create(t,child,opt={}){
  if(playing){log('Stop the game before adding nodes','w');return null}
  snap();
  const p=opt.parent!==undefined?opt.parent:((child||$('#nChild').checked)&&sel?sel:null);
  const n=mk(t,{name:opt.name||uniq(t)});
  if(t==='AnimatedSprite2D'){n.anim=Object.keys(ANIMS)[0]||'';if(!n.anim)log('No animations yet. Import a sprite sheet in Animation Studio or the Asset Store.','w')}
  if(t==='AnimationPlayer'){
    if(!n.anims||!Object.keys(n.anims).length)n.anims={idle:{length:1,loop:true,tracks:[]}};
    if(!n.autoplay)n.autoplay=Object.keys(n.anims)[0];
  }
  if(opt.x!==undefined&&opt.y!==undefined){n.x=Math.round(opt.x);n.y=Math.round(opt.y)}
  else{n.x=Math.round(cam.x+GW/2-n.w/2);n.y=60;if(t==='TileMap'||t==='ParallaxBackground'){n.x=0;n.y=0}}
  if(p){n.parent=p.id;if(opt.x===undefined){n.x=p.x;n.y=p.y}p.open=true}
  sel=n;window.BiteMarkDirty?.();log('Created '+t+' "'+n.name+'"'+(p?' under '+p.name:''),'ok');refresh();
  if(t==='AnimationPlayer')openAnimDock(n);
  if($('#nScript')&&$('#nScript').checked)autoScript(n);
  return n;
}

/* ---------- Godot-style context menus and node picker ---------- */
let ctxMenu=null;
function closeCtx(){if(ctxMenu){ctxMenu.remove();ctxMenu=null}}
function contextMenu(x,y,items){
  closeCtx();
  const m=el('div',{className:'ctx'});
  for(const it of items){
    if(it==='-'){m.append(el('div',{className:'sep'}));continue}
    if(!Array.isArray(it)){m.append(el('div',{className:'lbl',textContent:it.label}));continue}
    const [label,fn,o={}]=it;
    const b=el('button',{className:(o.danger?'danger ':'')+(o.sub?'sub':''),textContent:label,disabled:!!o.disabled,onclick:e=>{e.stopPropagation();if(o.disabled)return;closeCtx();fn()}});
    if(o.shortcut)b.append(el('kbd',{textContent:o.shortcut}));
    m.append(b);
  }
  document.body.append(m);
  const r=m.getBoundingClientRect();
  m.style.left=Math.max(6,Math.min(x,innerWidth-r.width-8))+'px';
  m.style.top=Math.max(6,Math.min(y,innerHeight-r.height-8))+'px';
  ctxMenu=m;
}
document.addEventListener('pointerdown',e=>{if(ctxMenu&&!e.target.closest('.ctx'))closeCtx()},true);
addEventListener('blur',closeCtx);
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeCtx()});

function nodeMenu(x,y,n,pos,li){
  const items=[];
  if(n){
    items.push({label:n.type+' · '+n.name});
    items.push(['Add Child Node…',()=>nodePicker(n,pos)]);
    if(pos)items.push(['Add Node Here…',()=>nodePicker(null,pos)]);
    items.push('-');
    items.push(['Rename',()=>{sel=n;refresh();const row=li&&li.isConnected?li:$('#list li.sel');if(row)rename(n,row)},{shortcut:'F2'}]);
    items.push(['Duplicate',()=>{sel=n;dup()},{shortcut:'Ctrl+D'}]);
    items.push(['Delete',()=>{sel=n;del()},{shortcut:'Del',danger:true}]);
    items.push('-');
    items.push([n.script?'Edit script':'Attach Vexo script',()=>openScript(n)]);
    items.push(['Automatic script (one click)',()=>autoScript(n)]);
    items.push(['Choose behaviour script…',()=>openBehaviourPicker(n)]);
    items.push([n.hide?'Show node':'Hide node',()=>{n.hide=!n.hide;refresh()}]);
    items.push(['Move up',()=>{sel=n;mv(-1)}]);
    items.push(['Move down',()=>{sel=n;mv(1)}]);
    if(n.type==='AnimationPlayer')items.push(['Open animation timeline',()=>openAnimDock(n)]);
  }else{
    items.push({label:'Scene'});
    items.push(['Add Node…',()=>nodePicker(null,pos)]);
    items.push(['Add Child Node…',()=>nodePicker(sel,pos),{disabled:!sel}]);
    items.push('-');
    items.push(['New Node2D',()=>create('Node2D',false,{parent:null,x:pos&&pos.x,y:pos&&pos.y})]);
    items.push(['New Sprite2D',()=>create('Sprite2D',false,{parent:null,x:pos&&pos.x,y:pos&&pos.y})]);
    items.push(['New CharacterBody2D',()=>create('CharacterBody2D',false,{parent:null,x:pos&&pos.x,y:pos&&pos.y})]);
    items.push(['New Enemy',()=>create('Enemy',false,{parent:null,x:pos&&pos.x,y:pos&&pos.y})]);
    items.push(['New Checkpoint',()=>create('Checkpoint',false,{parent:null,x:pos&&pos.x,y:pos&&pos.y})]);
    items.push(['New AnimationPlayer',()=>create('AnimationPlayer',false,{parent:null,x:pos&&pos.x,y:pos&&pos.y})]);
  }
  contextMenu(x,y,items);
}

let npPick='Node2D';
function nodePicker(parent,pos){
  const overlay=el('div',{className:'modal'}),box=el('div',{className:'mp np',role:'dialog','aria-label':'Create New Node'});
  const search=el('input',{placeholder:'Search nodes…','aria-label':'Search nodes'});
  const list=el('div',{className:'npList'});
  const info=el('div',{className:'npInfo'});
  const name=el('input',{value:uniq(npPick),'aria-label':'Node name'});
  const parentLbl=el('span',{className:'npParent',textContent:parent?'Child of '+parent.name:'Scene root'});
  const addBtn=el('button',{className:'pri',textContent:'Add node'});
  const renderInfo=()=>{
    const I=INFO[npPick]||['??','#94A3B8',''];
    info.innerHTML='';info.append(badge(npPick),el('b',{textContent:npPick}),el('span',{textContent:I[2]}));
  };
  const renderList=()=>{
    const q=search.value.toLowerCase();list.innerHTML='';
    NODE_TYPES.filter(t=>(t+' '+(INFO[t]?INFO[t][2]:'')).toLowerCase().includes(q)).forEach(t=>{
      const b=el('button',{className:t===npPick?'sel':'',onclick:()=>{npPick=t;name.value=uniq(t);renderList();renderInfo()},ondblclick:()=>add()},badge(t),el('span',{textContent:t}),el('small',{textContent:t==='AnimationPlayer'?'keyframes':'2D'}));
      list.append(b);
    });
  };
  const add=()=>{const nm=name.value.trim()||uniq(npPick);overlay.remove();create(npPick,false,{parent,x:pos&&pos.x,y:pos&&pos.y,name:nm});};
  addBtn.onclick=add;
  search.oninput=renderList;
  search.onkeydown=e=>{if(e.key==='Enter'){const first=[...list.children][0];if(first)first.click()}if(e.key==='Escape')overlay.remove()};
  name.onkeydown=e=>{if(e.key==='Enter')add();if(e.key==='Escape')overlay.remove()};
  box.append(el('h2',{textContent:'Create New Node'}),el('div',{className:'npSearch'},search),el('div',{className:'npBody'},list,info),
    el('div',{className:'npFoot'},parentLbl,el('span',{className:'grow'}),el('label',{className:'langRow'},el('span',{textContent:'Name'}),name),addBtn,el('button',{textContent:'Cancel',onclick:()=>overlay.remove()})));
  overlay.append(box);overlay.onclick=e=>{if(e.target===overlay)overlay.remove()};
  document.body.append(overlay);renderList();renderInfo();search.focus();
}
window.BiteMobile={
  addNode(){
    if(playing){log('Stop the game before adding nodes','w');return}
    nodePicker(sel||null,null);
  },
  openNodeMenu(x,y,n,pos){if(!playing)nodeMenu(x,y,n,pos)}
};
window.BiteGame={
  addNode:(type,opt)=>{if(playing)return null;const n=create(type,false,opt||{});if(n){refresh();window.BiteMarkDirty?.()}return n},
  uniqueName:b=>uniq(b),
  get scene(){return nodes},
  get playing(){return playing}
};
$('#list').addEventListener('contextmenu',e=>{
  if(e.target.closest('li')||playing)return;
  e.preventDefault();sel=null;refresh();nodeMenu(e.clientX,e.clientY,null);
});
listNodes=function(){
  const q=$('#nsearch').value.toLowerCase(),ul=$('#nlist');ul.innerHTML='';
  NODE_TYPES.filter(t=>(t+' '+INFO[t][2]).toLowerCase().includes(q)).forEach(t=>ul.append(el('li',{className:t===pickT?'sel':'',onclick:()=>{pickT=t;listNodes()},ondblclick:()=>create(t)},badge(t),t)));
  $('#ndesc').textContent=INFO[pickT]?INFO[pickT][2]:'';
};
$('#nsearch').oninput=listNodes;$('#nsearch').onkeydown=e=>{if(e.key==='Enter'){const m=NODE_TYPES.find(t=>t.toLowerCase().includes($('#nsearch').value.toLowerCase()));if(m){pickT=m;create(m)}}};
$('#nCreate').onclick=()=>create(pickT);$('#tAdd').onclick=()=>create(pickT,true);listNodes();
function del(){if(playing||!sel)return;snap();const rm=new Set(subtree(nodes,sel));nodes=nodes.filter(n=>!rm.has(n));window.BiteMarkDirty?.();log('Deleted '+sel.name+(rm.size>1?' and '+(rm.size-1)+' children':''),'w');sel=null;refresh()}
function dup(){
  if(playing||!sel)return;snap();const map=new Map(),src=subtree(nodes,sel);
  for(const s of src){const c=JSON.parse(JSON.stringify(s));c.id=nid++;map.set(s.id,c.id);if(s===sel)c.name=uniq(s.name.replace(/\d+$/,''));else c.parent=map.get(s.parent);c.x+=8;c.y+=8;nodes.push(c)}
  sel=nodes.find(n=>n.id===map.get(src[0].id));window.BiteMarkDirty?.();log('Duplicated '+src[0].name,'ok');refresh();
}
function mv(d){if(playing||!sel)return;const sib=nodes.filter(n=>(n.parent||null)===(sel.parent||null)),o=sib[sib.indexOf(sel)+d];if(!o)return;const a=nodes.indexOf(sel),b=nodes.indexOf(o);snap();[nodes[a],nodes[b]]=[nodes[b],nodes[a]];window.BiteMarkDirty?.();refresh()}
$('#bDel').onclick=del;$('#tDup').onclick=dup;$('#tUp').onclick=()=>mv(-1);$('#tDn').onclick=()=>mv(1);
addEventListener('keydown',e=>{
  if(playing||ws!=='game'||/INPUT|SELECT|TEXTAREA/.test(e.target.tagName))return;
  if(e.key==='Delete'){del()}else if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='d'){e.preventDefault();dup()}
  else if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='z'){e.preventDefault();e.shiftKey?redo():undo()}
  else if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='y'){e.preventDefault();redo()}
  else if(e.key==='F2'&&sel){const li=$('#list li.sel');if(li)rename(sel,li)}
});
$('#bPlay').addEventListener('click',()=>{
  if(!run)return;
  RUN_SCENE=CUR_SCENE;closeMenu();
  run.forEach(n=>{if(n.type==='AnimatedSprite2D')n.playing=n.auto!==false});
  resetLevel(run);
  startLevelAudio(run);
  startScripts();
  updateHud();
  if(MENU_CFG.main.enabled&&MENU_CFG.main.showOnStart)openMenu('main');
});
$('#bStop').addEventListener('click',()=>{stopAllAudio();closeMenu();won=false;WINNER=null;updateHud()});

/* ---------- scripting: Vexo 2D (built-in) with legacy JavaScript ---------- */
const V2=window.Vexo,HK=new WeakMap(),bus={},KM={left:['a','arrowleft'],right:['d','arrowright'],up:['w','arrowup'],down:['s','arrowdown'],jump:[' ','w','arrowup'],space:[' ']};
let VX=new WeakMap(),pk={},timers=[],pt=0;
const kd=(o,k)=>(KM[k]||[String(k).toLowerCase()]).some(x=>o[x]);
const Input={is_pressed:k=>kd(keys,k),just_pressed:k=>kd(keys,k)&&!kd(pk,k)};
function callHook(n,k,a){
  if(VX.has(n)){if(k==='ready')fireVexo(n,'start');else if(k==='body')fireVexo(n,'collision',a);return}
  const h=HK.get(n);if(!h||!h[k]||h.err||(n.dead&&k!=='ready'))return;
  try{h[k](a)}catch(e){h.err=1;log('Script error in '+n.name+': '+e.message,'e')}
}
function fireVexo(n,event,...args){
  const vx=VX.get(n);if(!vx)return;
  try{vx.fire(event,...args)}catch(e){log('Vexo error in '+n.name+': '+e.message,'e')}
}
/* ---------- shared level state: health, checkpoints, enemies, goal ---------- */
let won=false,WINNER=null,WIN_T=0,WIN_TEXT='',WIN_NEXT='',WIN_KEY_DOWN=false,LAST_CHECKPOINT=null;
const playerOf=()=>run?run.find(n=>n.type==='CharacterBody2D'&&!n.dead)||null:null;
function updateHud(){
  const b=playing?playerOf():null;
  $('#score').textContent=b?'HP '+Math.max(0,Math.round(b.hp??b.maxHp??3))+'/'+(b.maxHp??3)+'  Score '+score:'Score '+score;
}
function saveSpawn(b,x,y){
  if(!b)return;
  b.sx=x===undefined?b.x:x;b.sy=y===undefined?b.y:y;
}
function respawnPlayer(b,msg){
  if(!b)return;
  playSfx('death',.75);
  const dx=b.sx-b.x,dy=b.sy-b.y;
  b.x=b.sx;b.y=b.sy;b.vx=0;b.vy=0;b.inv=1.3;b.stun=0;b.hp=b.maxHp||3;b.floor=false;b.jn=0;
  if(run&&!b.dead)moveKids(run,b,dx,dy);
  updateHud();
  if(msg)log(msg,'w');
}
function hurtPlayer(b,amt,srcX){
  if(!b||b.dead||won||(b.inv||0)>0)return false;
  const dmg=Math.max(1,+amt||1);
  b.hp=Math.max(0,(b.hp??b.maxHp??3)-dmg);
  b.inv=1.1;b.stun=.28;b.vy=-190;b.vx=((srcX??b.x)>b.x+b.w/2?-1:1)*150;
  if(b.hp<=0){
    playSfx('death',.75);
    if(MENU_CFG.over.enabled){
      MENU_OPEN='over';MENU_BACK='';MENU_SEL=0;MENU_HITS=[];
      log('Game over. Score '+score,'w');
    }else respawnPlayer(b,'Player ran out of health. Respawned at '+(LAST_CHECKPOINT?LAST_CHECKPOINT.name:'the start'));
  }
  else log('Player hit (-'+dmg+' HP), '+b.hp+'/'+(b.maxHp||3)+' left','w');
  updateHud();return true;
}
function healPlayer(b,amt){
  if(!b)return;
  const max=Math.max(1,+b.maxHp||3);
  b.hp=amt===undefined||amt===null?max:Math.min(max,(b.hp??max)+Math.max(0,+amt||0));
  updateHud();
}
function damageEnemy(e,amt){
  if(!e||e.dead||e.type!=='Enemy')return;
  e._hp=(e._hp??Math.max(1,+e.hp||1))-Math.max(1,+amt||1);
  e._hitT=.3;
  if(e._hp<=0){
    e.dead=true;const pts=Math.max(0,+e.points||0);
    if(pts){score+=pts;updateHud()}
    fx.push({x:e.x+e.w/2-16,y:e.y+e.h/2-16,t:0});
    log('Enemy defeated: '+e.name+(pts?' +'+pts+' score':''),'ok');
  }
}
function winLevel(end,text){
  if(won)return;
  won=true;WINNER=end||null;WIN_T=0;WIN_KEY_DOWN=false;
  WIN_TEXT=text||(end&&end.winText)||'LEVEL COMPLETE!';
  WIN_NEXT=end&&end.next?String(end.next):'';
  if(end&&+end.bonus){score+=+end.bonus;updateHud()}
  log('Level complete: '+WIN_TEXT+(WIN_NEXT?' (next: '+WIN_NEXT+')':''),'ok');
}
function spawnEnemyAt(skin='AngryPig',x=0,y=0,o={}){
  if(!run)return null;
  const E=ENEMY_SKINS[skin]||ENEMY_SKINS.AngryPig;
  const n={id:nid++,type:'Enemy',name:'Enemy',x,y,w:E.fw,h:E.fh,anim:'',flip:false,speed:1,fps:10,rotation:0,alpha:1,...JSON.parse(JSON.stringify(DEF.Enemy)),...o,skin};
  if(E){n.w=o.w??E.fw;n.h=o.h??E.fh;if(!o.behavior)n.behavior=E.fly?'fly':E.fixed?'static':'patrol'}
  n.sx=x;n.sy=y;run.push(n);return n;
}
/* ---------- audio runtime: sound effects, music loops and Sound nodes ---------- */
const SND=window.BiteSounds||[],AUD_ONESHOT=new Set(),AUD_LOOPS=new Map();
const sfxOn=()=>SET.sfx!==false;
function soundSpec(name){
  if(name&&typeof name==='object')return name.sound||'';
  const s=String(name||'');if(!s)return'';
  if(s.startsWith('asset:')||s.startsWith('data:'))return s;
  const hit=SND.find(x=>x.id===s||x.name.toLowerCase()===s.toLowerCase()||x.file===s||x.path===s);
  if(hit)return hit.path;
  if(/\.(wav|ogg|mp3|m4a|aac|flac|webm)$/i.test(s))return s;
  return'';
}
const audioUrl=src=>String(src||'').startsWith('asset:')?(window.BiteAssets?.url(src)||''):src;
function playSound(name,opt={}){
  const src=soundSpec(name);if(!src)return null;
  const url=audioUrl(src);if(!url)return null;
  const vol=Math.max(0,Math.min(1,opt.volume===undefined?1:+opt.volume||0));
  try{
    if(opt.loop){
      let a=AUD_LOOPS.get(url);
      if(!a){a=new Audio(url);a.loop=true;AUD_LOOPS.set(url,a)}
      a.volume=vol;if(a.paused)a.play().catch(()=>{});
      return a;
    }
    const a=new Audio(url);a.volume=vol;AUD_ONESHOT.add(a);
    a.onended=()=>AUD_ONESHOT.delete(a);
    a.play().catch(()=>{});return a;
  }catch{return null}
}
function stopSound(name){
  const src=soundSpec(name);if(!src)return;
  const url=audioUrl(src);
  for(const a of [...AUD_ONESHOT]){if(a.src&&a.src.endsWith(url)){try{a.pause()}catch{};AUD_ONESHOT.delete(a)}}
  const a=AUD_LOOPS.get(url);
  if(a){try{a.pause();a.currentTime=0}catch{};AUD_LOOPS.delete(url)}
}
function stopAllAudio(){
  for(const a of AUD_ONESHOT){try{a.pause();a.currentTime=0}catch{}}
  AUD_ONESHOT.clear();
  for(const a of AUD_LOOPS.values()){try{a.pause();a.currentTime=0}catch{}}
  AUD_LOOPS.clear();
}
const playSfx=(id,vol=.7)=>{if(sfxOn())playSound(id,{volume:vol})};
const playNodeSound=n=>{if(!n||!n.sound)return null;if(!n.loop&&!sfxOn())return null;return playSound(n.sound,{volume:n.volume??.8,loop:!!n.loop})};
function startLevelAudio(L){
  stopAllAudio();
  for(const n of L){
    if(n.type!=='Sound'||n.dead)continue;
    n._inside=false;n._played=false;n._keyDown=false;
    if(n.autoplay||n.trigger==='start'){playNodeSound(n);n._played=true}
  }
}
function updateSoundNodes(L){
  const b=playerOf();
  for(const n of L){
    if(n.type!=='Sound'||n.dead||n.hide)continue;
    if(n.trigger==='key'){
      const k=String(n.key||' ').toLowerCase(),down=!!keys[k];
      if(down&&!n._keyDown&&(!n.once||!n._played)){playNodeSound(n);n._played=true}
      n._keyDown=down;
    }else if(n.trigger==='collision'){
      if(!b)continue;
      const h=hit(b,n);
      if(h&&!n._inside&&(!n.once||!n._played)){playNodeSound(n);n._played=true}
      n._inside=h;
    }
  }
}
const API={
  get_node:nm=>run&&run.find(n=>n.name===nm&&!n.dead)||null,
  queue_free:n=>{if(n){n.dead=true;run.sol=null}},
  spawn:(type,o={})=>{const n={id:nid++,type,name:type,x:0,y:0,w:16,h:16,anim:'',flip:false,speed:1,fps:12,...JSON.parse(JSON.stringify(DEF[type]||{})),...o,vx:0,vy:0};n.sx=n.x;n.sy=n.y;run.push(n);run.sol=null;return n},
  print:(...a)=>log(a.join(' '),'ok'),warn:(...a)=>log(a.join(' '),'w'),
  set_score:v=>{score=v;updateHud()},get_score:()=>score,
  get_player:()=>playerOf(),get_health:()=>{const b=playerOf();return b?(b.hp??b.maxHp??3):0},
  set_health:v=>{const b=playerOf();if(b){b.hp=Math.max(0,Math.min(+v||0,b.maxHp||3));updateHud()}},
  damage_player:amt=>hurtPlayer(playerOf(),amt,(playerOf()||{x:0}).x+1),
  heal_player:amt=>healPlayer(playerOf(),amt),respawn_player:()=>respawnPlayer(playerOf(),'Respawned'),
  save_checkpoint:()=>{const b=playerOf();if(b){saveSpawn(b);log('Spawn point saved','ok')}},
  win_level:text=>winLevel(run?run.find(x=>x.type==='EndCheckpoint'):null,typeof text==='string'?text:undefined),
  change_scene:name=>changeSceneRuntime(name),get_scene:()=>currentSceneName(),
  get_enemies:()=>run?run.filter(x=>x.type==='Enemy'&&!x.dead):[],damage_enemy:(e,amt=1)=>damageEnemy(e,amt),
  spawn_enemy:(skin,x=0,y=0,o={})=>spawnEnemyAt(skin,x,y,o),
  is_on_floor:()=>!!n.floor,get_axis:()=>(keys.d||keys.arrowright?1:0)-(keys.a||keys.arrowleft?1:0),
  jump:(p=270)=>{n.vy=-Math.abs(+p||270);n.jn=1;n.floor=false},bounce:(p=420)=>{n.vy=-Math.abs(+p||420)},
  time:()=>pt,collides:hit,connect:(k,f)=>(bus[k]=bus[k]||[]).push(f),emit:(k,...a)=>(bus[k]||[]).forEach(f=>f(...a)),
  after:(s,f)=>timers.push({t:s,f}),rand:(a=0,b=1)=>a+Math.random()*(b-a),
  play_sound:(name,vol=.8)=>playSound(name,{volume:vol}),
  stop_sound:name=>stopSound(name),stop_all_sounds:()=>stopAllAudio(),
  play_music:(name,vol=.6)=>playSound(name,{loop:true,volume:vol})};
/* engine API handed to a Vexo script, mirroring vexo_script/engine2d.py */
function makeVexoApi(n){
  const find=nm=>run&&run.find(x=>x.name===nm&&!x.dead)||null;
  return{
    move:(dx,dy)=>{n.x+=dx||0;n.y+=dy||0},
    find,node:find,get_node:find,
    find_all:nm=>run?run.filter(x=>x.name===nm&&!x.dead):[],
    destroy:t=>{t=t||n;t.dead=true;if(run)run.sol=null},
    spawn:(type,x=0,y=0,o={})=>API.spawn(type,{x,y,...o}),
    set_velocity:(x,y)=>{n.vx=x;n.vy=y},
    get_velocity:()=>new V2.Vec2(n.vx||0,n.vy||0),
    play_animation:name=>{n.anim=name;n.playing=true;apOf(n).restart(name)},
    stop_animation:()=>{n.playing=false},
    play_sound:(name,vol)=>playSound(name||n.sound,{volume:vol===undefined?(n.volume??.8):vol,loop:false}),
    stop_sound:name=>stopSound(name||n.sound),
    play_music:(name,vol)=>playSound(name||n.sound,{loop:true,volume:vol===undefined?.6:vol}),
    stop_music:()=>stopAllAudio(),
    restart:()=>log('Restart requested','w'),
    quit_game:()=>{if(playing)$('#bStop').click()},
    shake_camera:amount=>log('Camera shake '+amount),
    save_data:(k,v)=>{try{localStorage.setItem('bite.game.'+k,JSON.stringify(v))}catch{}},
    load_data:(k,d=null)=>{try{const s=localStorage.getItem('bite.game.'+k);return s?JSON.parse(s):d}catch{return d}},
    is_key_down:k=>Input.is_pressed(String(k).toLowerCase())||Input.is_pressed(String(k)),
    screen_size:()=>new V2.Vec2(GW,GH),
    distance_to:o=>Math.hypot((o.x||0)-n.x,(o.y||0)-n.y),
    get_score:()=>score,set_score:v=>{score=v;updateHud()},
    get_player:()=>playerOf(),get_health:()=>{const b=playerOf();return b?(b.hp??b.maxHp??3):0},
    set_health:v=>{const b=playerOf();if(b){b.hp=Math.max(0,Math.min(+v||0,b.maxHp||3));updateHud()}},
    damage_player:amt=>hurtPlayer(playerOf(),amt,(playerOf()||{x:0}).x+1),
    heal_player:amt=>healPlayer(playerOf(),amt),respawn_player:()=>respawnPlayer(playerOf(),'Respawned'),
    save_checkpoint:()=>{const b=playerOf();if(b){saveSpawn(b);log('Spawn point saved','ok')}},
    get_checkpoint:()=>LAST_CHECKPOINT,win_level:text=>winLevel(run?run.find(x=>x.type==='EndCheckpoint'):null,typeof text==='string'?text:undefined),
    change_scene:name=>changeSceneRuntime(name),get_scene:()=>currentSceneName(),
    get_enemies:()=>run?run.filter(x=>x.type==='Enemy'&&!x.dead):[],damage_enemy:(e,amt=1)=>damageEnemy(e,amt),
    spawn_enemy:(skin,x=0,y=0,o={})=>spawnEnemyAt(skin,x,y,o),
    is_on_floor:()=>!!n.floor,get_axis:()=>(keys.d||keys.arrowright?1:0)-(keys.a||keys.arrowleft?1:0),
    jump:(p=270)=>{n.vy=-Math.abs(+p||270);n.jn=1;n.floor=false},bounce:(p=420)=>{n.vy=-Math.abs(+p||420)},
    print:(...a)=>log(a.map(V2.vstr).join(' '),'ok'),warn:(...a)=>log(a.map(V2.vstr).join(' '),'w'),
    time:()=>pt,rand:(a=0,b=1)=>a+Math.random()*(b-a)
  };
}
const RET='\n;return {ready:typeof _ready==="function"?_ready:null,process:typeof _process==="function"?_process:null,body:typeof _on_body_entered==="function"?_on_body_entered:null};';
const NAMES=['self','Input',...Object.keys(API)];
const KEYNAME={'arrowleft':'LEFT','arrowright':'RIGHT','arrowup':'UP','arrowdown':'DOWN',' ':'SPACE','space':'SPACE'};
const keyNames=k=>{
  const nm=KEYNAME[k]||(/^[a-z]$/i.test(k)?k.toUpperCase():k.toUpperCase());
  const out=[nm];
  if(nm==='LEFT')out.push('ARROWLEFT');if(nm==='RIGHT')out.push('ARROWRIGHT');
  if(nm==='UP')out.push('ARROWUP');if(nm==='DOWN')out.push('ARROWDOWN');
  return out;
};
function vexoKeys(){
  const pressed=new Set(),released=new Set(),held=new Set();
  for(const k of new Set([...Object.keys(keys),...Object.keys(pk)])){
    const on=!!keys[k],was=!!pk[k];
    for(const nm of keyNames(k)){
      if(on){held.add(nm);if(!was)pressed.add(nm)}
      else if(was)released.add(nm);
    }
  }
  return{pressed,released,held};
}
function startScripts(){
  for(const k in bus)delete bus[k];timers=[];pt=0;pk={};
  VX=new WeakMap();if(V2)V2.clearNodeScripts();
  for(const n of run){
    n.dead=false;n._vxHits=new Set();n._apt=0;
    if(!n.script)continue;
    if(n.scriptLang==='vexo'&&V2){
      try{VX.set(n,new V2.VexoScript(n.script,{host:n,api:makeVexoApi(n),name:n.name,printFn:m=>log('['+n.name+'] '+m,'ok')}))}
      catch(e){log('Vexo error in '+n.name+': '+e.message,'e')}
    }else{
      try{HK.set(n,new Function(...NAMES,n.script+RET)(n,Input,...Object.values(API)))}catch(e){log('Script error in '+n.name+': '+e.message,'e')}
    }
  }
  for(const n of [...run])callHook(n,'ready');
}
function stepScripts(L){
  pt+=STEP;
  for(let i=timers.length-1;i>=0;i--){timers[i].t-=STEP;if(timers[i].t<=0){const t=timers.splice(i,1)[0];try{t.f()}catch(e){log('Script error (timer): '+e.message,'e')}}}
  const ev=vexoKeys();
  for(const n of L.slice()){
    if(n.dead)callHook(n,'process',STEP);
    else if(VX.has(n)){
      const vx=VX.get(n);
      try{
        for(const k of ev.pressed)vx.fire('key_pressed',k);
        for(const k of ev.released)vx.fire('key_released',k);
        for(const k of ev.held)vx.fire('input',k,STEP);
        vx.fire('update',STEP);vx.tick(STEP);
      }catch(e){log('Vexo error in '+n.name+': '+e.message,'e')}
    }else callHook(n,'process',STEP);
  }
  pk={...keys};
}
const API_DOC=`Legacy JavaScript hooks (Vexo is the recommended 2D language):
  function _ready()                 runs once when Play starts
  function _process(delta)          runs every frame (delta in seconds)
  function _on_body_entered(body)   Area2D: the player touched it

Node: self.x self.y self.w self.h self.vx self.vy self.flip self.hide
Input: Input.is_pressed("left"|"right"|"space"...)
Scene: get_node("Name")  queue_free(node)  spawn("Area2D", {x:10, y:20})
       change_scene("Level 2")  get_scene()
Game:  print(...)  get_score()  set_score(n)  time()  rand(a,b)`;
const VEXO_DOC=`Events
  on start:                      once when Play starts
  on update(dt):                 every frame
  on input("LEFT", dt):          held key, dt in seconds
  on key_pressed("J"):           key went down
  on key_released("J"):          key went up
  on collision(other):           nodes overlap

Engine functions
  move(dx, dy)   find("Player")   find_all(name)   node(name)
  destroy(target)   spawn("Area2D", x, y)   set_velocity(x, y)
  play_animation(name)   play_sound(name)   shake_camera(n)
  get_score()   set_score(n)   is_key_down("LEFT")   distance_to(node)
  screen_size()   save_data(key, value)   load_data(key, default)

Combat & level (no extra code needed for Enemy / Checkpoint nodes)
  get_player()   get_health()   set_health(n)   damage_player(n)   heal_player(n)
  respawn_player()   save_checkpoint()   win_level("You win!")
  get_enemies()   damage_enemy(enemy, n)   spawn_enemy("Bat", x, y)
  is_on_floor()   get_axis()   jump(n)   bounce(n)
  change_scene("Level 2")   get_scene()

Node: self.name  self.x  self.y  self.position  self.visible  self.rotation  self.alpha
Signals:  signal died()   emit died()   connect died -> handler
Timers:   after 1.5:  /  every 0.5:
Vars:     @export speed = 200   var hp = 100   const MAX = 3`;
const JTPL=t=>'// '+t+' script (legacy JavaScript).\n\nfunction _ready() {\n  print(self.name + " is ready");\n}\n\nfunction _process(delta) {\n'+
  (t==='CharacterBody2D'?'  // Untick "Built-in controls" in the Inspector, then:\n  // self.vx = (Input.is_pressed("right") - Input.is_pressed("left")) * 100;\n':'  // self.x += 20 * delta;\n')+'}\n'+
  (t==='Area2D'?'\nfunction _on_body_entered(body) {\n  print(body.name + " touched " + self.name);\n  queue_free(self);\n  set_score(get_score() + 1);\n}\n':'');
function VTPL(n){
  const t=n.type,h='# '+n.name+' - Vexo 2D script. Runs while the game is playing.\n\n';
  if(['Enemy','StartCheckpoint','Checkpoint','EndCheckpoint','SceneChanger','Sound','MovingPlatform','Spike','Spring','FireTrap','BreakableBox'].includes(t))
    return h+'# This node works without a script. Its Inspector options control it.\n# Add your own logic below if you want more.\non start:\n    print(self.name + " is ready")\n\non collision(other):\n    print(self.name + " touched " + other.name)\n';
  if(t==='CharacterBody2D')return h+'@export speed = 100\n\non start:\n    print(self.name + " is ready")\n\n# Untick "Built-in controls" in the Inspector to drive this body yourself.\non input("LEFT", dt):\n    move(-speed * dt, 0)\non input("RIGHT", dt):\n    move(speed * dt, 0)\non input("UP", dt):\n    move(0, -speed * dt)\non input("DOWN", dt):\n    move(0, speed * dt)\n';
  if(t==='Area2D')return h+'@export value = 1\n\non collision(other):\n    if other.name == "Player":\n        set_score(get_score() + value)\n        destroy()\n';
  if(t==='Label')return h+'on start:\n    self.text = "Hello from Vexo"\n\non update(dt):\n    self.alpha = 0.75 + 0.25 * sin(time() * 4)\n';
  if(t==='AnimationPlayer')return h+'# Control an AnimationPlayer from code.\non start:\n    play_animation("idle")\n';
  return h+'@export speed = 20\n\non start:\n    print(self.name + " is ready")\n\non update(dt):\n    self.rotation += speed * dt\n';
}
function openScript(n){
  if(playing)return;if(!n){log('Select a node first, then click Script','w');return}
  let lang=n.scriptLang||(n.script?'js':'vexo');
  const tpl=l=>l==='vexo'?VTPL(n):JTPL(n.type);
  const ta=el('textarea',{value:n.script||tpl(lang),spellcheck:false,style:'width:100%;height:330px;font:12px Consolas,monospace;background:var(--bg);color:var(--text);border:1px solid var(--line);border-radius:8px;padding:8px;tab-size:4;resize:vertical'});
  const msg=el('p',{className:'dim'}),o=el('div',{className:'modal'});
  const tag=el('span',{className:'langTag',textContent:lang==='vexo'?'VEXO 2D':'JAVASCRIPT'});
  const sel=el('select',{value:lang,'aria-label':'Script language'});
  sel.add(new Option('Vexo Script — built-in 2D language','vexo'));sel.add(new Option('JavaScript — legacy','js'));
  const help=el('pre',{className:'vexoHelp',textContent:lang==='vexo'?VEXO_DOC:API_DOC});
  const bsel=el('select',{value:'move_player','aria-label':'Quick behaviour'});
  if(V2)Object.entries(V2.BEHAVIOURS).forEach(([k,v])=>bsel.add(new Option(k.replace(/_/g,' ')+' — '+v.desc,k)));
  const bwrap=el('span',{className:'langRow',style:'flex:1'},el('label',{textContent:'Quick behaviour'}),bsel);
  const sync=()=>{
    const vx=lang==='vexo';
    tag.textContent=vx?'VEXO 2D':'JAVASCRIPT';
    help.textContent=vx?VEXO_DOC:API_DOC;
    bwrap.style.display=vx?'flex':'none';
    msg.textContent='';
  };
  sel.onchange=()=>{
    const next=sel.value;
    if(!ta.value.trim()||ta.value.trim()===tpl(lang).trim())ta.value=tpl(next);
    lang=next;sync();
  };
  const check=()=>{
    try{
      if(lang==='vexo')V2.check(ta.value);else new Function('self','Input',ta.value);
      msg.textContent='✓ No syntax errors';msg.style.color='var(--ok)';return true;
    }catch(e){msg.textContent='✗ '+e.message;msg.style.color='var(--err)';return false}
  };
  const save=()=>{
    check();snap();n.script=ta.value;n.scriptLang=lang;
    window.BiteMarkDirty?.();o.remove();refresh();
    log('Saved '+(lang==='vexo'?'Vexo':'JavaScript')+' script on '+n.name,'ok');
  };
  const insert=()=>{
    try{
      const code=V2.makeBehaviour(bsel.value);
      ta.value=ta.value.replace(/\s*$/,'')+'\n\n'+code;sync();check();
    }catch(e){msg.textContent='✗ '+e.message;msg.style.color='var(--err)'}
  };
  ta.onkeydown=e=>{
    e.stopPropagation();
    if(e.key==='Tab'){e.preventDefault();ta.setRangeText('    ',ta.selectionStart,ta.selectionEnd,'end')}
    if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='s'){e.preventDefault();save()}
  };
  ta.onkeyup=e=>e.stopPropagation();
  const b=(t,f,c='')=>el('button',{textContent:t,className:c,onclick:f});
  o.append(el('div',{className:'mp',style:'width:min(860px,96vw)'},
    el('h2',{textContent:'Script: '+n.name+' ('+n.type+')'}),
    el('div',{className:'langRow'},el('label',{textContent:'Language'}),sel,tag),
    ta,msg,
    el('div',{className:'langRow'},bwrap,b('Insert',insert),el('span',{className:'grow'}),b('Check',check)),
    el('details',{},el('summary',{textContent:'Script reference'}),help),
    el('div',{className:'f2'},b('Cancel',()=>o.remove()),b('Save script',save,'pri'))));
  o.onclick=e=>{if(e.target===o)o.remove()};document.body.append(o);ta.focus();sync();
}
$('#tScr').onclick=()=>openScript(sel);

/* ---------- scenes: create, switch, rename, duplicate and delete ---------- */
function stashScene(){const sc=SCENES.find(s=>s.id===CUR_SCENE);if(sc)sc.nodes=nodes}
function nextSceneId(){let i=1;while(SCENES.some(s=>s.id==='s'+i))i++;return 's'+i}
function uniqueSceneName(base,except){
  base=String(base||'Scene').trim()||'Scene';let n=base,i=2;
  while(SCENES.some(s=>s.id!==except&&s.name.toLowerCase()===n.toLowerCase()))n=base+' '+(i++);
  return n;
}
function syncSceneUI(){
  const s=$('#sceneSel');if(!s)return;
  s.innerHTML='';
  for(const sc of SCENES)s.add(new Option(sc.name,sc.id));
  s.value=CUR_SCENE;
  const cur=SCENES.find(x=>x.id===CUR_SCENE),info=$('#sceneInfo');
  if(info)info.textContent=cur?'Scene '+(SCENES.indexOf(cur)+1)+' / '+SCENES.length+' · '+nodes.length+' node'+(nodes.length===1?'':'s'):'';
  const del=$('#sceneDel');if(del)del.disabled=SCENES.length<2;
}
function activateScene(id,opt={}){
  if(playing){log('Stop the game before changing scenes','w');return false}
  const sc=SCENES.find(x=>x.id===id);if(!sc)return false;
  if(sc.id===CUR_SCENE){syncSceneUI();return true}
  stashScene();
  CUR_SCENE=sc.id;nodes=sc.nodes;sel=null;aps.clear();US.length=0;RS.length=0;cam.x=0;cam.y=0;
  syncSceneUI();refresh();
  if(!opt.silent)log('Scene "'+sc.name+'" opened','ok');
  return true;
}
function scenePrompt(title,label,value,onok){
  const o=el('div',{className:'modal'}),p=el('div',{className:'mp',role:'dialog','aria-label':title}),inp=el('input',{value});
  const close=()=>o.remove();
  const ok=()=>{const v=inp.value.trim();if(!v)return;close();onok(v)};
  p.append(el('h2',{textContent:title}),el('div',{className:'f'},el('label',{textContent:label}),inp),
    el('div',{className:'f2'},el('button',{textContent:'Cancel',onclick:close}),el('button',{textContent:'OK',className:'pri',onclick:ok})));
  o.append(p);o.onclick=e=>{if(e.target===o)close()};document.body.append(o);inp.focus();inp.select();
  inp.onkeydown=e=>{if(e.key==='Enter')ok();if(e.key==='Escape')close()};
}
function createScene(name,fromCurrent){
  if(playing){log('Stop the game before creating scenes','w');return null}
  stashScene();
  let arr;
  if(fromCurrent){
    const map=new Map();
    arr=nodes.map(s=>{const c=JSON.parse(JSON.stringify(s));c.id=nid++;map.set(s.id,c.id);for(const k of Object.keys(c))if(k[0]==='_'||k==='dead')delete c[k];return c});
    for(const c of arr)if(c.parent!=null&&map.has(c.parent))c.parent=map.get(c.parent);
  }else{
    arr=[{...JSON.parse(JSON.stringify(DEF.Node2D)),id:nid++,type:'Node2D',name:'Root',x:0,y:0,anim:'Idle',flip:false,speed:1,fps:12,rotation:0,alpha:1}];
  }
  const sc={id:nextSceneId(),name:uniqueSceneName(name||'Scene'),nodes:arr};
  SCENES.push(sc);CUR_SCENE=sc.id;nodes=arr;sel=null;aps.clear();US.length=0;RS.length=0;cam.x=0;cam.y=0;
  syncSceneUI();refresh();window.BiteMarkDirty?.();
  log('Created scene "'+sc.name+'"','ok');
  return sc;
}
function renameCurrentScene(){
  const sc=SCENES.find(s=>s.id===CUR_SCENE);if(!sc)return;
  scenePrompt('Rename scene','Scene name',sc.name,v=>{
    const old=sc.name;
    sc.name=uniqueSceneName(v,sc.id);
    for(const s of SCENES)for(const n of s.nodes){
      if(n.type==='SceneChanger'&&n.scene===old)n.scene=sc.name;
      if(n.type==='EndCheckpoint'&&n.next===old)n.next=sc.name;
    }
    syncSceneUI();refresh();window.BiteMarkDirty?.();log('Renamed scene to "'+sc.name+'"','ok');
  });
}
function deleteCurrentScene(){
  if(playing){log('Stop the game before deleting scenes','w');return}
  if(SCENES.length<2){log('A project needs at least one scene','w');return}
  const sc=SCENES.find(s=>s.id===CUR_SCENE);if(!sc)return;
  if(!confirm('Delete scene "'+sc.name+'"? Its '+sc.nodes.length+' node(s) will be removed.'))return;
  SCENES=SCENES.filter(s=>s.id!==sc.id);
  CUR_SCENE=SCENES[0].id;nodes=SCENES[0].nodes;sel=null;aps.clear();US.length=0;RS.length=0;cam.x=0;cam.y=0;
  syncSceneUI();refresh();window.BiteMarkDirty?.();log('Deleted scene "'+sc.name+'"','w');
}
function cycleScene(d){
  const i=SCENES.findIndex(s=>s.id===CUR_SCENE);if(i<0||!SCENES.length)return;
  activateScene(SCENES[(i+d+SCENES.length)%SCENES.length].id);
}
$('#sceneSel').onchange=e=>activateScene(e.target.value);
$('#sceneNew').onclick=()=>scenePrompt('New scene','Scene name','Scene '+(SCENES.length+1),v=>createScene(v,false));
$('#sceneDup').onclick=()=>{const sc=SCENES.find(s=>s.id===CUR_SCENE);createScene(sc?sc.name+' Copy':'Scene Copy',true)};
$('#sceneRen').onclick=renameCurrentScene;
$('#sceneDel').onclick=deleteCurrentScene;
window.BiteScenes={
  data:()=>{stashScene();return{current:CUR_SCENE,scenes:SCENES.map(s=>({id:s.id,name:s.name,nodes:s.nodes})),nid}},
  load:d=>{
    const src=d&&Array.isArray(d.scenes)?d.scenes:[];
    if(src.length){
      const ids=new Set();
      SCENES=src.map((s,i)=>{
        const base=String(s.id||('s'+(i+1)));let id=base,k=2;
        while(ids.has(id))id=base+'-'+(k++);
        ids.add(id);
        return{id,name:String(s.name||('Scene '+(i+1))),nodes:Array.isArray(s.nodes)?s.nodes:[]};
      });
      CUR_SCENE=SCENES.some(s=>s.id===d.current)?d.current:SCENES[0].id;
    }else{
      SCENES=[{id:'s1',name:'Main',nodes:Array.isArray(d&&d.nodes)?d.nodes:[]}];CUR_SCENE='s1';
    }
    nodes=(SCENES.find(s=>s.id===CUR_SCENE)||SCENES[0]).nodes;
    let mx=0;for(const s of SCENES)for(const n of s.nodes)mx=Math.max(mx,+n.id||0);
    nid=Math.max(1,(d&&+d.nid)||0,mx+1);
    sel=null;aps.clear();US.length=0;RS.length=0;cam.x=0;cam.y=0;
    syncSceneUI();refresh();
  },
  list:()=>SCENES.map(s=>({id:s.id,name:s.name,nodes:s.nodes.length})),
  current:()=>{const s=SCENES.find(x=>x.id===CUR_SCENE);return s?{id:s.id,name:s.name,nodes:s.nodes.length}:null},
  switch:id=>activateScene(id),
  create:(name,fromCurrent)=>createScene(name,fromCurrent),
  duplicate:()=>{const s=SCENES.find(x=>x.id===CUR_SCENE);return createScene(s?s.name+' Copy':'Scene Copy',true)},
  rename:renameCurrentScene,
  remove:deleteCurrentScene,
  next:()=>cycleScene(1),
  change:(name,opt)=>changeSceneRuntime(name,opt)
};

/* ---------- game menus: main, pause, game over, level select, settings ---------- */
const MENU_PAGE_ITEMS={
  main:{play:['play','Start game'],levels:['levels','Level select'],settings:['settings','Settings'],editor:['editor','Back to editor']},
  pause:{resume:['resume','Resume'],restart:['restart','Restart level'],levels:['levels','Level select'],main:['main','Main menu'],settings:['settings','Settings'],editor:['editor','Back to editor']},
  over:{retry:['retry','Retry level'],levels:['levels','Level select'],main:['main','Main menu'],editor:['editor','Back to editor']}
};
const menuDefaults=()=>({
  main:{enabled:true,showOnStart:true,title:'',subtitle:'',accent:'#39D5FF',items:{play:true,levels:true,settings:true,editor:true}},
  pause:{enabled:true,title:'Paused',subtitle:'',accent:'#8B5CF6',items:{resume:true,restart:true,levels:true,main:true,settings:true,editor:true}},
  over:{enabled:true,title:'Game Over',subtitle:'',accent:'#EF4444',items:{retry:true,levels:true,main:true,editor:true}}
});
let MENU_CFG=menuDefaults(),MENU_OPEN='',MENU_BACK='',MENU_SEL=0,MENU_HITS=[];
function normalizeMenus(m){
  const d=menuDefaults();if(!m||typeof m!=='object')return d;
  for(const k of Object.keys(d)){
    const s=m[k];if(!s||typeof s!=='object')continue;
    d[k].enabled=s.enabled!==false;
    if(k==='main')d[k].showOnStart=s.showOnStart!==false;
    if(typeof s.title==='string')d[k].title=s.title;
    if(typeof s.subtitle==='string')d[k].subtitle=s.subtitle;
    if(/^#[0-9a-f]{6}$/i.test(s.accent||''))d[k].accent=s.accent;
    if(s.items)for(const it of Object.keys(d[k].items))if(typeof s.items[it]==='boolean')d[k].items[it]=s.items[it];
  }
  return d;
}
function menuItems(page){
  if(page==='levels'){
    const out=SCENES.map(s=>({label:s.name,action:()=>menuSelectLevel(s.name)}));
    out.push({label:'Back',action:backMenu});return out;
  }
  if(page==='settings')return [
    {label:'Sound effects: '+(SET.sfx?'On':'Off'),action:()=>{
      SET.sfx=!SET.sfx;const c=$('#sfxOn');if(c)c.checked=SET.sfx;
      try{localStorage.setItem('bite.set',JSON.stringify(SET))}catch{}
      if(!SET.sfx)stopAllAudio();
    }},
    {label:'Fullscreen: '+(document.fullscreenElement?'On':'Off'),action:()=>{
      if(document.fullscreenElement)document.exitFullscreen?.();
      else document.documentElement.requestFullscreen?.().catch(()=>{});
    }},
    {label:'Back',action:backMenu}
  ];
  const c=MENU_CFG[page];if(!c)return[];
  const defs=MENU_PAGE_ITEMS[page]||{},out=[];
  for(const k of Object.keys(c.items))if(c.items[k]&&defs[k])out.push({label:defs[k][1],action:()=>menuAction(defs[k][0])});
  return out;
}
function openMenu(page){
  if(!playing)return false;
  if(page==='levels'||page==='settings')MENU_BACK=MENU_OPEN&&!['levels','settings'].includes(MENU_OPEN)?MENU_OPEN:(MENU_BACK||'pause');
  MENU_OPEN=page;MENU_SEL=0;MENU_HITS=[];return true;
}
function backMenu(){MENU_OPEN=MENU_BACK||'pause';MENU_SEL=0;MENU_HITS=[]}
function closeMenu(){MENU_OPEN='';MENU_BACK='';MENU_SEL=0;MENU_HITS=[]}
function menuAction(a){
  if(a==='resume'){closeMenu();return}
  if(a==='play'){
    const b=playerOf();
    if(won||!b||(b.hp??b.maxHp??1)<=0)restartRuntimeLevel();
    closeMenu();return;
  }
  if(a==='restart'||a==='retry'){restartRuntimeLevel();closeMenu();return}
  if(a==='levels'||a==='settings'){openMenu(a);return}
  if(a==='main'){openMenu('main');return}
  if(a==='editor'){closeMenu();$('#bStop').click()}
}
function menuSelectLevel(name){
  if(!playing){closeMenu();return}
  const cur=sceneAt(RUN_SCENE||CUR_SCENE);
  if(cur&&cur.name.toLowerCase()===String(name).toLowerCase())restartRuntimeLevel();
  else changeSceneRuntime(name);
  closeMenu();
}
function restartRuntimeLevel(){
  if(!playing)return false;
  const sc=sceneAt(RUN_SCENE||CUR_SCENE);
  if(!sc||!sc.nodes||!sc.nodes.length)return false;
  run=JSON.parse(JSON.stringify(sc.nodes));
  run.forEach(n=>{n.vx=0;n.vy=0;n.sx=n.x;n.sy=n.y});
  resetLevel(run);startLevelAudio(run);startScripts();cam.x=0;cam.y=0;updateHud();
  log('Level restarted: '+sc.name,'ok');return true;
}
function menuPos(e){
  const r=cv.getBoundingClientRect(),k=cv.width/r.width;
  return{x:((e.clientX-r.left)*k-view.ox)/view.s,y:((e.clientY-r.top)*k-view.oy)/view.s};
}
function drawMenu(g){
  MENU_HITS=[];
  const page=MENU_OPEN,items=menuItems(page);
  const pcfg=page==='main'?MENU_CFG.main:page==='pause'?MENU_CFG.pause:page==='over'?MENU_CFG.over:null;
  const accent=(pcfg&&pcfg.accent)||(page==='over'?'#EF4444':page==='settings'?'#22C55E':'#39D5FF');
  const proj=(window.BiteProjectName&&window.BiteProjectName())||'MY GAME';
  const title=page==='levels'?'Select level':page==='settings'?'Settings':(pcfg&&pcfg.title)||(page==='main'?proj:page==='pause'?'Paused':'Game Over');
  const sub=page==='levels'?'Choose a scene to load':page==='settings'?'Sound and display':(pcfg&&pcfg.subtitle)||'';
  g.save();g.fillStyle='rgba(5,8,15,.84)';g.fillRect(0,0,GW,GH);
  g.textAlign='center';g.textBaseline='alphabetic';
  g.fillStyle=accent;g.font='bold 19px monospace';g.fillText(String(title).toUpperCase(),GW/2,48);
  let y=62;
  if(sub){g.fillStyle='#94A3B8';g.font='7px monospace';g.fillText(sub,GW/2,y);y+=8}
  if(page==='over'){g.fillStyle='#CBD5F5';g.font='8px monospace';g.fillText('Score '+score,GW/2,y+3);y+=10}
  const ih=16,gap=5,n=items.length,top=Math.max(y+6,Math.min(GH-20-n*(ih+gap),92));
  MENU_SEL=Math.max(0,Math.min(n-1,MENU_SEL));
  items.forEach((it,i)=>{
    const x=GW/2-74,w=148,iy=top+i*(ih+gap),on=i===MENU_SEL;
    g.fillStyle=on?accent:'rgba(148,163,184,.14)';g.fillRect(x,iy,w,ih);
    if(on){g.strokeStyle='#F8FAFC';g.lineWidth=1;g.strokeRect(x+.5,iy+.5,w-1,ih-1)}
    g.fillStyle=on?'#06121F':'#CBD5F5';g.font=(on?'bold ':'')+'8px monospace';g.textBaseline='middle';
    g.fillText(it.label,GW/2,iy+ih/2+1);
    MENU_HITS.push({x,y:iy,w,h:ih,i,fn:it.action});
  });
  g.textBaseline='alphabetic';g.fillStyle='#64748B';g.font='6px monospace';
  g.fillText('Up/Down select · Enter or click · Esc '+(page==='main'||page==='over'?'':'resume'),GW/2,GH-8);
  g.restore();
}
function openMenuEditor(start='main'){
  if(playing){log('Stop the game before editing menus','w');return}
  const draft=JSON.parse(JSON.stringify(MENU_CFG));
  let cur=MENU_PAGE_ITEMS[start]?start:'main';
  const o=el('div',{className:'modal'}),p=el('div',{className:'mp',style:'width:min(720px,96vw)'});
  const tabs=el('div',{className:'f2',style:'flex-wrap:wrap'}),body=el('div',{});
  const note=el('p',{className:'dim',textContent:'Menus show while the game is playing. Press Esc during Play for the pause menu. Preview starts the game with this menu open.'});
  const close=()=>o.remove();
  const render=()=>{
    tabs.innerHTML='';body.innerHTML='';
    for(const [k,label] of [['main','Main menu'],['pause','Pause menu'],['over','Game over']])
      tabs.append(el('button',{textContent:label,className:cur===k?'pri':'',onclick:()=>{cur=k;render()}}));
    const c=draft[cur],defs=MENU_PAGE_ITEMS[cur];
    body.append(el('label',{className:'chk'},el('input',{type:'checkbox',checked:c.enabled,onchange:e=>c.enabled=e.target.checked}),'Enable this menu'));
    if(cur==='main')body.append(el('label',{className:'chk'},el('input',{type:'checkbox',checked:c.showOnStart,onchange:e=>c.showOnStart=e.target.checked}),'Show automatically when Play starts'));
    body.append(el('div',{className:'f'},el('label',{textContent:'Title'}),el('input',{value:c.title,placeholder:cur==='main'?'(project name)':cur==='pause'?'Paused':'Game Over',oninput:e=>c.title=e.target.value})));
    body.append(el('div',{className:'f'},el('label',{textContent:'Subtitle'}),el('input',{value:c.subtitle,placeholder:'Optional small line',oninput:e=>c.subtitle=e.target.value})));
    body.append(el('div',{className:'f'},el('label',{textContent:'Accent color'}),el('input',{type:'color',value:c.accent,oninput:e=>c.accent=e.target.value})));
    const box=el('div',{className:'f2',style:'flex-wrap:wrap'});
    for(const k of Object.keys(defs))
      box.append(el('label',{className:'chk'},el('input',{type:'checkbox',checked:c.items[k]!==false,onchange:e=>c.items[k]=e.target.checked}),defs[k][1]));
    body.append(el('h3',{textContent:'Buttons'}),box,note);
  };
  const reset=el('button',{textContent:'Reset',onclick:()=>{draft[cur]=menuDefaults()[cur];render()}});
  const preview=el('button',{textContent:'Preview',onclick:()=>{
    MENU_CFG=normalizeMenus(draft);close();
    if(!playing)$('#bPlay').click();
    openMenu(cur);
  }});
  const cancel=el('button',{textContent:'Cancel',onclick:close});
  const save=el('button',{textContent:'Save menu',className:'pri',onclick:()=>{
    MENU_CFG=normalizeMenus(draft);window.BiteMarkDirty?.();close();log('Game menus saved','ok');
  }});
  p.append(el('h2',{textContent:'Game menus'}),tabs,body,el('div',{className:'f2'},reset,preview,el('span',{className:'grow'}),cancel,save));
  o.append(p);o.onclick=e=>{if(e.target===o)close()};document.body.append(o);render();
}
window.BiteMenus={
  data:()=>({menus:MENU_CFG}),
  load:m=>{MENU_CFG=normalizeMenus(m);closeMenu()},
  open:openMenuEditor,
  preview:pg=>{if(!playing)$('#bPlay').click();openMenu(pg)},
  page:()=>MENU_OPEN
};
$('#bMenus').onclick=()=>openMenuEditor();

/* ---------- automatic scripts: one-click Vexo behaviours ---------- */
const AUTO_BEHAVIOUR={CharacterBody2D:'move_player',Area2D:'collect_coin',Label:'score_label',SceneChanger:'change_scene',Sound:'sound_on_touch',AnimatedSprite2D:'play_animation'};
function attachVexo(n,code,label){
  if(!n||!code)return false;
  const old=(n.script||'').trim();
  if(old.includes(code.trim())){log(n.name+' already has this script','w');return false}
  snap();n.script=old?old+'\n\n'+code:code;n.scriptLang='vexo';
  window.BiteMarkDirty?.();refresh();log('Added '+label+' to '+n.name,'ok');return true;
}
function autoScript(n=sel){
  if(playing){log('Stop the game before adding scripts','w');return false}
  if(!n){log('Select a node first, then click Auto','w');return false}
  const key=AUTO_BEHAVIOUR[n.type];
  if(key&&window.Vexo){
    try{return attachVexo(n,window.Vexo.makeBehaviour(key),'"'+key+'" script')}
    catch(e){log('Could not add automatic script: '+e.message,'e');return false}
  }
  return attachVexo(n,VTPL(n),'the starter template');
}
const BEHAVIOUR_ORDER=['move_player','follow_player','collect_coin','take_damage','open_door','play_animation','enemy_damage','heal_on_touch','save_checkpoint','sound_on_start','sound_on_touch','win_level','change_scene','score_label','fall_respawn'];
function openBehaviourPicker(n=sel){
  if(playing){log('Stop the game before adding scripts','w');return}
  if(!n){log('Select a node first','w');return}
  const o=el('div',{className:'modal'}),p=el('div',{className:'mp',style:'width:min(620px,96vw)'});
  const V=window.Vexo,beh=V?V.BEHAVIOURS:{};
  const names=BEHAVIOUR_ORDER.filter(k=>beh[k]).concat(Object.keys(beh).filter(k=>!BEHAVIOUR_ORDER.includes(k)));
  const picker=el('select'),desc=el('p',{className:'dim'});
  names.forEach(k=>picker.add(new Option(k.replace(/_/g,' ')+' — '+beh[k].desc,k)));
  const sync=()=>{desc.textContent=beh[picker.value]?beh[picker.value].desc:''};
  picker.onchange=sync;sync();
  const close=()=>o.remove();
  p.append(el('h2',{textContent:'Automatic script: '+n.name}),
    el('p',{className:'dim',textContent:'Pick a ready-made Vexo behaviour. It is added to the node script automatically when you press Add script.'}),
    el('div',{className:'f'},el('label',{textContent:'Behaviour'}),picker),desc,
    el('div',{className:'f2'},
      el('button',{textContent:'Starter template',onclick:()=>{close();attachVexo(n,VTPL(n),'the starter template')}}),
      el('button',{textContent:'Open editor',onclick:()=>{close();openScript(n)}}),
      el('span',{className:'grow'}),
      el('button',{textContent:'Cancel',onclick:close}),
      el('button',{textContent:'Add script',className:'pri',onclick:()=>{const k=picker.value;close();try{attachVexo(n,V.makeBehaviour(k),'"'+k+'" script')}catch(e){log('Could not add script: '+e.message,'e')}}})));
  o.append(p);o.onclick=e=>{if(e.target===o)close()};document.body.append(o);
}
$('#tAuto').onclick=()=>autoScript(sel);

/* menu keyboard: pause, navigate and activate without touching the mouse */
addEventListener('keydown',e=>{
  if(!playing)return;
  const k=e.key.toLowerCase();
  if(k==='escape'||k==='p'){
    if(MENU_OPEN==='levels'||MENU_OPEN==='settings'){e.preventDefault();e.stopPropagation();backMenu();return}
    if(MENU_OPEN==='pause'){e.preventDefault();e.stopPropagation();closeMenu();return}
    if(MENU_OPEN){e.preventDefault();return}
    if(MENU_CFG.pause.enabled){e.preventDefault();e.stopPropagation();openMenu('pause')}
    return;
  }
  if(!MENU_OPEN)return;
  const items=menuItems(MENU_OPEN);if(!items.length)return;
  if(k==='arrowup'||k==='w'){MENU_SEL=(MENU_SEL-1+items.length)%items.length;e.preventDefault();e.stopPropagation()}
  else if(k==='arrowdown'||k==='s'){MENU_SEL=(MENU_SEL+1)%items.length;e.preventDefault();e.stopPropagation()}
  else if(k==='enter'||k===' '){const it=items[MENU_SEL];e.preventDefault();e.stopPropagation();if(it)it.action()}
},true);

/* undo / redo */
const US=[],RS=[],st=()=>JSON.stringify({nodes,nid});
function snap(){US.push(st());if(US.length>60)US.shift();RS.length=0}
function restore(s){const d=JSON.parse(s);nodes=d.nodes;nid=d.nid;sel=sel&&nodes.find(n=>n.id===sel.id)||null;refresh()}
function undo(){if(playing||!US.length)return;RS.push(st());restore(US.pop());log('Undo')}
function redo(){if(playing||!RS.length)return;US.push(st());restore(RS.pop());log('Redo')}
$('#bUndo').onclick=undo;$('#bRedo').onclick=redo;$('#fields').addEventListener('focusin',snap);$('#fields').addEventListener('input',()=>window.BiteMarkDirty?.());

/* ---------- AnimationPlayer timeline (Godot-style keyframes) ---------- */
const PROPS=[['x','X position'],['y','Y position'],['rotation','Rotation'],['alpha','Opacity'],['visible','Visible']];
const PROPKEYS=new Set(PROPS.map(p=>p[0])),PROPNAME=p=>(PROPS.find(x=>x[0]===p)||['',p])[1];
let AP_NODE=null,AP_ANIM='',AP_TIME=0,AP_PLAY=false,AP_TRACK=-1,AP_KEY=-1,AP_TIME_EL=null,AP_HEAD_EL=null;
const animOf=()=>AP_NODE&&AP_NODE.anims?AP_NODE.anims[AP_ANIM]:null;
function apValue(tr,t){
  const keys=(tr.keys||[]).slice().sort((a,b)=>a.t-b.t);if(!keys.length)return;
  if(tr.prop==='visible'){let v=undefined;for(const k of keys)if(k.t<=t+1e-6)v=k.v;return v===undefined?keys[0].v:v}
  if(t<=keys[0].t)return keys[0].v;
  if(t>=keys[keys.length-1].t)return keys[keys.length-1].v;
  for(let i=0;i<keys.length-1;i++)if(t>=keys[i].t&&t<=keys[i+1].t){
    const a=keys[i],b=keys[i+1],span=b.t-a.t;return span<=0?b.v:a.v+(b.v-a.v)*((t-a.t)/span);
  }
  return keys[keys.length-1].v;
}
function apTracks(){const a=animOf();return a?(a.tracks||[]).filter(tr=>PROPKEYS.has(tr.prop)):[]}
function apTrack(id,prop,create){
  const a=animOf();if(!a)return null;
  let tr=(a.tracks||[]).find(x=>x.id===id&&x.prop===prop);
  if(!tr&&create){tr={id,prop,keys:[]};a.tracks.push(tr)}
  return tr;
}
function apSample(t,list){
  const a=animOf();if(!a)return;
  for(const tr of a.tracks||[]){
    if(!PROPKEYS.has(tr.prop))continue;
    const tgt=(list||nodes).find(x=>x.id===tr.id);if(!tgt)continue;
    const v=apValue(tr,t);if(v===undefined)continue;
    if(tr.prop==='visible')tgt.hide=!v;else tgt[tr.prop]=v;
  }
}
function applyAnimationPlayers(L){
  for(const p of L){
    if(p.type!=='AnimationPlayer'||p.dead||p.playing===false)continue;
    const a=p.anims&&p.anims[p.playingAnim||p.autoplay];if(!a)continue;
    const len=Math.max(.05,a.length||1);
    p._apt=(p._apt||0)+STEP*(p.speed||1);
    let t=p._apt;
    if(a.loop!==false)t=t%len;else t=Math.min(t,len);
    for(const tr of a.tracks||[]){
      if(!PROPKEYS.has(tr.prop))continue;
      const tgt=L.find(x=>x.id===tr.id&&!x.dead);if(!tgt)continue;
      const v=apValue(tr,t);if(v===undefined)continue;
      if(tr.prop==='visible')tgt.hide=!v;else tgt[tr.prop]=v;
    }
  }
}
function apTickUI(){
  const a=animOf();if(!a)return;
  const len=Math.max(.05,a.length||1);
  if(AP_TIME_EL)AP_TIME_EL.textContent=AP_TIME.toFixed(2)+' / '+len.toFixed(2)+' s';
  if(AP_HEAD_EL)AP_HEAD_EL.style.left=Math.min(100,AP_TIME/len*100)+'%';
}
function apSetKey(tr,t,v){
  const ex=tr.keys.find(k=>Math.abs(k.t-t)<.005);
  if(ex)ex.v=v;else tr.keys.push({t:Math.round(t*100)/100,v});
  tr.keys.sort((a,b)=>a.t-b.t);
  window.BiteMarkDirty?.();
}
function apEditorStep(){
  if(!AP_NODE||playing||AP_PLAY===false||ws!=='game')return;
  const a=animOf();if(!a)return;
  const len=Math.max(.05,a.length||1);
  AP_TIME+=STEP*(AP_NODE.speed||1);
  if(a.loop!==false)AP_TIME%=len;
  else if(AP_TIME>=len){AP_TIME=len;AP_PLAY=false;apRender()}
  apSample(AP_TIME);apTickUI();
}
function closeAnimDock(){AP_NODE=null;AP_PLAY=false;AP_TRACK=-1;AP_KEY=-1;$('#animDock').classList.remove('on')}
function openAnimDock(n){
  if(!n||n.type!=='AnimationPlayer')return;
  AP_NODE=n;
  if(!n.anims||!Object.keys(n.anims).length)n.anims={idle:{length:1,loop:true,tracks:[]}};
  const names=Object.keys(n.anims);
  AP_ANIM=n.playingAnim&&n.anims[n.playingAnim]?n.playingAnim:n.autoplay&&n.anims[n.autoplay]?n.autoplay:names[0];
  AP_TIME=0;AP_PLAY=false;AP_TRACK=-1;AP_KEY=-1;
  $('#animDock').classList.add('on');apRender();
}
function apRender(){
  if(AP_NODE&&!nodes.includes(AP_NODE)){closeAnimDock();AP_NODE=null}
  if(!AP_NODE){$('#apHead').innerHTML='';$('#apTimeline').innerHTML='';AP_TIME_EL=null;AP_HEAD_EL=null;return}
  if(!animOf())AP_ANIM=Object.keys(AP_NODE.anims)[0]||'';
  const a=animOf();if(!a){closeAnimDock();return}
  const len=Math.max(.05,a.length||1),names=Object.keys(AP_NODE.anims),head=$('#apHead'),tl=$('#apTimeline');
  head.innerHTML='';tl.innerHTML='';
  const asel=el('select',{value:AP_ANIM,'aria-label':'Animation'});
  names.forEach(nm=>asel.add(new Option(nm,nm)));
  asel.onchange=()=>{AP_ANIM=asel.value;AP_TIME=0;AP_PLAY=false;AP_TRACK=-1;AP_KEY=-1;apRender()};
  const lenIn=el('input',{type:'number',min:.1,step:.1,value:len,style:'width:74px',title:'Animation length in seconds'});
  lenIn.onchange=()=>{a.length=Math.max(.1,+lenIn.value||1);AP_TIME=Math.min(AP_TIME,a.length);apRender()};
  const loop=el('input',{type:'checkbox',checked:a.loop!==false});
  loop.onchange=()=>{a.loop=loop.checked;window.BiteMarkDirty?.()};
  const play=el('button',{textContent:AP_PLAY?'❚❚ Pause':'▶ Play'});
  play.onclick=()=>{AP_PLAY=!AP_PLAY;if(AP_PLAY&&AP_TIME>=len)AP_TIME=0;apRender()};
  head.append(el('b',{textContent:'ANIMATION PLAYER'}),el('span',{className:'dim',textContent:AP_NODE.name}),asel,
    el('button',{textContent:'+ Animation',onclick:()=>{
      const nm=(prompt('New animation name','anim'+(names.length+1))||'').trim();if(!nm)return;
      if(AP_NODE.anims[nm]){log('Animation "'+nm+'" already exists','w');return}
      snap();AP_NODE.anims[nm]={length:1,loop:true,tracks:[]};AP_ANIM=nm;AP_TIME=0;window.BiteMarkDirty?.();apRender();
    }}),
    el('button',{textContent:'Delete',onclick:()=>{
      if(names.length<2){log('An AnimationPlayer needs at least one animation','w');return}
      if(!confirm('Delete animation "'+AP_ANIM+'"?'))return;
      snap();delete AP_NODE.anims[AP_ANIM];AP_ANIM=Object.keys(AP_NODE.anims)[0];AP_TIME=0;window.BiteMarkDirty?.();apRender();
    }}),
    el('span',{className:'sp'}),
    el('span',{className:'adnote',textContent:'Length'}),lenIn,el('label',{className:'chk'},loop,el('span',{textContent:'Loop'})),
    play,el('button',{textContent:'■ Stop',onclick:()=>{AP_PLAY=false;AP_TIME=0;apSample(0);apTickUI();apRender()}}),
    AP_TIME_EL=el('span',{className:'aptime'}),
    el('span',{className:'sp'}),
    el('button',{textContent:'✕ Close',onclick:closeAnimDock}));
  AP_TIME_EL.textContent=AP_TIME.toFixed(2)+' / '+len.toFixed(2)+' s';

  const tracks=apTracks(),side=el('div',{className:'adside'});
  const targets=nodes.filter(n=>n.id!==AP_NODE.id);
  const tsel=el('select',{'aria-label':'Key target'});
  targets.forEach(n=>tsel.add(new Option(n.name+' · '+n.type,n.id)));
  const selected=tracks[AP_TRACK]&&targets.some(n=>n.id===tracks[AP_TRACK].id)?tracks[AP_TRACK]:null;
  const defTarget=nodes.find(n=>n.id===AP_NODE.parent)||targets[0];
  if(selected)tsel.value=selected.id;else if(defTarget)tsel.value=defTarget.id;
  const psel=el('select',{'aria-label':'Key property'});
  PROPS.forEach(([k,l])=>psel.add(new Option(l,k)));
  if(selected)psel.value=selected.prop;
  const val=el('input',{type:'number',step:'any','aria-label':'Key value'});
  const curVal=()=>{
    const tgt=targets.find(n=>n.id===+tsel.value);
    if(!tgt){val.value=0;return}
    if(psel.value==='visible'){val.value=tgt.hide?0:1;return}
    val.value=tgt[psel.value]??0;
  };
  tsel.onchange=curVal;psel.onchange=curVal;curVal();
  const addKey=t=>{
    const tgt=targets.find(n=>n.id===+tsel.value);
    if(!tgt){log('Add a node to the scene first','w');return}
    snap();
    const tr=apTrack(tgt.id,psel.value,true),v=psel.value==='visible'?!!(+val.value):(+val.value||0);
    AP_TIME=Math.max(0,Math.min(len,t));apSetKey(tr,AP_TIME,v);
    AP_TRACK=apTracks().indexOf(tr);AP_KEY=tr.keys.findIndex(k=>Math.abs(k.t-AP_TIME)<.005);
    apSample(AP_TIME);apRender();
  };
  side.append(el('h4',{textContent:'Add keyframe'}),
    el('label',{className:'adnote',textContent:'Target node'}),tsel,
    el('label',{className:'adnote',textContent:'Property'}),psel,
    el('label',{className:'adnote',textContent:'Value at playhead'}),val,
    el('div',{className:'f2'},el('button',{className:'pri',textContent:'◆ Add key',onclick:()=>addKey(AP_TIME)}),el('button',{textContent:'At 0 s',onclick:()=>addKey(0)})),
    el('div',{className:'f2'},el('button',{textContent:'Delete key',disabled:AP_KEY<0,onclick:()=>{
      const tr=tracks[AP_TRACK];if(!tr||AP_KEY<0)return;snap();tr.keys.splice(AP_KEY,1);AP_KEY=-1;window.BiteMarkDirty?.();apRender();
    }}),el('button',{textContent:'Delete track',disabled:AP_TRACK<0,onclick:()=>{
      const tr=tracks[AP_TRACK];if(!tr)return;if(!confirm('Delete this whole track?'))return;
      snap();a.tracks.splice(a.tracks.indexOf(tr),1);AP_TRACK=-1;AP_KEY=-1;window.BiteMarkDirty?.();apRender();
    }})),
    el('p',{className:'adnote',textContent:'Click the ruler to scrub. Drag a diamond to retime it. Right-click a key for more. Double-click a track to key it there.'}));

  const box=el('div',{className:'adtlBox'}),inner=el('div',{className:'adtlInner'});
  const ruler=el('div',{className:'apruler'});
  for(let i=0;i<=4;i++){
    const tag=i===4?len.toFixed(2)+'s':(len*i/4).toFixed(2)+'s';
    ruler.append(el('i',{style:'left:'+(i*25)+'%',textContent:tag}));
  }
  const scrub=e=>{
    const r=ruler.getBoundingClientRect();
    AP_TIME=Math.max(0,Math.min(len,(e.clientX-r.left)/r.width*len));
    apSample(AP_TIME);apTickUI();
  };
  ruler.onpointerdown=scrub;ruler.onpointermove=e=>{if(e.buttons&1)scrub(e)};
  inner.append(ruler);
  if(!tracks.length)inner.append(el('div',{className:'animEmpty',textContent:'No tracks yet. Pick a target and property on the left, then add a key.'}));
  tracks.forEach((tr,ti)=>{
    const tgt=nodes.find(n=>n.id===tr.id),row=el('div',{className:'adtrack'});
    const name=el('div',{className:'tname',title:tgt?tgt.name+' · '+PROPNAME(tr.prop):'Missing node',onclick:()=>{AP_TRACK=ti;AP_KEY=-1;apRender()}},
      el('b',{textContent:tgt?tgt.name:'(missing)'}),el('span',{textContent:' · '+PROPNAME(tr.prop)+' ('+tr.keys.length+')'}));
    const line=el('div',{className:'tline',onclick:e=>{
      AP_TRACK=ti;const r=line.getBoundingClientRect();AP_TIME=Math.max(0,Math.min(len,(e.clientX-r.left)/r.width*len));AP_KEY=-1;apSample(AP_TIME);apTickUI();
    },ondblclick:e=>{
      const r=line.getBoundingClientRect();addKey(Math.max(0,Math.min(len,(e.clientX-r.left)/r.width*len)));
    }});
    tr.keys.forEach((key,ki)=>{
      const ke=el('i',{className:'apkey'+(ti===AP_TRACK&&ki===AP_KEY?' sel':''),style:'left:'+(key.t/len*100)+'%',title:key.t.toFixed(2)+'s = '+key.v});
      ke.onclick=e=>{e.stopPropagation();AP_TRACK=ti;AP_KEY=ki;AP_TIME=key.t;apSample(AP_TIME);apRender()};
      ke.oncontextmenu=e=>{e.preventDefault();e.stopPropagation();contextMenu(e.clientX,e.clientY,[{label:PROPNAME(tr.prop)+' key'},['Delete key',()=>{snap();tr.keys.splice(tr.keys.indexOf(key),1);AP_KEY=-1;window.BiteMarkDirty?.();apRender()},{danger:true}],['Move to playhead',()=>{snap();key.t=AP_TIME;tr.keys.sort((x,y)=>x.t-y.t);window.BiteMarkDirty?.();apRender()}]]);};
      ke.onpointerdown=e=>{
        if(e.button!==0)return;e.preventDefault();e.stopPropagation();snap();
        const r=line.getBoundingClientRect();
        const mv=ev=>{
          const t=Math.max(0,Math.min(len,Math.round(((ev.clientX-r.left)/r.width*len)*100)/100));
          key.t=t;AP_TIME=t;ke.style.left=(t/len*100)+'%';apSample(t);apTickUI();
        };
        const up=()=>{ke.removeEventListener('pointermove',mv);tr.keys.sort((x,y)=>x.t-y.t);AP_KEY=tr.keys.indexOf(key);window.BiteMarkDirty?.();apRender()};
        ke.setPointerCapture(e.pointerId);ke.addEventListener('pointermove',mv);ke.addEventListener('pointerup',up,{once:true});
      };
      line.append(ke);
    });
    row.append(name,line);inner.append(row);
  });
  const overlay=el('div',{className:'apoverlay'}),ph=el('div',{className:'applay'});
  ph.style.left=Math.min(100,AP_TIME/len*100)+'%';overlay.append(ph);inner.append(overlay);
  AP_HEAD_EL=ph;box.append(inner);
  tl.append(side,box);
  apTickUI();
}

/* extra workspace tools */
const oAR=animRefresh,oRA=renderAnim,oAdd=addSheet;
addSheet=function(name,img,fw,fh,m,sp){
  const s=oAdd(name,img,fw,fh,m,sp);
  if(!Object.values(ANIMS).some(a=>a.sheet===name)){ANIMS[name]={sheet:name,mode:'loop',frames:Array.from({length:s.n},(_,f)=>({f,dur:.1}))};if(!ANIMS[curAnim]){curAnim=name;curSheet=name}}
  return s;
};
animRefresh=function(){
  if(!ANIMS[curAnim]){const k=Object.keys(ANIMS)[0];if(k){curAnim=k;curSheet=ANIMS[k].sheet}}
  oAR();
};
renderAnim=function(){if(!ANIMS[curAnim]||!sheets[ANIMS[curAnim].sheet]){$('#prev').getContext('2d').clearRect(0,0,192,192);return}oRA()};

/* console / output panel */
const LOGS=[];let lf='all';
const showLog=o=>lf==='all'||(lf==='ok'?o.c!=='w'&&o.c!=='e':o.c===lf);
function drawLog(){
  const L=$('#log');L.innerHTML='';LOGS.filter(showLog).forEach(o=>L.append(el('div',{className:o.c,textContent:'['+o.t+'] '+o.m})));L.scrollTop=1e9;
  const cnt=c=>LOGS.filter(o=>o.c===c).length;$('[data-lf=w]').textContent='Warnings ('+cnt('w')+')';$('[data-lf=e]').textContent='Errors ('+cnt('e')+')';
}
[...$('#log').children].forEach(d=>LOGS.push({m:d.textContent,c:d.className,t:'--:--:--'}));
log=function(m,c=''){LOGS.push({m,c,t:new Date().toTimeString().slice(0,8)});if(LOGS.length>500)LOGS.shift();drawLog()};
$$('[data-lf]').forEach(b=>b.onclick=()=>{lf=b.dataset.lf;$$('[data-lf]').forEach(x=>x.classList.toggle('on',x===b));drawLog()});
$('#lClear').onclick=()=>{LOGS.length=0;drawLog()};
$('#lCopy').onclick=()=>{navigator.clipboard&&navigator.clipboard.writeText(LOGS.filter(showLog).map(o=>'['+o.t+'] '+o.m).join('\n')).then(()=>log('Console copied to clipboard','ok'))};
addEventListener('error',e=>log('Script error: '+e.message,'e'));drawLog();

/* ---------- tile painting ---------- */
const od=cv.onpointerdown,om=cv.onpointermove,ou=cv.onpointerup;
function paint(e){const p=wpos(e),k=Math.floor((p.x-sel.x)/T)+','+Math.floor((p.y-sel.y)/T);if(drag.er||tileErase)delete sel.cells[k];else sel.cells[k]=tile;KC.delete(sel)}
cv.onpointerdown=e=>{
  if(playing&&MENU_OPEN){
    cv.focus();const p=menuPos(e);
    for(const h of MENU_HITS)if(p.x>=h.x&&p.x<=h.x+h.w&&p.y>=h.y&&p.y<=h.y+h.h){MENU_SEL=h.i;h.fn();break}
    e.preventDefault();return;
  }
  pre=playing?null:st();
  if(!playing&&document.body.classList.contains('mPan')&&e.pointerType!=='mouse'){
    cv.focus();try{cv.setPointerCapture(e.pointerId)}catch{}
    drag={pan:1,touch:1,sx:e.clientX,sy:e.clientY,cx:cam.x,cy:cam.y,moved:0};
    return;
  }
  if(!playing&&sel&&sel.type==='TileMap'&&e.button===0){cv.focus();cv.setPointerCapture(e.pointerId);drag={tile:1,er:e.shiftKey};paint(e);return}
  const rmb=e.button===2;od(e);
  if(rmb&&drag&&drag.pan){drag.sy=e.clientY;drag.cy=cam.y;drag.moved=0}
};
cv.onpointermove=e=>{
  if(drag&&drag.tile){paint(e);return}
  const n=drag&&drag.n,x=n&&n.x,y=n&&n.y;om(e);
  if(drag&&drag.pan&&Math.hypot(e.clientX-drag.sx,e.clientY-(drag.sy??e.clientY))>4)drag.moved=1;
  if(drag&&drag.pan&&drag.touch){
    const rw=cv.getBoundingClientRect().width,k=rw>0?cv.width/rw:1,s=view.s>0?view.s:1;
    cam.x=Math.max(0,Math.min(640-GW,drag.cx-(e.clientX-drag.sx)/s*k));
    cam.y=Math.max(0,Math.min(360-GH,drag.cy-(e.clientY-drag.sy)/s*k));
  }
  if(n&&SET.snap){const z=SET.sz;n.x=Math.round(n.x/z)*z;n.y=Math.round(n.y/z)*z}
  if(n)moveKids(nodes,n,n.x-x,n.y-y);
};
cv.onpointerup=e=>{
  if(pre&&pre!==st()){US.push(pre);RS.length=0;window.BiteMarkDirty?.()}pre=null;
  if(drag&&drag.tile){drag=null;return}
  if(drag&&drag.pan&&!drag.moved&&!playing&&!drag.touch){
    const p=wpos(e),h=[...nodes].reverse().find(n=>p.x>=n.x&&p.x<=n.x+n.w&&p.y>=n.y&&p.y<=n.y+n.h);
    drag=null;sel=h||null;refresh();
    nodeMenu(e.clientX,e.clientY,h,p);return;
  }
  ou(e);
};

/* long-press opens the same context menu on touch devices */
function bindLongPress(target,hitTest){
  let timer=null,sx=0,sy=0;
  const clear=()=>{clearTimeout(timer);timer=null};
  target.addEventListener('pointerdown',e=>{
    if(e.pointerType==='mouse'||e.button!==0)return;
    const fn=hitTest(e);if(!fn)return;
    sx=e.clientX;sy=e.clientY;clear();
    timer=setTimeout(()=>{timer=null;try{navigator.vibrate&&navigator.vibrate(15)}catch{};fn()},520);
  },{passive:true});
  target.addEventListener('pointermove',e=>{if(timer&&Math.hypot(e.clientX-sx,e.clientY-sy)>10)clear()},{passive:true});
  target.addEventListener('pointerup',clear,{passive:true});
  target.addEventListener('pointercancel',clear,{passive:true});
  target.addEventListener('pointerleave',clear,{passive:true});
}
bindLongPress(cv,e=>{
  if(playing)return null;
  const x=e.clientX,y=e.clientY;
  return ()=>{
    const p=wpos({clientX:x,clientY:y});
    const n=[...nodes].reverse().find(o=>p.x>=o.x&&p.x<=o.x+o.w&&p.y>=o.y&&p.y<=o.y+o.h)||null;
    sel=n;refresh();nodeMenu(x,y,n,p);
  };
});
bindLongPress($('#list'),e=>{
  const li=e.target.closest('#list li');if(!li||!li._node||playing)return null;
  const x=e.clientX,y=e.clientY;
  return ()=>{
    const n=li._node;sel=n;refresh();
    nodeMenu(x,y,n,undefined,$('#list li.sel'));
  };
});

/* ---------- simulation (60 Hz fixed step) ---------- */
function solids(L){
  if(L.sol)return L.sol;const s=[];let W=640,H=180;
  for(const n of L){
    if(n.dead)continue;
    if(n.type==='StaticBody2D'||n.type==='MovingPlatform'||(n.type==='BreakableBox'&&!n.broken))s.push(n);
    else if(n.type==='TileMap')for(const[a,b]of tl(n))s.push({x:n.x+a*T,y:n.y+b*T,w:T,h:T});
  }
  for(const r of s){W=Math.max(W,r.x+r.w);H=Math.max(H,r.y+r.h)}
  L.sol=s;L.W=W;L.H=H;return s;
}
function resetLevel(L){
  won=false;WINNER=null;WIN_T=0;WIN_TEXT='';WIN_NEXT='';LAST_CHECKPOINT=null;
  for(const n of L){
    n._vxHits=new Set();
    if(n.type==='Enemy'){
      n.dead=false;n._init=0;n._hitT=0;n._at=0;n.vx=0;n.vy=0;n.as='idle';
      n._dir=(n.dir??-1)<0?-1:1;n.flip=false;
    }else if(n.type==='BreakableBox'){
      n.dead=false;n.broken=false;n._breakT=0;n._hitT=0;n._hits=Math.max(1,+n.hits||1);
    }else if(n.type==='MovingPlatform'){
      n._x0=n.x;n._y0=n.y;n._px=n.x;n._py=n.y;n._t=0;
    }else if(n.type==='FireTrap'){
      n._t=0;n._on=n.startOn!==false;
    }else if(n.type==='Spring'){
      n._t=0;
    }else if(n.type==='Checkpoint'){
      n.activated=false;n._flagT=0;n._inside=false;
    }else if(n.type==='EndCheckpoint'){
      n._inside=false;n._nag=0;
    }else if(n.type==='CharacterBody2D'){
      n.dead=false;n.maxHp=Math.max(1,+n.maxHp||3);n.hp=n.maxHp;n.inv=0;n.stun=0;
      n.vx=0;n.vy=0;n.floor=false;n.jn=0;n.as='Idle';n.at=0;
    }else if(n.type==='Sound'){
      n._inside=false;n._played=false;n._keyDown=false;
    }else if(n.type==='SceneChanger'){
      n._inside=false;n._used=false;n._to='';n._t=0;
    }
  }
  const st=L.find(n=>n.type==='StartCheckpoint'&&!n.hide&&n.active!==false);
  const b=L.find(n=>n.type==='CharacterBody2D'&&!n.dead);
  if(b){
    if(st){b.x=st.x+st.w/2-b.w/2;b.y=st.y+st.h-b.h}
    b.sx=b.x;b.sy=b.y;
    if(st&&st.heal!==false)b.hp=b.maxHp;
    for(const p of L)if(p.type==='CharacterBody2D'&&p!==b){
      p.maxHp=Math.max(1,+p.maxHp||3);p.hp=p.maxHp;p.sx=p.x;p.sy=p.y;
    }
  }
  L.sol=null;fx=[];
  updateHud();
  const en=L.filter(n=>n.type==='Enemy').length;
  if(en||st)log('Level ready: '+en+' enemy'+(en===1?'':'s')+', spawn at '+(st?st.name:'player start'),'ok');
}
/* ---------- multi-scene runtime: level changes, doors and next-scene flow ---------- */
function changeSceneRuntime(name,opt={}){
  if(!playing){log('Scene change to "'+name+'" needs Play','w');return false}
  const sc=sceneByName(name);
  if(!sc){log('Scene not found: "'+name+'"','e');return false}
  if(!sc.nodes||!sc.nodes.length){log('Scene "'+sc.name+'" is empty','w');return false}
  const old=playerOf(),hp=old?old.hp:null;
  run=JSON.parse(JSON.stringify(sc.nodes));
  run.forEach(n=>{n.vx=0;n.vy=0;n.sx=n.x;n.sy=n.y});
  RUN_SCENE=sc.id;
  resetLevel(run);
  const b=playerOf();
  if(b&&opt.keepHealth&&hp!=null)b.hp=Math.max(1,Math.min(+hp,b.maxHp||3));
  if(!b)log('Scene "'+sc.name+'" has no CharacterBody2D player','w');
  startScripts();
  startLevelAudio(run);
  cam.x=0;cam.y=0;
  updateHud();
  log('Scene changed to "'+sc.name+'"','ok');
  return true;
}
function updateScenePortals(L,b){
  for(const n of L){
    if(n.type!=='SceneChanger'||n.dead||n.hide)continue;
    if(n._to){
      n._t=(n._t||0)+STEP;
      if(n._t>=Math.max(0,+n.delay||0)){const to=n._to;n._to='';changeSceneRuntime(to,{keepHealth:n.keep});return}
      continue;
    }
    const h=hit(b,n);
    if(h&&!n._inside){
      n._inside=true;
      if(n._used)continue;
      n._used=true;n._t=0;
      if(!n.scene){log('Level door "'+n.name+'" has no target scene','w');continue}
      if(!sceneByName(n.scene)){log('Scene not found: "'+n.scene+'"','e');continue}
      if((+n.delay||0)<=0){changeSceneRuntime(n.scene,{keepHealth:n.keep});return}
      n._to=n.scene;log('Entering '+n.scene+'…','ok');
    }else if(!h)n._inside=false;
  }
}
function updatePlatforms(L){
  for(const p of L){
    if(p.type!=='MovingPlatform'||p.dead)continue;
    if(p._x0===undefined){p._x0=p.x;p._y0=p.y;p._px=p.x;p._py=p.y;p._t=0}
    const dist=+p.dist||0,speed=Math.max(1,+p.speed||40),dur=Math.abs(dist)/speed||1;
    p._t=(p._t||0)+STEP;
    const u=((p._t/dur)+(+p.phase||0)/dur)%2,tri=u<=1?u:2-u;
    p._px=p.x;p._py=p.y;
    if((p.axis||'x')==='y'){p.x=p._x0;p.y=p._y0+tri*dist}
    else{p.x=p._x0+tri*dist;p.y=p._y0}
  }
}
function carryPlatforms(L){
  for(const b of L){
    if(b.type!=='CharacterBody2D'||b.dead||(b.vy||0)<0)continue;
    for(const p of L){
      if(p.type!=='MovingPlatform'||p.dead||p._px===undefined)continue;
      if(b.x+b.w>p._px+1&&b.x<p._px+p.w-1&&Math.abs((b.y+b.h)-p._py)<=6){
        b.x+=p.x-p._px;b.y=p.y-b.h;b.floor=true;b.coy=.1;break;
      }
    }
  }
}
function updateAmbient(L){
  for(const n of L){
    if(n.type==='FireTrap'){
      if(n.cycle!==false){
        n._t=(n._t||0)+STEP;
        const on=Math.max(.1,+n.onTime||1.4),off=Math.max(.1,+n.offTime||1.1);
        n._on=(n._t%(on+off))<on;
      }else n._on=n.startOn!==false;
    }else if(n.type==='Spring'&&n._t>0)n._t=Math.max(0,n._t-STEP);
    else if(n.type==='Checkpoint'&&n.activated)n._flagT=(n._flagT||0)+STEP;
    else if(n.type==='BreakableBox'&&n.broken&&!n.dead){
      n._breakT=(n._breakT||0)+STEP;
      if(n._breakT>.4){n.dead=true;L.sol=null}
    }else if(n.type==='EndCheckpoint'&&n._nag>0)n._nag=Math.max(0,n._nag-STEP);
  }
}
function hitBox(n){
  if(!n||n.dead||n.broken)return;
  n._hitT=.2;
  n._hits=(n._hits??Math.max(1,+n.hits||1))-1;
  if(n._hits>0){log('Box cracked, '+n._hits+' hit'+(n._hits===1?'':'s')+' left','w');return}
  n.broken=true;n._breakT=0;
  if(run)run.sol=null;
  const pts=Math.max(0,+n.points||0);
  if(pts){score+=pts;updateHud()}
  if(n.drop&&run){
    const f=FRUITS[Math.floor(Math.random()*FRUITS.length)];
    run.push({id:nid++,type:'Area2D',name:'Coin',x:n.x+n.w/2-8,y:n.y-18,w:16,h:16,tex:'Items/Fruits/'+f+'.png',anim:'',flip:false,speed:1,fps:12,alpha:1,rotation:0,dead:false});
  }
  log('Box broken: '+n.name+(pts?' +'+pts+' score':''),'ok');
}
function touchNodes(L,b){
  for(const n of L){
    if(n.dead||n.hide)continue;
    if(n.type==='Spike'){
      const box={x:n.x+2,y:n.y+Math.max(2,n.h*.35),w:Math.max(1,n.w-4),h:Math.max(1,n.h*.65)};
      if(hit(b,box)){
        if(n.respawn)respawnPlayer(b,'Spikes! Respawned at '+(LAST_CHECKPOINT?LAST_CHECKPOINT.name:'the start'));
        else hurtPlayer(b,n.dmg,b.x+b.w/2);
      }
    }else if(n.type==='Spring'){
      if((n._t||0)<=0&&hit(b,n)&&(b.vy||0)>=0&&(b.y+b.h)<=n.y+n.h){
        b.y=n.y-b.h;b.vy=-Math.abs(+n.power||420);b.jn=1;b.coy=0;b.floor=false;n._t=.45;
      }
    }else if(n.type==='FireTrap'){
      const on=n._on??n.startOn!==false;
      if(on&&hit(b,{x:n.x+2,y:n.y+4,w:Math.max(1,n.w-4),h:Math.max(1,n.h-6)}))hurtPlayer(b,n.dmg,b.x+b.w/2);
    }else if(n.type==='Checkpoint'){
      const h=hit(b,n);
      if(h&&!n._inside){
        n._inside=true;
        const fresh=!n.activated;
        if(fresh){
          n.activated=true;n._flagT=0;LAST_CHECKPOINT=n;
          for(const p of L)if(p.type==='CharacterBody2D'){p.sx=n.x+n.w/2-p.w/2;p.sy=n.y+n.h-p.h}
          log('Checkpoint reached: '+n.name,'ok');
        }
        if(fresh||n.reusable){
          if(n.heal!==false){b.hp=b.maxHp||3;updateHud()}
          if(+n.bonus){score+=+n.bonus;updateHud()}
        }
      }else if(!h)n._inside=false;
    }else if(n.type==='EndCheckpoint'){
      if(hit(b,n)){
        if(n.requireCoins&&L.some(x=>x.type==='Area2D'&&!x.dead)){
          if((n._nag||0)<=0){log('Collect all coins before finishing','w');n._nag=1.5}
        }else if(!won)winLevel(n);
      }
    }
  }
}
function updateEnemies(L,S){
  const chars=L.filter(n=>n.type==='CharacterBody2D'&&!n.dead);
  for(const e of L){
    if(e.type!=='Enemy'||e.dead)continue;
    const cfg=ENEMY_SKINS[e.skin]||ENEMY_SKINS.AngryPig;
    if(!e._init){
      e._init=1;e.hx=e.x;e.hy=e.y;e._hp=Math.max(1,+e.hp||1);
      e._dir=(e.dir??-1)<0?-1:1;e.vx=0;e.vy=0;e.as='idle';e._hitT=0;e._at=0;
      if(!e.behavior)e.behavior=cfg.fly?'fly':cfg.fixed?'static':'patrol';
    }
    e._at+=STEP;if(e._hitT>0)e._hitT-=STEP;
    const bh=e.behavior||'patrol',fly=bh==='fly';
    let tgt=null,td=1e9;
    for(const b of chars){const d=Math.hypot(b.x-e.x,b.y-e.y);if(d<td){td=d;tgt=b}}
    const chase=bh==='chase'&&tgt&&td<(+e.sight||150);
    let ax=0,ay=0;
    if(bh!=='static'&&+e.speed>0){
      if(chase){
        ax=Math.sign(tgt.x+tgt.w/2-(e.x+e.w/2));
        if(fly)ay=Math.sign(tgt.y+tgt.h/2-(e.y+e.h/2));
      }else ax=e._dir;
      if(fly&&!chase)ay=Math.sin((gt+e.id)*2)*.6;
    }
    e.vx=ax*(+e.speed||0);
    e.vy=fly?ay*(+e.speed||0):Math.min((e.vy||0)+SET.g*STEP,420);
    const ox=e.x,oy=e.y;
    e.x+=e.vx*STEP;
    if(e.vx)for(const s of S){
      if(s===e)continue;
      if(hit(e,s)){if(e.vx>0)e.x=s.x-e.w;else e.x=s.x+s.w;e._dir*=-1;e.vx=0}
    }
    if(!fly){
      e.y+=e.vy*STEP;e.floor=false;
      for(const s of S){
        if(s===e)continue;
        if(hit(e,s)){if(e.vy>0){e.y=s.y-e.h;e.floor=true}else e.y=s.y+s.h;e.vy=0}
      }
      if(e.floor&&e.ledge!==false&&Math.abs(e.vx)>.1){
        const px=e._dir>0?e.x+e.w+2:e.x-2;
        const ground=S.some(s=>px>=s.x&&px<=s.x+s.w&&e.y+e.h>=s.y-2&&e.y+e.h<=s.y+10);
        if(!ground)e._dir*=-1;
      }
    }else{
      if(e.y<0)e.y=0;
      if(e.y>Math.max(0,L.H-e.h))e.y=Math.max(0,L.H-e.h);
    }
    const rng=+e.range||0;
    if(rng>0&&Math.abs(e.x-e.hx)>rng){e.x=e.hx+Math.sign(e.x-e.hx)*rng;e._dir*=-1}
    if(e.y>L.H+240){e.dead=true;continue}
    const moved=Math.abs(e.x-ox)>.01||Math.abs(e.y-oy)>.01;
    e.as=e._hitT>0?'hit':moved?'move':'idle';
    e.flip=e._dir>0;
    moveKids(L,e,e.x-ox,e.y-oy);
    for(const b of chars){
      if(!hit(b,e))continue;
      const stomp=e.stomp!==false&&b.vy>60&&(b.y+b.h)-e.y<Math.min(20,Math.max(8,e.h*.6))&&b.y<e.y;
      if(stomp){
        damageEnemy(e,1e6);
        b.vy=-Math.max(220,(b.jump||270)*.8);b.jn=1;b.floor=false;
        break;
      }
      hurtPlayer(b,e.dmg,e.x+e.w/2);
    }
  }
}
/* fire Vexo `on collision(other)` once per new overlap, like the Python engine */
const NO_HIT=new Set(['Camera2D','AnimationPlayer','ParallaxBackground','Node2D','TileMap','Area2D']);
function vexoCollisions(L){
  for(const n of L){
    if(n.dead)continue;
    const vx=VX.get(n);if(!vx)continue;
    const prev=n._vxHits||new Set(),now=new Set();
    for(const o of L){
      if(o===n||o.dead||NO_HIT.has(o.type)||!hit(n,o))continue;
      now.add(o.id);
      if(!prev.has(o.id))fireVexo(n,'collision',o);
    }
    n._vxHits=now;
  }
}
gameStep=function(){
  if(playing&&MENU_OPEN)return;
  gt+=STEP;const L=playing?run:nodes;
  if(!playing)fx=[];
  else{
    stepScripts(L);
    if(won){
      WIN_T+=STEP;
      fx.forEach(e=>e.t+=STEP);fx=fx.filter(e=>e.t<.4);
      if(WIN_NEXT&&sceneByName(WIN_NEXT)){
        const delay=Math.max(0,+(WINNER&&WINNER.delay)||1.5);
        if(WINNER&&WINNER.autoNext){
          if(WIN_T>=delay)changeSceneRuntime(WIN_NEXT,{keepHealth:true});
        }else{
          const dn=!!(keys.enter||keys[' ']);
          if(dn&&!WIN_KEY_DOWN)changeSceneRuntime(WIN_NEXT,{keepHealth:true});
          WIN_KEY_DOWN=dn;
        }
      }
    }else{
      updatePlatforms(L);carryPlatforms(L);updateAmbient(L);
      const S=solids(L);
      for(const b of L){
        if(b.type!=='CharacterBody2D'||b.dead)continue;
        const stunned=(b.stun||0)>0;if(stunned)b.stun-=STEP;
        b.inv=Math.max(0,(b.inv||0)-STEP);
        const ax=stunned?0:b.ctrl===false?Math.sign(b.vx||0):(keys.d||keys.arrowright?1:0)-(keys.a||keys.arrowleft?1:0),J=b.jump||270;
        const ox=b.x,oy=b.y;
        if(b.ctrl!==false&&!stunned)b.vx=ax*(b.run||100);
        if(ax)b.flip=ax<0;
        b.vy=Math.min(b.vy+SET.g*(b.grav??1)*STEP,420);
        b.coy=b.floor?.1:Math.max(0,(b.coy||0)-STEP);
        const jp=!stunned&&b.ctrl!==false&&(keys[' ']||keys.w||keys.arrowup);
        if(jp&&!b.jh){if(b.coy>0){b.vy=-J;b.jn=1;b.coy=0;b.floor=false;playSfx('jump',.6)}else if(b.dj!==false&&(b.jn||0)<2){b.vy=-J*.9;b.jn=2;playSfx('jump',.5)}}
        b.jh=jp;
        b.x+=b.vx*STEP;if(b.vx)for(const s of S)if(hit(b,s))b.x=b.vx>0?s.x-b.w:s.x+s.w;
        b.y+=b.vy*STEP;b.floor=false;
        for(const s of S)if(hit(b,s)){
          if(b.vy>0){b.y=s.y-b.h;b.floor=true}
          else{b.y=s.y+s.h;if(s.type==='BreakableBox')hitBox(s)}
          b.vy=0;
        }
        if(b.floor)b.jn=0;
        if(b.y>L.H+120)respawnPlayer(b,'Player fell and respawned at '+(LAST_CHECKPOINT?LAST_CHECKPOINT.name:'the start'));
        moveKids(L,b,b.x-ox,b.y-oy);const st=!b.floor?(b.jn===2&&b.vy<0?'Double Jump':b.vy<0?'Jump':'Fall'):ax?'Run':'Idle';
        if(st!==b.as){b.as=st;b.at=0}b.at+=STEP;b.anim=ax?'Run':'Idle';
        for(const a of L)if(a.type==='Area2D'&&!a.dead){const h=hit(b,a),hk=HK.get(a),vxa=VX.get(a);
          if(hk&&hk.body){if(h&&!a.ins){a.ins=1;callHook(a,'body',b)}else if(!h)a.ins=0}
          else if(vxa){if(h&&!a.ins){a.ins=1;fireVexo(a,'collision',b)}else if(!h)a.ins=0}
          else if(h){a.dead=true;score++;updateHud();playSfx('collect_apple',.7);fx.push({x:a.x+a.w/2-16,y:a.y+a.h/2-16,t:0});log('Area2D: '+a.name+' collected','ok')}}
        touchNodes(L,b);
        updateScenePortals(L,b);
        const C=L.find(n=>n.type==='Camera2D'&&!n.hide);
        if(C&&C.follow===false){cam.x=C.x;cam.y=C.y}else{const k=C?C.smooth:.12;cam.x+=(b.x+b.w/2-GW/2-cam.x)*k;cam.y+=(b.y+b.h/2-GH/2-cam.y)*k;
          if(!C||C.limit!==false){cam.x=Math.max(0,Math.min(L.W-GW,cam.x));cam.y=Math.max(0,Math.min(Math.max(0,L.H-GH),cam.y))}}
      }
      updateEnemies(L,S);
      updateSoundNodes(L);
      vexoCollisions(L);
      fx.forEach(e=>e.t+=STEP);fx=fx.filter(e=>e.t<.4);
    }
  }
  for(const n of L){
    if(n.type==='AnimatedSprite2D'){const a=apOf(n);a.play(n.anim);if(n.playing===false){const m=ANIMS[n.anim]?ANIMS[n.anim].frames.length:1;a.i=Math.max(0,Math.min(n.frame|0,m-1));a.t=0;a.done=false}else a.update(STEP,n.speed||1)}
    else if(n.type==='CharacterBody2D'&&!n.skin){const a=apOf(n);a.play(n.anim);a.update(STEP,n.speed||1)}
  }
  if(playing)applyAnimationPlayers(L);
  apEditorStep();
};

/* ---------- renderer (nearest-neighbor, integer scale) ---------- */
const parTiles=new WeakMap();
function parTile(im){
  const s=im.naturalWidth||im.width,e=parTiles.get(im),w=GW+s,h=GH+s;
  if(e&&e.w===w&&e.h===h&&e.src===im.currentSrc)return e;
  const c=document.createElement('canvas');c.width=w;c.height=h;const g=c.getContext('2d');
  for(let y=0;y<h;y+=s)for(let x=0;x<w;x+=s)g.drawImage(im,x,y);
  const t={c,w,h,s,src:im.currentSrc};parTiles.set(im,t);return t;
}
function drawDoor(g,x,y,w,h,n,open,live,t){
  const W=Math.max(4,Math.round(w)),H=Math.max(6,Math.round(h));
  const b=Math.max(1,Math.min(Math.round(W/14),Math.floor(W/4)));
  const top=Math.max(3,Math.min(Math.round(H*.18),H-5));
  const ax=Math.max(1,Math.min(Math.round(W*.16),Math.floor(W/4)));
  if(open){g.globalAlpha=.10+.05*Math.sin(t*3);g.fillStyle='#2DD4BF';g.fillRect(x-2,y-2,W+4,H+4);g.globalAlpha=1}
  g.fillStyle='#3B4A63';
  g.fillRect(x,y+top,W,H-top);
  g.fillRect(x+ax,y+Math.round(top*.45),W-2*ax,top);
  g.fillRect(x+ax*2,y,W-4*ax,Math.max(1,Math.round(top*.55)));
  g.fillStyle='#7C8BA1';g.fillRect(x,y+top,1,H-top);g.fillRect(x,y+top,W,1);
  g.fillStyle='#1E293B';g.fillRect(x+W-1,y+top,1,H-top);
  const px=x+b,py=y+top+Math.round(b*.5),pw=Math.max(1,W-2*b),ph=Math.max(1,H-top-b);
  g.fillStyle=open?'#083B38':'#3F1D1D';g.fillRect(px,py,pw,ph);
  g.fillStyle=open?'#0F766E':'#5B1F1F';
  g.fillRect(x+b+ax,y+Math.round(top*.5),Math.max(1,W-2*(b+ax)),Math.max(1,Math.round(top*.5)));
  g.fillRect(x+b+Math.round(ax*.45),y+Math.round(top*.8),Math.max(1,W-2*(b+Math.round(ax*.45))),Math.max(1,Math.round(top*.35)));
  const plank=Math.max(3,Math.round(pw/5));
  g.fillStyle=open?'#0B5C57':'#4A2016';
  for(let sx=px+plank;sx<px+pw-1;sx+=plank)g.fillRect(sx,py+2,1,Math.max(1,ph-4));
  g.fillStyle=open?'#0A2F2D':'#2C120C';
  g.fillRect(px,py+Math.round(ph*.34),pw,1);g.fillRect(px,py+Math.round(ph*.68),pw,1);
  const cx=x+Math.round(W/2),cy=y+Math.round(top*.55);
  g.fillStyle=open?'#5EEAD4':'#F87171';
  g.fillRect(cx,cy-2,1,1);g.fillRect(cx-1,cy-1,3,1);g.fillRect(cx-2,cy,5,1);g.fillRect(cx-1,cy+1,3,1);g.fillRect(cx,cy+2,1,1);
  g.fillStyle='#FBBF24';g.fillRect(x+W-b-3,y+Math.round(H*.58),2,3);
  g.fillStyle='#B45309';g.fillRect(x+W-b-3,y+Math.round(H*.58)+2,2,1);
  g.fillStyle='#64748B';g.fillRect(x,y+H-b,W,b);
  g.fillStyle='#CBD5E1';g.fillRect(x,y+H-b,W,1);
  if(open&&live)for(let i=0;i<3;i++){
    const p=(t*.30+i*.33)%1,fx=px+1+Math.round((.5+.5*Math.sin(t*1.7+i*2.1))*(pw-3)),fy=py+2+Math.round((1-p)*Math.max(1,ph-5));
    g.fillStyle=i===1?'#99F6E4':'#2DD4BF';g.fillRect(fx,fy,1,1);
  }
  if(n._to){g.globalAlpha=.2+.3*Math.abs(Math.sin(t*18));g.fillStyle='#E0FFFB';g.fillRect(px,py,pw,ph);g.globalAlpha=1}
  if(!live&&n.label){
    const tw=Math.max(14,n.label.length*4+6),tx=x+Math.round(W/2)-Math.round(tw/2),ty=y-10;
    g.fillStyle='rgba(5,8,15,.78)';g.fillRect(tx,ty,tw,8);
    g.fillStyle=open?'#5EEAD4':'#F87171';g.fillRect(tx,ty,tw,1);
    g.fillStyle='#E2E8F0';g.font='7px monospace';g.textAlign='center';g.textBaseline='alphabetic';
    g.fillText(n.label,x+Math.round(W/2),ty+6);g.textAlign='left';
  }
}
renderGame=function(){
  fit(cv);calls=0;const L=playing?run:nodes;
  bg.imageSmoothingEnabled=!pp;bg.fillStyle=SET.bg;bg.fillRect(0,0,GW,GH);calls++;
  const cx=pp?Math.round(cam.x):cam.x,cy=pp?Math.round(cam.y):cam.y,R=v=>pp?Math.round(v):v;
  for(const n of L)if(n.type==='ParallaxBackground'&&!n.hide){
    const im=IM(n.tex);if(!rdy(im))continue;const T=parTile(im),s=T.s,ox=R(((gt*n.sx)%s+s)%s),oy=R(((gt*n.sy)%s+s)%s);
    bg.drawImage(T.c,ox-s,oy-s);calls++;
  }
  for(const n of L){
    if(n.dead||n.hide||n.type==='ParallaxBackground')continue;
    const x=R(n.x-cx),y=R(n.y-cy),ty=n.type;calls++;
    const rot=+n.rotation||0,al=n.alpha===undefined?1:n.alpha,useTr=rot!==0||al!==1;
    if(useTr){bg.save();if(al!==1)bg.globalAlpha=al;if(rot){bg.translate(x+n.w/2,y+n.h/2);bg.rotate(rot*Math.PI/180);bg.translate(-(x+n.w/2),-(y+n.h/2))}}
    if(ty==='TileMap'){const ts=IM(TS);if(rdy(ts))for(const[a,b,i]of tl(n)){const px=x+a*T,py=y+b*T;if(px>-T&&py>-T&&px<GW&&py<GH)bg.drawImage(ts,(i%COLS)*T,Math.floor(i/COLS)*T,T,T,px,py,T,T)}
      if(!playing&&n===sel){bg.strokeStyle='#ffffff22';bg.beginPath();for(let gx=((x%T)+T)%T;gx<=GW;gx+=T){bg.moveTo(gx+.5,0);bg.lineTo(gx+.5,GH)}for(let gy=((y%T)+T)%T;gy<=GH;gy+=T){bg.moveTo(0,gy+.5);bg.lineTo(GW,gy+.5)}bg.stroke()}}
    else if(ty==='StaticBody2D'){bg.fillStyle=n.col||'#24324d';bg.fillRect(x,y,n.w,n.h);bg.fillStyle='#39D5FF';bg.fillRect(x,y,n.w,2)}
    else if(ty==='MovingPlatform'){
      bg.fillStyle='#334155';bg.fillRect(x,y,n.w,n.h);
      bg.fillStyle='#64748b';bg.fillRect(x,y,n.w,3);
      const mx=x+n.w/2,my=y+n.h/2;bg.fillStyle='#38BDF8';bg.beginPath();
      if((n.axis||'x')==='y'){bg.moveTo(mx,my-4);bg.lineTo(mx+4,my+2);bg.lineTo(mx-4,my+2)}
      else{bg.moveTo(mx-5,my);bg.lineTo(mx+1,my-4);bg.lineTo(mx+1,my+4)}
      bg.fill();
    }
    else if(ty==='Enemy'){
      const cfg=ENEMY_SKINS[n.skin]||ENEMY_SKINS.AngryPig,state=playing&&n.as?n.as:'idle';
      const d=(state==='hit'&&cfg.hit)||(state==='move'&&cfg.move)||cfg.idle;
      const f=Math.floor(gt*Math.max(1,+n.fps||10))%Math.max(1,d[1]);
      cell(bg,IM('Enemies/'+n.skin+'/'+d[0]),cfg.fw,cfg.fh,f,R(x+(n.w-cfg.fw)/2),R(y+n.h-cfg.fh),n.flip);
      if(playing&&n._hitT>0){bg.fillStyle='rgba(255,255,255,.45)';bg.fillRect(x,y,n.w,n.h)}
    }
    else if(ty==='Spike'){
      const im=IM('Traps/Spikes/Idle.png');
      if(rdy(im))for(let px=x;px<x+n.w;px+=16)bg.drawImage(im,0,0,16,16,px,R(y+n.h-16),Math.min(16,x+n.w-px),16);
      else{bg.fillStyle='#F87171';bg.fillRect(x,y,n.w,n.h)}
    }
    else if(ty==='Spring'){
      const jump='Traps/Trampoline/Jump (28x28).png';
      if((n._t||0)>0&&rdy(IM(jump))){const f=Math.min(7,Math.floor((0.45-n._t)/0.45*8));cell(bg,IM(jump),28,28,f,x,y)}
      else{const im=IM('Traps/Trampoline/Idle.png');if(rdy(im))bg.drawImage(im,0,0,28,28,x,y,28,28);else{bg.fillStyle='#A3E635';bg.fillRect(x,y,n.w,n.h)}}
    }
    else if(ty==='FireTrap'){
      const on=playing?(n._on??n.startOn!==false):n.startOn!==false;
      if(on){const im=IM('Traps/Fire/On (16x32).png');if(rdy(im))cell(bg,im,16,32,Math.floor(gt*12)%3,x,y);else{bg.fillStyle='#FB923C';bg.fillRect(x,y,n.w,n.h)}}
      else{const im=IM('Traps/Fire/Off.png');if(rdy(im))bg.drawImage(im,0,0,16,32,x,y,16,32);else{bg.fillStyle='#475569';bg.fillRect(x,y,n.w,n.h)}}
    }
    else if(ty==='BreakableBox'){
      const style=Math.max(1,Math.min(3,+n.box||1));let file=boxTex(style,'idle'),fr=0;
      if(n.broken){file=boxTex(style,'break');fr=Math.min(3,Math.floor((n._breakT||0)/.4*4))}
      else if(playing&&n._hitT>0){file=boxTex(style,'hit');fr=Math.min(BOX_HIT[style]-1,Math.floor((.2-n._hitT)*40))}
      const im=IM(file);if(rdy(im))bg.drawImage(im,fr*28,0,28,24,x,y,28,24);else{bg.fillStyle='#D97706';bg.fillRect(x,y,n.w,n.h)}
    }
    else if(ty==='StartCheckpoint'||ty==='Checkpoint'||ty==='EndCheckpoint'){
      let file=CP_TEX.startIdle,nf=1,fr=0;
      if(ty==='StartCheckpoint'){
        if(playing){file=CP_TEX.startMove;nf=17;fr=Math.floor(gt*12)%nf}
      }else if(ty==='Checkpoint'){
        if(playing&&n.activated){file=CP_TEX.cpOut;nf=26;fr=Math.min(25,Math.floor((n._flagT||0)*20))}
        else{file=CP_TEX.cpIdle;nf=10;fr=Math.floor(gt*10)%nf}
      }else if(won&&WINNER===n){file=CP_TEX.endPressed;nf=8;fr=Math.floor(gt*12)%nf}
      const im=IM(file);if(rdy(im))cell(bg,im,64,64,fr,x,y);else{bg.fillStyle='#FBBF24';bg.fillRect(x,y,n.w,n.h)}
      if(n.label){bg.fillStyle='#fde68a';bg.font='8px monospace';bg.textAlign='center';bg.textBaseline='alphabetic';bg.fillText(n.label,x+n.w/2,y-3);bg.textAlign='left'}
    }
    else if(ty==='SceneChanger'){
      drawDoor(bg,x,y,n.w,n.h,n,!!n.scene,playing,gt);
    }
    else if(ty==='Area2D'){
      const inf=n.tex&&AS[n.tex];
      if(inf)cell(bg,IM(n.tex),inf.fw,inf.fh,fi(gt+n.id*.13,16,inf.frames),R(x+n.w/2-inf.fw/2),R(y+n.h/2-inf.fh/2));
      else{bg.fillStyle='#F59E0B';bg.fillRect(x,y,n.w,n.h);bg.fillStyle='#fde68a';bg.fillRect(x+1,y+1,2,2)}}
    else if(ty==='Sprite2D'){
      const inf=AS[n.tex]||(window.BiteAssets&&BiteAssets.info?BiteAssets.info(n.tex):null);
      if(inf)cell(bg,IM(n.tex),inf.fw||n.w,inf.fh||n.h,fi(gt,n.fps||12,inf.frames||1),x,y,n.flip);
      else{bg.fillStyle='#EF4444';bg.fillRect(x,y,n.w,n.h)}
    }
    else if(ty==='Sound'){
      if(!playing){
        bg.fillStyle='#F472B6';bg.beginPath();bg.arc(x+n.w/2,y+n.h/2,7,0,Math.PI*2);bg.fill();
        bg.fillStyle='#111827';bg.font='bold 9px monospace';bg.textAlign='center';bg.textBaseline='middle';
        bg.fillText('♪',x+n.w/2,y+n.h/2+.5);bg.textAlign='left';bg.textBaseline='alphabetic';
      }
    }
    else if(ty==='Label'){bg.fillStyle=n.col||'#fff';bg.font=(n.size||8)+'px monospace';bg.textBaseline='top';bg.fillText(n.text||'',x,y)}
    else if(ty==='Camera2D'){if(!playing){bg.strokeStyle='#F59E0B';bg.setLineDash([4,3]);bg.strokeRect(x+.5,y+.5,GW-1,GH-1);bg.setLineDash([]);bg.fillStyle='#F59E0B';bg.fillRect(x,y,4,4)}}
    else if(ty==='Node2D'){bg.strokeStyle='#8B5CF6';bg.beginPath();bg.moveTo(x-4,y+.5);bg.lineTo(x+5,y+.5);bg.moveTo(x+.5,y-4);bg.lineTo(x+.5,y+5);bg.stroke()}
    else if(ty==='CharacterBody2D'&&n.skin){
      const st=playing&&n.as?n.as:'Idle',d=SA[st]||SA.Idle,t=playing&&n.as?n.at:gt,ga=bg.globalAlpha;
      if(playing&&(n.inv||0)>0&&Math.floor(gt*20)%2===0)bg.globalAlpha=ga*.4;
      cell(bg,IM('Characters/'+n.skin+'/'+d[0]),32,32,fi(t,1/d[2],d[1]),R(x+n.w/2-16),R(y+n.h-32),n.flip);
      bg.globalAlpha=ga;
    }else{const a=apOf(n),fr=a.frame(),sh=fr&&sheets[ANIMS[a.name].sheet];
      if(sh){const an=ty==='AnimatedSprite2D',px=an?(n.ctr===false?x:x+(n.w-sh.fw)/2)+(n.ox||0):x+n.w/2-sh.fw/2,py=an?(n.ctr===false?y:y+(n.h-sh.fh)/2)+(n.oy||0):y+n.h-sh.fh;
        spr(bg,sh,fr.f,R(px),R(py),n.flip,an&&n.flipV,an&&n.alpha!==undefined?n.alpha:1)}else{bg.fillStyle='#EF4444';bg.fillRect(x,y,n.w,n.h)}}
    if(!playing&&n===sel&&n.w>0){bg.strokeStyle='#8B5CF6';bg.lineWidth=1;bg.strokeRect(x-.5,y-.5,n.w+1,n.h+1)}
    if(SET.col&&n.w>0&&['CharacterBody2D','Area2D','StaticBody2D','Enemy','Spike','Spring','FireTrap','BreakableBox','MovingPlatform','StartCheckpoint','Checkpoint','EndCheckpoint','SceneChanger','Sound'].includes(ty)){
      bg.strokeStyle=ty==='Area2D'?'#F59E0B':ty==='Sound'?'#F472B6':ty==='SceneChanger'?'#2DD4BF':ty==='StaticBody2D'||ty==='MovingPlatform'?'#60A5FA':ty==='Enemy'||ty==='Spike'||ty==='FireTrap'?'#EF4444':'#22C55E';
      bg.strokeRect(x+.5,y+.5,n.w-1,n.h-1);
    }
    if(useTr)bg.restore();
  }
  if(!L.length&&!playing){bg.fillStyle='#94A3B8';bg.font='8px sans-serif';bg.textAlign='center';bg.textBaseline='alphabetic';bg.fillText('Empty scene. Create a node in the left panel.',GW/2,GH/2);bg.textAlign='left'}
  const co=IM('Items/Fruits/Collected.png');for(const e of fx)cell(bg,co,32,32,fi(e.t,15,6,false),R(e.x-cx),R(e.y-cy));
  if(won&&WINNER){
    bg.save();bg.globalAlpha=Math.min(1,WIN_T/.35);
    bg.fillStyle='rgba(5,8,15,.72)';bg.fillRect(0,0,GW,GH);
    bg.textAlign='center';bg.textBaseline='middle';
    bg.fillStyle='#fde68a';bg.font='bold 18px monospace';bg.fillText(WIN_TEXT,GW/2,GH/2-12);
    bg.fillStyle='#cbd5f5';bg.font='9px monospace';bg.fillText('Score '+score+(WIN_NEXT?'   Next: '+WIN_NEXT:''),GW/2,GH/2+14);
    bg.fillStyle='#94a3b8';bg.font='7px monospace';
    const hint=WIN_NEXT?(WINNER&&WINNER.autoNext?'Loading next scene '+WIN_NEXT+'…':'Press Space or Enter for '+WIN_NEXT):'Press Stop to edit, then Play to restart.';
    bg.fillText(hint,GW/2,GH/2+32);
    bg.restore();
  }
  if(MENU_OPEN)drawMenu(bg);
  const W=cv.width,H=cv.height,k=Math.min(W/GW,H/GH),s=pp?Math.max(1,Math.floor(k)):k;
  view={s,ox:pp?Math.floor((W-GW*s)/2):(W-GW*s)/2,oy:pp?Math.floor((H-GH*s)/2):(H-GH*s)/2};
  ctx.imageSmoothingEnabled=!pp;ctx.fillStyle='#05080f';ctx.fillRect(0,0,W,H);ctx.drawImage(buf,view.ox,view.oy,GW*s,GH*s);calls++;
  const v=$('#valid');
  if(pp)setValid('ok','✓ Nearest neighbor, '+s+'× integer scale');
  else setValid('warn','⚠ Smoothing on, '+s.toFixed(2)+'× scale: pixels may blur');
};

$('#bStop').addEventListener('click',()=>{cam.y=0});
demo();
if(!SCENES.length){SCENES=[{id:'s1',name:'Main',nodes}];CUR_SCENE='s1'}
syncSceneUI();
log('BiteEngine 3: empty scene. Create nodes in the left panel, then press Play (A/D move, Space jump).','ok');
})();
