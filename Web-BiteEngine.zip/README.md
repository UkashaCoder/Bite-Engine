# BiteEngine 3

![BiteEngine 3 — 2D game engine with Vexo scripting](logo-banner.png)

A free, open-source 2D game editor that runs entirely in the browser. Build
Godot-style node scenes, animate sprites, draw pixel art, write gameplay in the
built-in **Vexo 2D** language and play the result instantly. No install, no
build step, no account.

Licensed under the [MIT License](LICENSE). Free for personal, educational and
commercial use.

---

## Features

- **Project manager** - create, open, search, duplicate, download and delete
  projects. Projects are stored in the browser and can be exported as
  `.biteproj` files with an embedded project logo.
- **Godot-style scene editor** - scene tree, inspector, right-click node
  creation, drag to move, undo / redo, pixel-perfect integer scaling.
- **22 node types** - `Node2D`, `Sprite2D`, `AnimatedSprite2D`,
  `CharacterBody2D`, `Enemy`, `StaticBody2D`, `MovingPlatform`, `Area2D`,
  `Spike`, `Spring`, `FireTrap`, `BreakableBox`, `StartCheckpoint`,
  `Checkpoint`, `EndCheckpoint`, `SceneChanger`, `Sound`, `TileMap`,
  `ParallaxBackground`, `Camera2D`, `Label` and `AnimationPlayer`.
- **Vexo 2D scripting** - a small, readable language with variables, functions,
  `if` / `while` / `for`, signals, events, timers and collision callbacks. One
  click adds a ready-made behaviour script to the selected node.
- **Animation Studio** - import sprite sheets, slice frames, build animations,
  set FPS / loop / ping-pong / once, and preview with onion skin.
- **AnimationPlayer** - Godot-style keyframe timeline for position, rotation,
  opacity and visibility.
- **Pixel Art Studio** - 32 x 32 canvas with pencil, eraser, fill, line,
  rectangle, circle and colour picker. Send the sprite straight to game assets.
- **Multi-scene games** - create, duplicate, rename and delete scenes. Use
  `SceneChanger` or `EndCheckpoint` to load another scene or level.
- **Game menu builder** - main, pause and game-over menus with level select and
  settings; drawn in-game with keyboard, mouse and touch input.
- **Game Assets manager** - upload images and audio, create folders, and attach
  files to `Sprite2D`, `AnimatedSprite2D` and `Sound` nodes.
- **3 ready-made games** - Pixel Quest, Cave Escape and Sky Hopper, each with
  10 levels, player, hazards, music and menus.
- **Asset Store** - 271 bundled Pixel Adventure sprites with one-click import
  into My Library.
- **Glass UI and 5 colour themes** - Cyan, Violet, Emerald, Amber and Rose,
  plus light and dark modes. Choices are remembered on the device.
- **Mobile and PWA** - touch panels, pan mode, a single-file `mobile.html`
  build, offline support and installable app metadata.

---

## Run it

### Desktop

1. Extract the whole ZIP. Keep `index.html`, the `store/` folder and the
   `assets/` folder together.
2. Open `index.html` in a modern browser (Chrome, Edge, Firefox or Safari).
3. Pick a ready-made game or choose **+ New project**.

For the installable / offline features, serve the folder over HTTP instead of
opening the file directly:

```bash
python -m http.server 8080
# then open http://localhost:8080
```

Any static file server works. No Node.js, bundler or compiler is required.

### Phone

Open `mobile.html`. It contains the complete editor - HTML, both stylesheets
and all JavaScript - in one file. Keep it next to `assets/` and `store/` so the
bundled sounds and artwork load.

### Windows app

`BiteEngine3-Windows/BiteEngine3.exe` is a single-file Windows launcher for the
full engine. The folder also carries README-FIRST.txt, LICENSE, the logo and
all icon sizes.

1. Double-click it. It unpacks the engine to
   `%LOCALAPPDATA%\BiteEngine3\app` on first run.
2. It starts a small local server on `http://127.0.0.1:17823` and opens the
   editor in an Edge app window (no browser tabs or address bar).
3. A tray icon lets you reopen the editor, open the install folder or exit.
4. Projects stay in the Edge profile at `%LOCALAPPDATA%\BiteEngine3\profile`,
   so they survive restarts.

The exe is unsigned, so Windows SmartScreen may ask for confirmation the first
time. It needs Microsoft Edge (preinstalled on Windows 10/11). If Edge is
missing, it opens the editor in the default browser instead. Run it with
`--server-only` to start the server without opening a window.

### Default controls

| Action | Keys |
| --- | --- |
| Move | `A` / `D` or arrow keys |
| Jump | `Space`, `W` or `Up` |
| Pause / menu | `Esc` or `P` |
| Save project | `Ctrl+S` |
| Undo / redo | `Ctrl+Z` / `Ctrl+Y` |
| Duplicate node | `Ctrl+D` |
| Delete node | `Delete` |
| Rename node | `F2` |
| Pan the view | right-drag (or touch Pan mode) |

---

## How projects work

- Each project is stored in `localStorage` under `bite.proj.<name>`.
- `File > Save` stores the current project. `File > Save as` renames it.
- `File > Download .biteproj` exports the project, its scenes, animations,
  assets, menus, scripts and logo.
- `File > Open file...` imports a `.biteproj` file.
- The download dialog also exports the project logo as a 640 x 360 PNG and a
  256 x 256 Windows `.ico`.
- Browser storage is limited (usually about 5 MB). If a save reports that
  storage is full, export a `.biteproj` file and keep it as the master copy.

---

## Publishing and sharing

BiteEngine is a static website, so it can be published on any static host
(Netlify, GitHub Pages, Cloudflare Pages, Vercel, itch.io, a school server or a
plain web host).

1. Upload the whole folder, including `store/` and `assets/`.
2. Make sure the site is served over HTTPS. This enables the service worker,
   offline mode and PWA installation.
3. Open the site once online. `sw.js` caches the app shell so later visits work
   offline.
4. Use **File > Publish checklist** before sharing. It checks the project name,
   scenes, player, menus and logo, and gives you the download buttons.

To share a game project, send the `.biteproj` file (or the project's download
bundle). Players import it with **File > Open file...**. The engine itself can
also be installed as an app from the browser menu.

The service worker uses network-first loading for pages, scripts and styles, so
an updated deployment is picked up on the next visit while offline mode still
works from the cache.

### Bundled artwork

The Asset Store includes **Pixel Adventure** by Pixel Frog, released as CC0
public domain. It is redistributed with attribution in the Asset Store and can
be used freely in personal and commercial games.

---

## Files

| File | Purpose |
| --- | --- |
| `index.html` | App shell and editor markup |
| `mobile.html` | Single-file mobile build (all CSS + JS inline) |
| `style.css` | Glass UI, themes and desktop layout |
| `mobile.css` | Touch-first layout and bottom panels |
| `engine.js` | Rendering, animation runtime, pixel art, profiler, main loop |
| `godot.js` | Node types, scene tree, TileMap, gameplay, menus, Vexo glue |
| `project.js` | Project manager, save/load, templates, logos |
| `store.js` | Asset Store, Game Assets manager and sound library |
| `vexo.js` | Vexo 2D language lexer, parser and runtime |
| `mobile.js` | Mobile panels, pan mode, install and service-worker hook |
| `store/manifest.js` | Asset catalogue (271 sprites) |
| `manifest.webmanifest` | Installable app metadata |
| `sw.js` | Offline cache and update strategy |
| `logo.svg`, `logo.png`, `logo-banner.png` | Website / store logo artwork |
| `icon.svg`, `icon-1024.png`, `icon-192.png`, `icon-512.png`, `icon-maskable-512.png`, `favicon.ico` | App icons and favicon |
| `BiteEngine3-Windows/` | Windows release folder: exe, quick-start, license, logo and icons |
| `desktop/Program.cs`, `desktop/build-exe.ps1` | Launcher source and build script |
| `README.md` | This guide |
| `LICENSE` | MIT license text |

Folders:

- `store/` - bundled Pixel Adventure artwork.
- `assets/sounds/` - `jump.wav`, `collect_apple.wav`, `death.wav`, `music.ogg`.

---

## Development

There is no build step. Edit the files and reload the browser. The single-file
`mobile.html` is generated by inlining `style.css`, `mobile.css` and the seven
JavaScript files into `index.html`; regenerate it whenever you change those
files.

When you deploy an update, bump the cache name in `sw.js`
(`biteengine3-v11` -> `biteengine3-v12`) so returning visitors receive the new
version.

Tests are manual: open the app, switch through every workspace tab, open each
template, press Play, and check the browser console for errors.

---

## License

MIT. See [LICENSE](LICENSE).

You may use, copy, modify, merge, publish, distribute, sublicense and sell
copies of the software, including commercially, as long as the copyright notice
and permission notice are included. The software is provided "as is", without
warranty.

The bundled Pixel Adventure artwork is CC0 and is not covered by the MIT
license; its original attribution is kept in the Asset Store.
