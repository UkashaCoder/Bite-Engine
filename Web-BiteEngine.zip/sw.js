'use strict';
/* BiteEngine 3 — offline shell. Only runs when the app is served over http(s).
   App code and pages are network-first so a new version appears on the next
   visit; images and audio are cache-first for instant, offline-friendly loads. */
const CACHE='biteengine3-v12';
const SHELL=[
  './','./index.html','./mobile.html','./style.css','./mobile.css','./engine.js','./godot.js',
  './project.js','./store.js','./vexo.js','./mobile.js','./store/manifest.js',
  './icon.svg','./icon-192.png','./icon-512.png','./icon-maskable-512.png','./favicon.ico','./logo.svg','./manifest.webmanifest',
  './README.md','./LICENSE',
  './assets/sounds/jump.wav','./assets/sounds/collect_apple.wav',
  './assets/sounds/death.wav','./assets/sounds/music.ogg'
];

self.addEventListener('install',e=>{
  e.waitUntil(caches.open(CACHE).then(c=>c.addAll(SHELL)).then(()=>self.skipWaiting()));
});

self.addEventListener('activate',e=>{
  e.waitUntil(caches.keys()
    .then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k))))
    .then(()=>self.clients.claim()));
});

const isCode=u=>/\.(?:html?|js|css|webmanifest)$/i.test(u.pathname);

self.addEventListener('fetch',e=>{
  const req=e.request;
  if(req.method!=='GET')return;
  const u=new URL(req.url);
  if(u.origin!==location.origin)return;
  if(req.mode==='navigate'||isCode(u)){
    e.respondWith(fetch(req)
      .then(r=>{if(r.ok)caches.open(CACHE).then(c=>c.put(req,r.clone()));return r})
      .catch(()=>caches.match(req).then(hit=>hit||caches.match('./index.html'))));
    return;
  }
  e.respondWith(caches.match(req).then(hit=>{
    const net=fetch(req).then(r=>{
      if(r.ok)caches.open(CACHE).then(c=>c.put(req,r.clone()));
      return r;
    });
    return hit||net;
  }));
});
