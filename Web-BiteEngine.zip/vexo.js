'use strict';
/* VEXO SCRIPT 0.1 - browser runtime.
   A dependency-free port of the Vexo language (lexer, parser, tree-walking
   interpreter, signals, events, timers, exports) used by BiteEngine. */
(()=>{
const MAX_STEPS=1000000;

class VexoError extends Error{
  constructor(msg,line){super(line?'line '+line+': '+msg:msg);this.name='VexoError';this.msg=msg;this.line=line}
}

const KEYWORDS=new Set(['var','const','function','async','signal','emit','on','if','elif','else','while','for','in','return','pass','break','continue','after','every','connect','and','or','not']);
const ASSIGN=new Set(['=','+=','-=','*=','/=','%=']);
const CMP=new Set(['==','!=','<','>','<=','>=']);

/* ---------------- lexer ---------------- */
const TOKEN_RE=/([ \t]+)|(#.*|\/\/.*)|(\d+\.\d*|\.\d+|\d+)|("(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*')|([A-Za-z_][A-Za-z_0-9]*)|(->|==|!=|<=|>=|\+=|-=|\*=|\/=|%=|[-+*\/%<>=()\[\]{},.:@])/y;
const ESC={'n':'\n','t':'\t','\\':'\\','"':'"',"'":"'",'0':'\0'};
function unescapeStr(s){
  let out='',i=0;
  while(i<s.length){
    if(s[i]==='\\'&&i+1<s.length){out+=ESC[s[i+1]]!==undefined?ESC[s[i+1]]:s[i+1];i+=2}
    else{out+=s[i];i++}
  }
  return out;
}
function tokenize(src){
  const toks=[],indents=[0];let ln=0;
  for(const raw of src.split(/\r?\n/)){
    ln++;
    const line=raw.replace(/\t/g,'    '),stripped=line.trim();
    if(!stripped||stripped.startsWith('#')||stripped.startsWith('//'))continue;
    const ind=(line.match(/^ */)||[''])[0].length;
    if(ind>indents[indents.length-1]){indents.push(ind);toks.push({type:'INDENT',value:null,line:ln})}
    else{
      while(ind<indents[indents.length-1]){indents.pop();toks.push({type:'DEDENT',value:null,line:ln})}
      if(ind!==indents[indents.length-1])throw new VexoError('inconsistent indentation',ln);
    }
    let pos=0;
    while(pos<line.length){
      TOKEN_RE.lastIndex=pos;
      const m=TOKEN_RE.exec(line);
      if(!m)throw new VexoError('unexpected character '+JSON.stringify(line[pos]),ln);
      pos=TOKEN_RE.lastIndex;
      if(m[1]!==undefined||m[2]!==undefined)continue;
      let type,value;
      if(m[3]!==undefined){type='NUM';value=m[3].includes('.')?parseFloat(m[3]):parseInt(m[3],10)}
      else if(m[4]!==undefined){type='STR';value=unescapeStr(m[4].slice(1,-1))}
      else if(m[5]!==undefined){type='NAME';value=m[5]}
      else{type='OP';value=m[6]}
      toks.push({type,value,line:ln});
    }
    toks.push({type:'NEWLINE',value:null,line:ln});
  }
  while(indents.length>1){indents.pop();toks.push({type:'DEDENT',value:null,line:ln})}
  toks.push({type:'EOF',value:null,line:ln});
  return toks;
}

/* ---------------- parser ---------------- */
class Parser{
  constructor(toks){this.t=toks;this.i=0}
  peek(o=0){return this.t[Math.min(this.i+o,this.t.length-1)]}
  next(){return this.t[this.i++]}
  isOp(v){const t=this.peek();return t.type==='OP'&&t.value===v}
  isKw(v){const t=this.peek();return t.type==='NAME'&&t.value===v}
  acceptOp(v){if(this.isOp(v)){this.next();return true}return false}
  expectOp(v){if(!this.acceptOp(v)){const t=this.peek();throw new VexoError("expected '"+v+"'",t.line)}}
  expectName(){const t=this.next();if(t.type!=='NAME')throw new VexoError('expected a name',t.line);return t.value}
  end(){const t=this.peek();if(t.type==='NEWLINE')this.next();else if(t.type!=='DEDENT'&&t.type!=='EOF')throw new VexoError('unexpected '+JSON.stringify(t.value),t.line)}
  program(){const out=[];while(this.peek().type!=='EOF')out.push(this.statement());return out}
  block(){
    this.expectOp(':');
    if(this.peek().type==='NEWLINE'){
      this.next();
      if(this.peek().type!=='INDENT')throw new VexoError('expected an indented block',this.peek().line);
      this.next();const body=[];
      while(this.peek().type!=='DEDENT'&&this.peek().type!=='EOF')body.push(this.statement());
      if(this.peek().type==='DEDENT')this.next();
      return body;
    }
    return [this.statement()];
  }
  params(){
    const out=[];this.expectOp('(');
    while(!this.isOp(')')){const name=this.expectName();const def=this.acceptOp('=')?this.expr():null;out.push([name,def]);if(!this.acceptOp(','))break}
    this.expectOp(')');return out;
  }
  statement(){
    const t=this.peek(),line=t.line;
    if(t.type==='INDENT')throw new VexoError('unexpected indent',line);
    if(t.type==='OP'&&t.value==='@'){
      this.next();if(this.expectName()!=='export')throw new VexoError('unknown annotation (only @export exists)',line);
      if(this.isKw('var'))this.next();
      const name=this.expectName();this.expectOp('=');const e=this.expr();this.end();
      return ['export',name,e,line];
    }
    if(t.type==='NAME'){
      let k=t.value;
      if(k==='var'||k==='const'){
        this.next();const name=this.expectName();const e=this.acceptOp('=')?this.expr():null;this.end();
        return [k,name,e,line];
      }
      if(k==='async'&&this.peek(1).type==='NAME'&&this.peek(1).value==='function'){this.next();k='function'}
      if(k==='function'){
        this.next();const name=this.expectName();const params=this.params();
        return ['function',name,params,this.block(),line];
      }
      if(k==='signal'){
        this.next();const name=this.expectName();
        const params=this.isOp('(')?this.params().map(p=>p[0]):[];this.end();
        return ['signal',name,params,line];
      }
      if(k==='emit'){
        this.next();const e=this.expr();
        if(e[0]!=='call')throw new VexoError('emit needs a call, e.g. emit died()',line);
        this.end();return ['emit',e[1],e[2],line];
      }
      if(k==='on'){
        this.next();const event=this.expectName(),pats=[];
        if(this.acceptOp('(')){while(!this.isOp(')')){pats.push(this.expr());if(!this.acceptOp(','))break}this.expectOp(')')}
        return ['on',event,pats,this.block(),line];
      }
      if(k==='if'){
        this.next();const branches=[],cond=this.expr();branches.push([cond,this.block()]);let elseBody=null;
        for(;;){
          if(this.isKw('elif')){this.next();branches.push([this.expr(),this.block()])}
          else if(this.isKw('else')){this.next();elseBody=this.block();break}
          else break;
        }
        return ['if',branches,elseBody,line];
      }
      if(k==='while'){this.next();const c=this.expr();return ['while',c,this.block(),line]}
      if(k==='for'){
        this.next();const name=this.expectName();
        if(!this.isKw('in'))throw new VexoError("expected 'in'",this.peek().line);
        this.next();const it=this.expr();return ['for',name,it,this.block(),line];
      }
      if(k==='return'){this.next();const e=(this.peek().type==='NEWLINE'||this.peek().type==='DEDENT'||this.peek().type==='EOF')?null:this.expr();this.end();return ['return',e,line]}
      if(k==='pass'||k==='break'||k==='continue'){this.next();this.end();return [k,line]}
      if(k==='after'||k==='every'){this.next();const e=this.expr();return [k,e,this.block(),line]}
      if(k==='connect'){this.next();const sig=this.expr();this.expectOp('->');const handler=this.expr();this.end();return ['connect',sig,handler,line]}
    }
    const e=this.expr(),nt=this.peek();
    if(nt.type==='OP'&&ASSIGN.has(nt.value)){
      const op=this.next().value;
      if(!['name','member','index'].includes(e[0]))throw new VexoError('cannot assign to this expression',line);
      const v=this.expr();this.end();return ['assign',op,e,v,line];
    }
    this.end();return ['expr',e,line];
  }
  expr(){return this.or()}
  or(){let l=this.and();while(this.isKw('or')){this.next();l=['or',l,this.and()]}return l}
  and(){let l=this.not();while(this.isKw('and')){this.next();l=['and',l,this.not()]}return l}
  not(){if(this.isKw('not')){this.next();return ['not',this.not()]}return this.cmp()}
  cmp(){
    let l=this.add();
    for(;;){
      const t=this.peek();
      if(t.type==='OP'&&CMP.has(t.value)){this.next();l=['bin',t.value,l,this.add(),t.line]}
      else if(t.type==='NAME'&&t.value==='in'){this.next();l=['bin','in',l,this.add(),t.line]}
      else return l;
    }
  }
  add(){let l=this.mul();while(this.peek().type==='OP'&&(this.peek().value==='+'||this.peek().value==='-')){const t=this.next();l=['bin',t.value,l,this.mul(),t.line]}return l}
  mul(){let l=this.unary();while(this.peek().type==='OP'&&['*','/','%'].includes(this.peek().value)){const t=this.next();l=['bin',t.value,l,this.unary(),t.line]}return l}
  unary(){if(this.isOp('-')){this.next();return ['neg',this.unary()]}return this.postfix()}
  postfix(){
    let e=this.primary();
    for(;;){
      const t=this.peek();
      if(t.type!=='OP')return e;
      if(t.value==='('){
        this.next();const args=[];
        while(!this.isOp(')')){args.push(this.expr());if(!this.acceptOp(','))break}
        this.expectOp(')');e=['call',e,args,t.line];
      }else if(t.value==='.'){this.next();e=['member',e,this.expectName(),t.line]}
      else if(t.value==='['){
        this.next();const idx=this.expr();this.expectOp(']');e=['index',e,idx,t.line];
      }else return e;
    }
  }
  primary(){
    const t=this.next(),{type,value,line}=t;
    if(type==='NUM'||type==='STR')return ['lit',value];
    if(type==='NAME'){
      if(value==='true')return ['lit',true];
      if(value==='false')return ['lit',false];
      if(value==='null'||value==='none'||value==='nil')return ['lit',null];
      if(KEYWORDS.has(value))throw new VexoError("unexpected keyword '"+value+"'",line);
      return ['name',value,line];
    }
    if(type==='OP'){
      if(value==='('){const e=this.expr();this.expectOp(')');return e}
      if(value==='['){
        const items=[];while(!this.isOp(']')){items.push(this.expr());if(!this.acceptOp(','))break}
        this.expectOp(']');return ['list',items];
      }
      if(value==='{'){
        const pairs=[];while(!this.isOp('}')){const k=this.expr();this.expectOp(':');pairs.push([k,this.expr()]);if(!this.acceptOp(','))break}
        this.expectOp('}');return ['dict',pairs];
      }
    }
    throw new VexoError('unexpected '+(value!==null?value:type),line);
  }
}
function parse(source){return new Parser(tokenize(source)).program()}
function check(source){parse(source)}

/* ---------------- values ---------------- */
class Vec2{
  constructor(x=0,y=0){this.x=Number(x)||0;this.y=Number(y)||0}
  length(){return Math.hypot(this.x,this.y)}
  normalized(){const n=this.length();return n===0?new Vec2():new Vec2(this.x/n,this.y/n)}
  dist(o){return Math.hypot(this.x-o.x,this.y-o.y)}
  dot(o){return this.x*o.x+this.y*o.y}
  __repr__(){return 'vec2('+this.x+', '+this.y+')'}
}
class Color{
  constructor(r=255,g=255,b=255,a=255){this.r=Math.trunc(r);this.g=Math.trunc(g);this.b=Math.trunc(b);this.a=Math.trunc(a)}
}
function vstr(v){
  if(v===true)return 'true';
  if(v===false)return 'false';
  if(v===null||v===undefined)return 'null';
  if(typeof v==='number'){if(Number.isInteger(v)&&Math.abs(v)<1e15)return String(v);return String(Math.round(v*1e10)/1e10)}
  if(v instanceof Vec2)return 'vec2('+vstr(v.x)+', '+vstr(v.y)+')';
  if(v instanceof Color)return 'color('+v.r+', '+v.g+', '+v.b+')';
  if(Array.isArray(v))return '['+v.map(x=>typeof x==='string'?'"'+x+'"':vstr(x)).join(', ')+']';
  if(v&&typeof v==='object'&&!isNode(v))return '{'+Object.keys(v).map(k=>k+': '+vstr(v[k])).join(', ')+'}';
  if(v&&typeof v==='object')return '<'+(v.name||v.type)+'>';
  return String(v);
}
function truthy(v){
  if(v===null||v===undefined||v===false)return false;
  if(typeof v==='number')return v!==0;
  if(typeof v==='string')return v.length>0;
  if(Array.isArray(v))return v.length>0;
  if(v instanceof Map)return v.size>0;
  if(v instanceof Vec2)return true;
  if(typeof v==='object')return Object.keys(v).length>0;
  return true;
}
function valueEq(a,b){
  if(a===b)return true;
  if(a instanceof Vec2&&b instanceof Vec2)return a.x===b.x&&a.y===b.y;
  if(a instanceof Color&&b instanceof Color)return a.r===b.r&&a.g===b.g&&a.b===b.b&&a.a===b.a;
  if(Array.isArray(a)&&Array.isArray(b))return a.length===b.length&&a.every((x,i)=>valueEq(x,b[i]));
  return false;
}
function isNode(v){return !!(v&&typeof v==='object'&&typeof v.type==='string'&&v.id!=null&&typeof v.x==='number'&&typeof v.y==='number')}
let NODE_SCRIPTS=new WeakMap();
function scriptOfNode(n){return NODE_SCRIPTS.get(n)||null}
function clearNodeScripts(){NODE_SCRIPTS=new WeakMap()}

/* ---------------- interpreter ---------------- */
class Scope{constructor(parent=null){this.vars=new Map();this.consts=new Set();this.parent=parent}}
class VexoFunction{
  constructor(name,params,body,scope,inst,line){this.name=name;this.params=params;this.body=body;this.scope=scope;this.inst=inst;this.line=line}
  call(...args){return this.inst._callFunction(this,args)}
  __repr__(){return '<function '+this.name+'>'}
}
class ReturnCtl{constructor(value){this.value=value}}
class BreakCtl{}
class ContinueCtl{}
class Signal{
  constructor(name='signal'){this.name=name;this.handlers=[]}
  connect(fn){if(typeof fn!=='function'&&!(fn&&typeof fn.call==='function'))throw new TypeError('connect() needs a function');if(!this.handlers.includes(fn))this.handlers.push(fn)}
  disconnect(fn){const i=this.handlers.indexOf(fn);if(i>=0)this.handlers.splice(i,1)}
  emit(...args){for(const h of [...this.handlers]){if(typeof h==='function')h(...args);else h.call(...args)}}
}
const BINOPS={
  '+':(a,b)=>a+b,'-':(a,b)=>a-b,'*':(a,b)=>a*b,'/':(a,b)=>a/b,'%':(a,b)=>a%b,
  '<':(a,b)=>a<b,'>':(a,b)=>a>b,'<=':(a,b)=>a<=b,'>=':(a,b)=>a>=b,
  'in':(a,b)=>b instanceof Map?b.has(a):typeof b==='string'?b.includes(a):Array.isArray(b)?b.includes(a):b&&typeof b==='object'?Object.prototype.hasOwnProperty.call(b,a):false
};
function binop(op,a,b){
  if(op==='+'&&(typeof a==='string')!==(typeof b==='string'))return vstr(a)+vstr(b);
  if(op==='==')return valueEq(a,b);
  if(op==='!=')return !valueEq(a,b);
  if(a instanceof Vec2||b instanceof Vec2){
    if(op==='+'&&a instanceof Vec2&&b instanceof Vec2)return new Vec2(a.x+b.x,a.y+b.y);
    if(op==='-'&&a instanceof Vec2&&b instanceof Vec2)return new Vec2(a.x-b.x,a.y-b.y);
    if(op==='*')return a instanceof Vec2&&b instanceof Vec2?new Vec2(a.x*b.x,a.y*b.y):a instanceof Vec2?new Vec2(a.x*b,a.y*b):new Vec2(a*b.x,a*b.y);
    if(op==='/')return a instanceof Vec2?new Vec2(a.x/b,a.y/b):new Vec2(a/b.x,a/b.y);
  }
  const f=BINOPS[op];if(!f)throw new VexoError('unknown operator '+op);
  return f(a,b);
}
function invoke(f,args){return f instanceof VexoFunction?f.call(...args):f(...args)}
const clamp=(v,lo,hi)=>Math.max(lo,Math.min(hi,v));
const hasOwn=(o,k)=>Object.prototype.hasOwnProperty.call(o,k);
const LIST_METHODS={
  append:o=>v=>{o.push(v)},
  pop:o=>(i=-1)=>i===undefined?o.pop():(i<0?o.splice(o.length+i,1):o.splice(i,1))[0],
  insert:o=>(i,v)=>{o.splice(i,0,v)},
  remove:o=>v=>{const i=o.findIndex(x=>valueEq(x,v));if(i>=0)o.splice(i,1)},
  extend:o=>a=>{o.push(...a)},
  index:o=>v=>o.findIndex(x=>valueEq(x,v)),
  count:o=>v=>o.filter(x=>valueEq(x,v)).length,
  sort:o=>(...a)=>o.sort(),
  reverse:o=>()=>o.reverse()
};
const DICT_METHODS={
  keys:o=>()=>Object.keys(o),
  values:o=>()=>Object.values(o),
  items:o=>()=>Object.entries(o),
  get:o=>(k,d=null)=>hasOwn(o,k)?o[k]:d,
  has:o=>k=>hasOwn(o,k),
  pop:o=>(k,d=null)=>{if(!hasOwn(o,k))return d;const v=o[k];delete o[k];return v}
};

function makeBuiltins(inst){
  return new Map(Object.entries({
    self:inst.host,
    print:inst._print.bind(inst),
    str:vstr,
    int:v=>Math.trunc(Number(v)),
    float:v=>Number(v),
    bool:v=>truthy(v),
    len:v=>v==null?0:typeof v==='string'||Array.isArray(v)?v.length:v instanceof Map?v.size:typeof v==='object'?Object.keys(v).length:0,
    range:(...a)=>{
      const nums=a.map(x=>Math.trunc(Number(x)));
      let start=0,stop=0,step=1;
      if(nums.length===1)stop=nums[0];else if(nums.length===2){start=nums[0];stop=nums[1]}else{start=nums[0];stop=nums[1];step=nums[2]||1}
      const out=[];if(step>0)for(let i=start;i<stop;i+=step)out.push(i);else for(let i=start;i>stop;i+=step)out.push(i);
      return out;
    },
    abs:Math.abs,
    min:(...a)=>Math.min(...(a.length===1&&Array.isArray(a[0])?a[0]:a)),
    max:(...a)=>Math.max(...(a.length===1&&Array.isArray(a[0])?a[0]:a)),
    round:(v,n=0)=>{const f=Math.pow(10,Math.trunc(n));return Math.round(v*f)/f},
    floor:Math.floor,ceil:Math.ceil,sqrt:Math.sqrt,
    sin:Math.sin,cos:Math.cos,tan:Math.tan,atan2:Math.atan2,
    radians:d=>d*Math.PI/180,degrees:r=>r*180/Math.PI,
    clamp,lerp:(a,b,t)=>a+(b-a)*t,
    sign:v=>(v>0)-(v<0),
    move_toward:(a,b,d)=>Math.abs(b-a)<=d?b:a+d*((b>a)-(b<a)),
    random:Math.random,
    randf:(a,b)=>a+Math.random()*(b-a),
    randi:(a,b)=>Math.floor(a+Math.random()*(b-a+1)),
    choice:a=>a[Math.floor(Math.random()*a.length)],
    vec2:(x,y)=>new Vec2(x,y),
    color:(r,g,b,a)=>new Color(r,g,b,a),
    is_valid:v=>v!==null&&v!==undefined,
    PI:Math.PI,TAU:Math.PI*2
  }));
}

class VexoScript{
  constructor(source,opt={}){
    this.name=opt.name||'<script>';
    this.host=opt.host||null;
    this.api=Object.assign({},opt.api||{});
    this.overrides=Object.assign({},opt.exports||{});
    this.printFn=opt.printFn||console.log;
    this.output=[];
    this.exports={};
    this.signals=new Map();
    this.handlers=new Map();
    this.timers=[];
    this.globals=new Scope();
    this._steps=0;this._depth=0;this.err=null;
    this.ast=parse(source);
    this.builtins=makeBuiltins(this);
    if(this.host&&typeof this.host==='object')NODE_SCRIPTS.set(this.host,this);
    this._run(()=>this._runBody(this.ast,this.globals));
  }
  fire(event,...args){
    let ran=0;
    for(const [pats,body,scope,line] of [...(this.handlers.get(event)||[])]){
      const env=new Scope(scope);
      if(!this._bindEvent(pats,args,env,scope))continue;
      this._run(()=>this._runBody(body,env,line));ran++;
    }
    return ran;
  }
  tick(dt){
    for(const t of [...this.timers]){
      t.left-=dt;
      if(t.left>1e-9||!this.timers.includes(t))continue;
      if(t.every===null)this.timers.splice(this.timers.indexOf(t),1);else t.left+=t.every;
      const env=new Scope(t.scope);
      this._run(()=>this._runBody(t.body,env,t.line));
    }
  }
  call(name,...args){
    const fn=this.getVar(name);
    return invoke(fn,args);
  }
  hasVar(name){return this.globals.vars.has(name)}
  getVar(name){
    if(this.globals.vars.has(name))return this.globals.vars.get(name);
    throw new Error("script has no variable or function '"+name+"'");
  }
  setVar(name,value){
    if(this.globals.consts.has(name))throw new VexoError("cannot assign to constant '"+name+"'");
    this.globals.vars.set(name,value);
  }
  hasHandler(event){return (this.handlers.get(event)||[]).length>0}
  exportInfo(){
    const out={};
    for(const n of Object.keys(this.exports))out[n]={value:this.globals.vars.get(n),default:this.exports[n],type:typeof this.exports[n]};
    return out;
  }
  clearTimers(){this.timers.length=0}
  _print(...args){
    const text=args.map(vstr).join(' ');
    this.output.push(text);
    if(this.output.length>200)this.output.shift();
    try{this.printFn(text)}catch{}
  }
  _run(fn){
    const outer=this._depth===0;
    if(outer)this._steps=0;
    this._depth++;
    try{return fn()}finally{this._depth--}
  }
  _runBody(body,env,line=null){
    try{this._execBlock(body,env)}
    catch(e){
      if(e instanceof ReturnCtl)return e.value;
      if(e instanceof BreakCtl)throw new VexoError("'break' used outside a loop",line);
      if(e instanceof ContinueCtl)throw new VexoError("'continue' used outside a loop",line);
      throw e;
    }
    return null;
  }
  _bindEvent(pats,args,env,scope){
    for(let i=0;i<pats.length;i++){
      const p=pats[i],val=i<args.length?args[i]:null;
      if(p[0]==='name')env.vars.set(p[1],val);
      else if(i>=args.length||!valueEq(this._eval(p,scope),val))return false;
    }
    return true;
  }
  _callFunction(fn,args){
    return this._run(()=>{
      const nAll=fn.params.length,nReq=fn.params.filter(p=>p[1]===null).length;
      if(args.length<nReq||args.length>nAll){
        const want=nReq===nAll?String(nAll):nReq+'-'+nAll;
        throw new VexoError(fn.name+'() takes '+want+' argument(s), got '+args.length,fn.line);
      }
      const env=new Scope(fn.scope);
      fn.params.forEach(([pn,def],i)=>{env.vars.set(pn,i<args.length?args[i]:this._eval(def,fn.scope))});
      return this._runBody(fn.body,env,fn.line);
    });
  }
  _execBlock(body,scope){for(const st of body)this._exec(st,scope)}
  _exec(st,scope){
    this._steps++;
    if(this._steps>MAX_STEPS)throw new VexoError('script exceeded the step limit (infinite loop?)',st[st.length-1]);
    const k=st[0];
    try{
      if(k==='expr')this._eval(st[1],scope);
      else if(k==='assign')this._assign(st,scope);
      else if(k==='if'){
        let done=false;
        for(const [cond,body] of st[1])if(truthy(this._eval(cond,scope))){this._execBlock(body,scope);done=true;break}
        if(!done&&st[2]!==null)this._execBlock(st[2],scope);
      }
      else if(k==='var')scope.vars.set(st[1],st[2]!==null?this._eval(st[2],scope):null);
      else if(k==='const'){scope.vars.set(st[1],st[2]!==null?this._eval(st[2],scope):null);scope.consts.add(st[1])}
      else if(k==='export'){
        const def=this._eval(st[2],scope);
        this.exports[st[1]]=def;
        scope.vars.set(st[1],Object.prototype.hasOwnProperty.call(this.overrides,st[1])?this.overrides[st[1]]:def);
      }
      else if(k==='function')scope.vars.set(st[1],new VexoFunction(st[1],st[2],st[3],scope,this,st[st.length-1]));
      else if(k==='signal'){const sig=new Signal(st[1]);this.signals.set(st[1],sig);scope.vars.set(st[1],sig)}
      else if(k==='emit'){
        const sig=this._eval(st[1],scope);
        if(!(sig instanceof Signal))throw new VexoError('emit target is not a signal',st[st.length-1]);
        sig.emit(...st[2].map(a=>this._eval(a,scope)));
      }
      else if(k==='on')this.handlers.set(st[1],(this.handlers.get(st[1])||[]).concat([[st[2],st[3],scope,st[st.length-1]]]));
      else if(k==='while'){
        while(truthy(this._eval(st[1],scope))){
          try{this._execBlock(st[2],scope)}catch(e){if(e instanceof BreakCtl)break;if(e instanceof ContinueCtl)continue;throw e}
        }
      }
      else if(k==='for'){
        let it=this._eval(st[2],scope);
        if(it instanceof Map)it=[...it.keys()];
        else if(it&&typeof it==='object'&&!Array.isArray(it)&&typeof it[Symbol.iterator]!=='function')it=Object.keys(it);
        for(const item of [...it]){
          scope.vars.set(st[1],item);
          try{this._execBlock(st[3],scope)}catch(e){if(e instanceof BreakCtl)break;if(e instanceof ContinueCtl)continue;throw e}
        }
      }
      else if(k==='return')throw new ReturnCtl(st[1]!==null?this._eval(st[1],scope):null);
      else if(k==='pass'){/* noop */}
      else if(k==='break')throw new BreakCtl();
      else if(k==='continue')throw new ContinueCtl();
      else if(k==='after'||k==='every'){
        const secs=Number(this._eval(st[1],scope));
        if(k==='every'&&secs<=0)throw new VexoError("'every' needs a positive interval",st[st.length-1]);
        this.timers.push({left:Math.max(secs,0),every:k==='every'?secs:null,body:st[2],scope,line:st[st.length-1]});
      }
      else if(k==='connect'){
        const sig=this._eval(st[1],scope);
        if(!(sig instanceof Signal))throw new VexoError("connect needs a signal on the left of '->'",st[st.length-1]);
        sig.connect(this._eval(st[2],scope));
      }
      else throw new VexoError('unknown statement '+k,st[st.length-1]);
    }catch(e){
      if(e instanceof ReturnCtl||e instanceof BreakCtl||e instanceof ContinueCtl)throw e;
      if(e instanceof VexoError){if(e.line==null)e.line=st[st.length-1];throw e}
      throw new VexoError((e&&e.name?e.name+': ':'')+(e&&e.message?e.message:String(e)),st[st.length-1]);
    }
  }
  _assign(st,scope){
    const [,op,target,vexpr]=st;
    let value=this._eval(vexpr,scope);
    if(op!=='=')value=binop(op[0],this._eval(target,scope),value);
    if(target[0]==='name')this._setName(target[1],value,scope);
    else if(target[0]==='member')this._setMember(this._eval(target[1],scope),target[2],value);
    else this._eval(target[1],scope)[this._eval(target[2],scope)]=value;
  }
  _setName(name,value,scope){
    for(let sc=scope;sc;sc=sc.parent){
      if(sc.vars.has(name)){
        if(sc.consts.has(name))throw new VexoError("cannot assign to constant '"+name+"'");
        sc.vars.set(name,value);return;
      }
    }
    scope.vars.set(name,value);
  }
  _getMember(obj,name){
    if(typeof name==='string'&&name.startsWith('_'))throw new VexoError("cannot access private member '"+name+"'");
    if(obj instanceof VexoScript)return obj.getVar(name);
    if(obj instanceof Vec2||obj instanceof Color||obj instanceof Signal){
      if(name in obj){const v=obj[name];return typeof v==='function'?v.bind(obj):v}
      throw new VexoError('unknown member '+name);
    }
    if(isNode(obj)){
      if(name==='position')return new Vec2(obj.x,obj.y);
      if(name==='visible')return !obj.hide;
      if(name==='rotation')return obj.rotation||0;
      if(name==='alpha')return obj.alpha===undefined?1:obj.alpha;
      if(Object.prototype.hasOwnProperty.call(obj,name)){const v=obj[name];return typeof v==='function'?v.bind(obj):v}
      const si=scriptOfNode(obj);
      if(si&&si.hasVar(name))return si.getVar(name);
      throw new VexoError("unknown member '"+name+"' on node "+obj.name);
    }
    if(obj instanceof Map){if(obj.has(name))return obj.get(name);throw new VexoError("unknown key '"+name+"'")}
    if(Array.isArray(obj)&&LIST_METHODS[name])return LIST_METHODS[name](obj);
    if(obj&&typeof obj==='object'&&DICT_METHODS[name]&&!hasOwn(obj,name))return DICT_METHODS[name](obj);
    if(obj!=null&&(typeof obj==='object'||typeof obj==='string')){
      if(name in obj){const v=obj[name];return typeof v==='function'?v.bind(obj):v}
      throw new VexoError("unknown member '"+name+"'");
    }
    throw new VexoError("cannot read member '"+name+"'");
  }
  _setMember(obj,name,value){
    if(typeof name==='string'&&name.startsWith('_'))throw new VexoError("cannot access private member '"+name+"'");
    if(obj instanceof VexoScript){obj.setVar(name,value);return}
    if(isNode(obj)){
      if(name==='position'){
        if(value instanceof Vec2){obj.x=value.x;obj.y=value.y}
        else if(Array.isArray(value)){obj.x=value[0];obj.y=value[1]}
        else throw new VexoError('position needs a vec2');
        return;
      }
      if(name==='visible'){obj.hide=!truthy(value);return}
      const si=scriptOfNode(obj);
      if(!Object.prototype.hasOwnProperty.call(obj,name)&&si&&si.hasVar(name))si.setVar(name,value);
      else obj[name]=value;
      return;
    }
    if(obj instanceof Map){obj.set(name,value);return}
    if(obj!=null&&typeof obj==='object'){obj[name]=value;return}
    throw new VexoError("cannot set member '"+name+"'");
  }
  _lookup(name,scope,line){
    for(let sc=scope;sc;sc=sc.parent)if(sc.vars.has(name))return sc.vars.get(name);
    if(this.builtins.has(name))return this.builtins.get(name);
    if(Object.prototype.hasOwnProperty.call(this.api,name))return this.api[name];
    if(this.host&&!name.startsWith('_')&&Object.prototype.hasOwnProperty.call(this.host,name)){
      const v=this.host[name];return typeof v==='function'?v.bind(this.host):v;
    }
    throw new VexoError("unknown name '"+name+"' (not a variable, built-in, or engine function registered by the host)",line);
  }
  _eval(e,scope){
    const k=e[0];
    if(k==='lit')return e[1];
    if(k==='name')return this._lookup(e[1],scope,e[2]);
    if(k==='bin')return binop(e[1],this._eval(e[2],scope),this._eval(e[3],scope));
    if(k==='call'){
      const f=this._eval(e[1],scope),args=e[2].map(a=>this._eval(a,scope));
      if(f instanceof VexoFunction)return f.call(...args);
      if(typeof f==='function')return f(...args);
      throw new VexoError(vstr(f)+' is not callable',e[3]);
    }
    if(k==='member')return this._getMember(this._eval(e[1],scope),e[2]);
    if(k==='index'){
      const obj=this._eval(e[1],scope),idx=this._eval(e[2],scope);
      if(obj instanceof Map)return obj.get(idx);
      if(obj==null)throw new VexoError('cannot index '+vstr(obj));
      return obj[idx];
    }
    if(k==='and'){const l=this._eval(e[1],scope);return truthy(l)?this._eval(e[2],scope):l}
    if(k==='or'){const l=this._eval(e[1],scope);return truthy(l)?l:this._eval(e[2],scope)}
    if(k==='not')return !truthy(this._eval(e[1],scope));
    if(k==='neg'){const v=this._eval(e[1],scope);return v instanceof Vec2?new Vec2(-v.x,-v.y):-v}
    if(k==='list')return e[1].map(x=>this._eval(x,scope));
    if(k==='dict'){
      const out={};
      for(const [a,b] of e[1])out[this._eval(a,scope)]=this._eval(b,scope);
      return out;
    }
    throw new VexoError('unknown expression '+k);
  }
}

/* ---------------- Quick Game Logic behaviours ---------------- */
const BEHAVIOURS={
  move_player:{desc:'Arrow keys / WASD movement',defaults:{speed:200},template:'@export speed = $speed\n\non input("LEFT", dt):\n    move(-speed * dt, 0)\non input("RIGHT", dt):\n    move(speed * dt, 0)\non input("UP", dt):\n    move(0, -speed * dt)\non input("DOWN", dt):\n    move(0, speed * dt)\non input("A", dt):\n    move(-speed * dt, 0)\non input("D", dt):\n    move(speed * dt, 0)\non input("W", dt):\n    move(0, -speed * dt)\non input("S", dt):\n    move(0, speed * dt)\n'},
  follow_player:{desc:'Chase the node named Player',defaults:{speed:80},template:'@export speed = $speed\n\non update(dt):\n    var target = find("Player")\n    if target != null:\n        var dir = (target.position - self.position).normalized()\n        move(dir.x * speed * dt, dir.y * speed * dt)\n'},
  collect_coin:{desc:'Collect on contact and add score',defaults:{value:10},template:'@export value = $value\n\non collision(other):\n    if other.name == "Player":\n        set_score(get_score() + value)\n        play_sound("coin.wav")\n        destroy()\n'},
  take_damage:{desc:'Health, damage and a died signal',defaults:{health:100},template:'@export max_health = $health\nvar health = $health\nsignal health_changed(value)\nsignal died()\n\nfunction take_damage(amount):\n    health = max(0, health - amount)\n    emit health_changed(health)\n    if health <= 0:\n        emit died()\n'},
  open_door:{desc:'Animate then vanish when touched',defaults:{},template:'on collision(other):\n    if other.name == "Player":\n        play_animation("open")\n        after 0.4:\n            destroy()\n'},
  play_animation:{desc:'Play an animation on start',defaults:{anim:'idle'},template:'@export animation_name = "$anim"\n\non start:\n    play_animation(animation_name)\n'},
  enemy_damage:{desc:'Damage the player on contact',defaults:{damage:1},template:'@export damage = $damage\n\non collision(other):\n    if other.type == "CharacterBody2D":\n        damage_player(damage)\n'},
  heal_on_touch:{desc:'Heal the player, then disappear',defaults:{amount:1},template:'@export amount = $amount\n\non collision(other):\n    if other.type == "CharacterBody2D":\n        heal_player(amount)\n        destroy()\n'},
  save_checkpoint:{desc:'Save a respawn point when touched',defaults:{},template:'on collision(other):\n    if other.type == "CharacterBody2D":\n        save_checkpoint()\n        print("Checkpoint saved")\n'},
  sound_on_start:{desc:'Play a sound when the level starts',defaults:{clip:'music',volume:0.6},template:'@export clip = "$clip"\n@export volume = $volume\n\non start:\n    play_sound(clip, volume)\n'},
  sound_on_touch:{desc:'Play a sound when the player touches it',defaults:{clip:'collect_apple',volume:0.8},template:'@export clip = "$clip"\n@export volume = $volume\n\non collision(other):\n    if other.type == "CharacterBody2D":\n        play_sound(clip, volume)\n'},
  win_level:{desc:'Win the level when touched',defaults:{text:'You win!'},template:'@export message = "$text"\n\non collision(other):\n    if other.type == "CharacterBody2D":\n        win_level(message)\n'},
  change_scene:{desc:'Load another scene when touched',defaults:{scene:'Level 2'},template:'@export target_scene = "$scene"\n\non collision(other):\n    if other.type == "CharacterBody2D":\n        change_scene(target_scene)\n'},
  score_label:{desc:'Show the score on a Label',defaults:{},template:'on start:\n    self.text = "Score " + str(get_score())\n\non update(dt):\n    self.text = "Score " + str(get_score())\n'},
  fall_respawn:{desc:'Respawn after falling off the level',defaults:{limit:600},template:'@export fall_limit = $limit\n\non update(dt):\n    if self.position.y > fall_limit:\n        respawn_player()\n'}
};
function makeBehaviour(name,params={}){
  if(!BEHAVIOURS[name])throw new Error("unknown behaviour '"+name+"'");
  const vals=Object.assign({},BEHAVIOURS[name].defaults,params);
  return BEHAVIOURS[name].template.replace(/\$(\w+)/g,(m,k)=>vstr(vals[k]));
}

window.Vexo={VexoError,VexoScript,Signal,Vec2,Color,parse,check,tokenize,scriptOfNode,clearNodeScripts,makeBehaviour,BEHAVIOURS,vstr,truthy};
})();
